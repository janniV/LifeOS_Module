# LifeOS Music Player

JAR-Modul für LifeOS (siehe `LifeOS-Modulstandard.txt`). Implementiert
`core.LifeModule` und wird über `META-INF/services/core.LifeModule` registriert.

## Funktionen

- Tabs **Titel**, **Künstler:innen**, **Alben**, **Playlists**,
  **Warteschlange**, **Songtext**, **Quellen** (keine Sidebar-Submodule).
- **Quellen**: lokale Ordner und NAS-Einstiege aus
  `core.getRemoteFileEntryPoints(...)`. Scan nur auf Anforderung mit
  Fortschrittsanzeige.
- **Bibliothek** wird im Modul-Speicher als `library.json` persistiert,
  Tags via *jaudiotagger* (ID3 / Vorbis / MP4 / FLAC).
- **Wiedergabe**: Ab v0.9 läuft alles über **FFmpeg** (via JavaCPP /
  JavaCV) — MP3, AAC, FLAC, OGG/Vorbis/Opus, WAV, AIFF, ALAC, WMA,
  AC3, DSD-WAV usw. Der alte JavaFX-`MediaPlayer`-Pfad und der
  jflac-Pfad bleiben als Fallback im Code, falls die nativen
  FFmpeg-Bibliotheken auf einer Plattform nicht laden.
- **NAS-Cache** mit LRU-ähnlicher Verdrängung (Default 8 GiB), damit
  Festplatten-Spin-up nicht jedes Mal nötig ist.
- **Playlists** persistiert in `playlists.json`.
- **Songtexte** aus ID3/Vorbis-Tags lesen, im Modul-Speicher überschreibbar
  speichern, optional über das interne LifeOS-LLM nachladen.
- **Dashboard-Widget** „Aktuell läuft" inkl. Transport-Buttons.
- **OS Media Center**: Aktuell laufender Titel wird automatisch an
  `core.LifeOSMediaCenter` gemeldet — inkl. Titel, Künstler, Album,
  Cover, Position, Länge, Lautstärke und Fähigkeiten (Play/Pause,
  Next/Previous, Stop, Seek, SetVolume). Position-Updates werden auf
  ~1 Hz gedrosselt. Der `LifeOSMediaController` aus dem Modul
  unterstützt zusätzlich `stop()`, `seek(positionMs)` und
  `setVolume(volume)`, damit der Host die OS-Bridge (Windows SMTC,
  Linux MPRIS, macOS MPNowPlayingInfoCenter) komplett anbinden kann.
- **System-Media-Controls-Schnittstelle**
  (`com.lifeos.musicplayer.system.SystemMediaControls`) als Alternative
  für Hosts ohne `LifeOSMediaCenter`: Wird beim Modulstart automatisch
  in den `PlaybackController` eingehängt. Ein nativer Adapter kann via
  `MusicPlayerModule.getSystemMediaControls().setNativeBridge(...)`
  registriert werden, ohne den Wiedergabe-Code anzufassen.
- **Agenten-Werkzeuge**: `music_search`, `music_play`, `music_queue_add`,
  `music_pause`, `music_next`, `music_create_playlist`.

## Bauen

```
mvn package
```

Erzeugt `target/lifeos-music-player.jar`. Die LifeOS-Core-Schnittstellen
unter `src/main/java/core/` sind nur Kompilations-Stubs und werden aus dem
finalen JAR ausgeschlossen.

## Speicherort

Alles unter `core.getModuleStoragePath("com.lifeos.musicplayer")`:

- `library.json`, `sources.json`, `playlists.json`, `settings.json`
- `cache/` — gespiegelte NAS-Audiodateien
- `lyrics/<trackId>.txt`

## Host-Integration: OS Media Center

Das Modul publiziert pro Trackwechsel, Statusänderung und im laufenden
Betrieb (gedrosselt auf ~1 Hz) eine `core.LifeOSMediaSession` an
`core.CoreServices.getMediaCenter()`. Die Session enthält alles, was
Windows SMTC, Linux MPRIS und macOS MPNowPlayingInfoCenter brauchen:

| Feld                 | Typ      | Bemerkung                                  |
|----------------------|----------|--------------------------------------------|
| `title`              | String   | `xesam:title` / SMTC `Title`               |
| `artist`             | String   | Display-Name, MPRIS-Array bei Bedarf bauen |
| `album`              | String   | `xesam:album` / SMTC `AlbumTitle`          |
| `coverImagePath`     | String   | lokaler Pfad, in `file://`-URI umwandeln   |
| `positionMs`         | long     | aktuell, in µs für MPRIS umrechnen         |
| `durationMs`         | long     | `mpris:length` (µs) / SMTC `EndTime`       |
| `volume`             | double   | 0..1                                       |
| `playing`            | boolean  | true → `Playing`, false → `Paused`         |
| `canPlayPause`       | boolean  | `CanPlay`/`CanPause`                       |
| `canGoNext/Previous` | boolean  | `CanGoNext`/`CanGoPrevious`                |
| `canChangeVolume`    | boolean  |                                            |
| `canSeek`            | boolean  | `CanSeek`                                  |

Steuerbefehle aus dem OS gehen über den mitgelieferten
`LifeOSMediaController` zurück ins Modul: `playPause`, `next`,
`previous`, `stop`, `seek(positionMs)`, `setVolume(volume)`,
`volumeUp`/`volumeDown`.

### Was der Host bauen muss

- **Windows:** kleine `lifeos-smtc.dll` (C++/WinRT) — ruft
  `SystemMediaTransportControls.GetForCurrentView()` auf, registriert
  Button-Handler und aktualisiert `MusicDisplayProperties`,
  `PlaybackStatus` und `TimelineProperties`. Im Host per JNA geladen,
  Aufrufe in einer konkreten `LifeOSMediaCenter`-Klasse gebündelt.
- **Linux:** pure Java über `dbus-java` 5.x — Host exportiert
  `org.mpris.MediaPlayer2.LifeOS` auf dem Session-Bus, implementiert
  `org.mpris.MediaPlayer2`, `…Player` und `org.freedesktop.DBus.Properties`,
  feuert `PropertiesChanged`, wenn das Modul publiziert.
- **macOS:** JNI-Bridge zu `MPNowPlayingInfoCenter` /
  `MPRemoteCommandCenter` (Objective-C-Dylib).
- **HarmonyOS / Android:** nicht in diesem Modul abbildbar — JavaFX
  läuft dort nicht. Würde eine eigene Mobile-App in
  ArkTS/OpenHarmony-Java mit eigenem `AVSessionManager` brauchen.
