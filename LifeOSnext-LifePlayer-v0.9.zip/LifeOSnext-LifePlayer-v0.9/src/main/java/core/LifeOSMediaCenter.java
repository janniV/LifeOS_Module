package core;

public abstract class LifeOSMediaCenter {
    public abstract void publish(LifeOSMediaSession session, LifeOSMediaController controller);
    public abstract void clear(String moduleId);
}
