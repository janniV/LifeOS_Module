package core;

import javafx.scene.Node;
import java.util.Collections;
import java.util.List;

public interface LifeModule {
    String getModuleName();
    String getModuleId();
    default String getModuleIconPath() { return null; }
    default String getFontIconName() { return "fas-cube"; }
    Node getMainView();
    void onInitialize(CoreServices core);
    void onShutdown();
    ModuleAIContext getAIContext();
    default Node getDashboardWidget() { return null; }
    default List<LifeModule> getSubModules() { return null; }
    default void onUninstall() {}
    default String getRuntimeType() { return "java"; }
    default List<String> getRequestedPermissions() { return Collections.emptyList(); }
    default void onThemeChanged(LifeOSThemeState themeState) {}
}
