package core;

public interface LifeOSMediaController {
    void playPause();
    void previous();
    void next();
    void volumeDown();
    void volumeUp();

    default void stop() {}
    default void seek(long positionMs) {}
    default void setVolume(double volume) {}
}
