package core;
public interface RoadmapService {}
