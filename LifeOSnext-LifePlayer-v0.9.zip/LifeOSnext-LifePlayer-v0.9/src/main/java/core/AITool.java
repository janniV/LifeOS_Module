package core;

import java.util.function.Function;

public class AITool {
    private final String toolName;
    private final String description;
    private final String inputSchema;
    private final AIToolSafety safetyLevel;
    private final boolean requiresConfirmation;
    private final Function<String, String> action;

    public AITool() {
        this("", "", "{}", AIToolSafety.READ_ONLY, false, json -> AgentToolResult.error("not implemented"));
    }

    public AITool(String toolName, String description) {
        this(toolName, description, "{}", AIToolSafety.READ_ONLY, false, json -> AgentToolResult.error("not implemented"));
    }

    public AITool(String toolName, String description, Function<String, String> action) {
        this(toolName, description, "{}", AIToolSafety.READ_ONLY, false, action);
    }

    public AITool(String toolName, String description, String inputSchema) {
        this(toolName, description, inputSchema, AIToolSafety.READ_ONLY, false, json -> AgentToolResult.error("not implemented"));
    }

    public AITool(String toolName, String description, String inputSchema, Function<String, String> action) {
        this(toolName, description, inputSchema, AIToolSafety.READ_ONLY, false, action);
    }

    public AITool(String toolName, String description, String inputSchema, AIToolSafety safetyLevel) {
        this(toolName, description, inputSchema, safetyLevel, false, json -> AgentToolResult.error("not implemented"));
    }

    public AITool(String toolName, String description, String inputSchema, AIToolSafety safetyLevel, Function<String, String> action) {
        this(toolName, description, inputSchema, safetyLevel, false, action);
    }

    public AITool(String toolName, String description, String inputSchema, AIToolSafety safetyLevel, boolean requiresConfirmation) {
        this(toolName, description, inputSchema, safetyLevel, requiresConfirmation, json -> AgentToolResult.error("not implemented"));
    }

    public AITool(String toolName, String description, String inputSchema, AIToolSafety safetyLevel, boolean requiresConfirmation, Function<String, String> action) {
        this.toolName = toolName;
        this.description = description;
        this.inputSchema = inputSchema == null ? "{}" : inputSchema;
        this.safetyLevel = safetyLevel == null ? AIToolSafety.READ_ONLY : safetyLevel;
        this.requiresConfirmation = requiresConfirmation;
        this.action = action == null ? json -> AgentToolResult.error("not implemented") : action;
    }

    public String getToolName()          { return toolName; }
    public String getDescription()       { return description; }
    public String getInputSchema()       { return inputSchema; }
    public AIToolSafety getSafetyLevel() { return safetyLevel; }
    public boolean requiresConfirmation(){ return requiresConfirmation; }

    public String execute(String jsonInput) {
        return action.apply(jsonInput);
    }
}
