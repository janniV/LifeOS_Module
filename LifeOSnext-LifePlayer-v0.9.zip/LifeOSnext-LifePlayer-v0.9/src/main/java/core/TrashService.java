package core;
public interface TrashService {}
