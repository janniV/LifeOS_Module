package core;

import javafx.scene.Node;
import java.nio.file.Path;
import java.util.Collections;
import java.util.List;
import java.util.function.Consumer;

public interface CoreServices {
    void showDialog(String title, Node content);
    void openInNewWindow(LifeModule module);
    void sendNotification(String message);
    Object getGlobalSettings();
    void openModule(String moduleName);
    List<String> getAvailableModules();

    default List<AITool> getAvailableAITools() { return Collections.emptyList(); }
    default List<ModulePermissionTarget> getModulePermissionTargets() { return Collections.emptyList(); }
    default LifeOSThemeState getThemeState() { return new LifeOSThemeState(false, false, false, false, 1.0, ""); }
    default LifeOSMediaCenter getMediaCenter() { return null; }
    default boolean isModulePermissionAllowed(String moduleId, String permission) { return false; }
    default int getSamiraAutomationLevel(String moduleId) { return 0; }
    default String completeWithInternalLLM(String moduleId, String systemPrompt, String userMessage, boolean forceJsonResponse) { return ""; }

    Path getModuleStoragePath(String moduleId);
    default LifeOSFileService getFileService() { return null; }
    default List<LifeOSFileReference> getRemoteFileEntryPoints(String moduleId) { return Collections.emptyList(); }
    default boolean isRemoteFileReferenceAllowed(String moduleId, LifeOSFileReference reference, boolean write) { return false; }

    Object requestSharedData(String dataKey);
    boolean isModuleInstalled(String moduleId);
    void setModuleBadge(String moduleName, int count);
    double getDownloadProgress();
    String getDownloadStatusText();
    boolean isDownloading();
    void startModelDownload(ModelDefinition model, Consumer<Double> onProgress, Runnable onComplete, Consumer<Exception> onError);

    default RoadmapService getRoadmapService() { return null; }
    default TrashService getTrashService() { return null; }
    default AgentRuntimeStore getAgentRuntimeStore() { return null; }
    default void registerModule(LifeModule module) {}
    default void unregisterModule(String moduleName) {}
    default void unregisterModuleSource(Path sourcePath) {}
}
