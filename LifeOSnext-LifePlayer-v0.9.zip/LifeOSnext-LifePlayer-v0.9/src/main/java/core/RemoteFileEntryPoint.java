package core;

public final class RemoteFileEntryPoint {
    private final String providerId;
    private final String label;
    private final String rootPath;

    public RemoteFileEntryPoint(String providerId, String label, String rootPath) {
        this.providerId = providerId;
        this.label = label;
        this.rootPath = rootPath;
    }

    public String getProviderId() { return providerId; }
    public String getLabel() { return label; }
    public String getRootPath() { return rootPath; }

    public LifeOSFileReference toReference(String ownerModuleId) {
        return new LifeOSFileReference(providerId, LifeOSFileReference.Scope.REMOTE, ownerModuleId, rootPath);
    }
}
