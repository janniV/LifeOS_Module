package core;

public final class LifeOSMediaSession {
    private String moduleId = "";
    private String moduleName = "";
    private String title = "";
    private String artist = "";
    private String album = "";
    private String coverImagePath = "";
    private boolean playing;
    private boolean canPlayPause = true;
    private boolean canGoPrevious = true;
    private boolean canGoNext = true;
    private boolean canChangeVolume = true;
    private boolean canSeek;
    private long positionMs;
    private long durationMs;
    private double volume = 1.0;

    public LifeOSMediaSession() {}

    public String getModuleId()        { return moduleId; }
    public void setModuleId(String v)  { this.moduleId = v == null ? "" : v; }
    public String getModuleName()      { return moduleName; }
    public void setModuleName(String v){ this.moduleName = v == null ? "" : v; }
    public String getTitle()           { return title; }
    public void setTitle(String v)     { this.title = v == null ? "" : v; }
    public String getArtist()          { return artist; }
    public void setArtist(String v)    { this.artist = v == null ? "" : v; }
    public String getAlbum()           { return album; }
    public void setAlbum(String v)     { this.album = v == null ? "" : v; }
    public String getCoverImagePath()  { return coverImagePath; }
    public void setCoverImagePath(String v) { this.coverImagePath = v == null ? "" : v; }
    public boolean isPlaying()         { return playing; }
    public void setPlaying(boolean v)  { this.playing = v; }
    public boolean isCanPlayPause()    { return canPlayPause; }
    public void setCanPlayPause(boolean v) { this.canPlayPause = v; }
    public boolean isCanGoPrevious()   { return canGoPrevious; }
    public void setCanGoPrevious(boolean v) { this.canGoPrevious = v; }
    public boolean isCanGoNext()       { return canGoNext; }
    public void setCanGoNext(boolean v){ this.canGoNext = v; }
    public boolean isCanChangeVolume() { return canChangeVolume; }
    public void setCanChangeVolume(boolean v) { this.canChangeVolume = v; }
    public boolean isCanSeek()         { return canSeek; }
    public void setCanSeek(boolean v)  { this.canSeek = v; }
    public long getPositionMs()        { return positionMs; }
    public void setPositionMs(long v)  { this.positionMs = Math.max(0, v); }
    public long getDurationMs()        { return durationMs; }
    public void setDurationMs(long v)  { this.durationMs = Math.max(0, v); }
    public double getVolume()          { return volume; }
    public void setVolume(double v)    { this.volume = Math.max(0.0, Math.min(1.0, v)); }
}
