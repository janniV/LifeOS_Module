package core;

public enum AIToolSafety {
    READ_ONLY, UI_ACTION, USER_DATA_WRITE, DESTRUCTIVE
}
