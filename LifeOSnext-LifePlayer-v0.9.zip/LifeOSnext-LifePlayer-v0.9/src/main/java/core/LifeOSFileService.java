package core;

import java.io.InputStream;
import java.util.List;
import java.util.concurrent.CompletableFuture;

public interface LifeOSFileService {
    List<FileProvider> listProviders();
    FileProvider getProvider(String providerId);

    LifeOSFileReference getModuleDataReference(String moduleId, String relativePath);
    LifeOSFileReference getWorkspaceReference(String relativePath);
    LifeOSFileReference getExportReference(String relativePath);

    LifeOSFileMetadata describe(LifeOSFileReference ref);
    CompletableFuture<LifeOSFileMetadata> describeAsync(LifeOSFileReference ref);

    List<LifeOSFileReference> list(LifeOSFileReference folder);
    CompletableFuture<List<LifeOSFileReference>> listAsync(LifeOSFileReference folder);

    InputStream openReadStream(LifeOSFileReference ref) throws Exception;

    String readText(LifeOSFileReference ref) throws Exception;
    CompletableFuture<String> readTextAsync(LifeOSFileReference ref);
    void writeText(LifeOSFileReference ref, String content) throws Exception;
    void createFolder(LifeOSFileReference folder) throws Exception;

    void attachToObject(LifeOSFileReference ref, String objectKey);
    List<LifeOSFileReference> listAttachments(String objectKey);
    void updateTags(LifeOSFileReference ref, List<String> tags);
}
