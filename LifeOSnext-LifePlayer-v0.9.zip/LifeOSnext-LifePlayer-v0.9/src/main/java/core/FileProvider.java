package core;

public interface FileProvider {
    String getProviderId();
    String getDisplayName();
    boolean isRemote();
}
