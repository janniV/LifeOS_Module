package core;

import java.util.Map;

public final class ThemeState {
    private final boolean darkMode;
    private final String designMode;
    private final boolean sidebarCollapsed;
    private final double fontScale;
    private final Map<String, String> cssVariables;

    public ThemeState(boolean darkMode, String designMode, boolean sidebarCollapsed,
                      double fontScale, Map<String, String> cssVariables) {
        this.darkMode = darkMode;
        this.designMode = designMode;
        this.sidebarCollapsed = sidebarCollapsed;
        this.fontScale = fontScale;
        this.cssVariables = cssVariables;
    }

    public boolean isDarkMode() { return darkMode; }
    public String getDesignMode() { return designMode; }
    public boolean isSidebarCollapsed() { return sidebarCollapsed; }
    public double getFontScale() { return fontScale; }
    public Map<String, String> getCssVariables() { return cssVariables; }
}
