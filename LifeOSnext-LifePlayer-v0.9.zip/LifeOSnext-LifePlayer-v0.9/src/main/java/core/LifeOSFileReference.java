package core;

import java.util.Objects;

public final class LifeOSFileReference {
    public enum Scope { MODULE, WORKSPACE, EXPORT, REMOTE }

    private final String providerId;
    private final Scope scope;
    private final String ownerId;
    private final String relativePath;

    public LifeOSFileReference(String providerId, Scope scope, String ownerId, String relativePath) {
        this.providerId = providerId;
        this.scope = scope;
        this.ownerId = ownerId;
        this.relativePath = relativePath;
    }

    public String getProviderId() { return providerId; }
    public Scope getScope() { return scope; }
    public String getOwnerId() { return ownerId; }
    public String getRelativePath() { return relativePath; }

    public boolean isRemote() { return scope == Scope.REMOTE || "nas".equals(providerId); }

    @Override public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof LifeOSFileReference r)) return false;
        return Objects.equals(providerId, r.providerId)
            && scope == r.scope
            && Objects.equals(ownerId, r.ownerId)
            && Objects.equals(relativePath, r.relativePath);
    }
    @Override public int hashCode() { return Objects.hash(providerId, scope, ownerId, relativePath); }
    @Override public String toString() {
        return providerId + ":" + scope + ":" + ownerId + ":" + relativePath;
    }
}
