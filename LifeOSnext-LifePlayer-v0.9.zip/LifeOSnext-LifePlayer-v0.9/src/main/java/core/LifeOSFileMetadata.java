package core;

import java.time.Instant;
import java.util.List;

public final class LifeOSFileMetadata {
    private final String name;
    private final long size;
    private final boolean directory;
    private final Instant modified;
    private final List<String> tags;
    private final String mimeType;

    public LifeOSFileMetadata(String name, long size, boolean directory,
                              Instant modified, List<String> tags, String mimeType) {
        this.name = name;
        this.size = size;
        this.directory = directory;
        this.modified = modified;
        this.tags = tags;
        this.mimeType = mimeType;
    }

    public String getName() { return name; }
    public long getSize() { return size; }
    public boolean isDirectory() { return directory; }
    public Instant getModified() { return modified; }
    public List<String> getTags() { return tags; }
    public String getMimeType() { return mimeType; }
}
