package core;
public class ModelDefinition {}
