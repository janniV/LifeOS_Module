package core;

public final class AgentToolResult {
    private AgentToolResult() {}

    public static String success(String message) {
        return "{\"status\":\"success\",\"message\":" + quote(message) + "}";
    }

    public static String error(String message) {
        return "{\"status\":\"error\",\"message\":" + quote(message) + "}";
    }

    public static String confirmationRequired(String message) {
        return "{\"status\":\"confirmation_required\",\"message\":" + quote(message) + "}";
    }

    private static String quote(String s) {
        if (s == null) return "null";
        return "\"" + s.replace("\\", "\\\\").replace("\"", "\\\"") + "\"";
    }
}
