package core;

public final class LifeOSThemeState {
    private final boolean darkMode;
    private final boolean sidebarCollapsed;
    private final boolean compactMode;
    private final boolean highContrast;
    private final double fontScale;
    private final String cssVariables;

    public LifeOSThemeState(boolean darkMode, boolean sidebarCollapsed, boolean compactMode,
                             boolean highContrast, double fontScale, String cssVariables) {
        this.darkMode = darkMode;
        this.sidebarCollapsed = sidebarCollapsed;
        this.compactMode = compactMode;
        this.highContrast = highContrast;
        this.fontScale = fontScale;
        this.cssVariables = cssVariables == null ? "" : cssVariables;
    }

    public boolean isDarkMode()        { return darkMode; }
    public boolean isSidebarCollapsed(){ return sidebarCollapsed; }
    public boolean isCompactMode()     { return compactMode; }
    public boolean isHighContrast()    { return highContrast; }
    public double getFontScale()       { return fontScale; }
    public String getCssVariables()    { return cssVariables; }
}
