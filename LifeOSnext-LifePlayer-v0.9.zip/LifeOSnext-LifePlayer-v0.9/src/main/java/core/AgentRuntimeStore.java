package core;
public interface AgentRuntimeStore {}
