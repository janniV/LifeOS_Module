package core;
public class ModulePermissionTarget {}
