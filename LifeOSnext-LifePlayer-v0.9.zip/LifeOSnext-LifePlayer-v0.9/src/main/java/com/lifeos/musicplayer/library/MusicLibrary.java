package com.lifeos.musicplayer.library;

import com.lifeos.musicplayer.model.Album;
import com.lifeos.musicplayer.model.Artist;
import com.lifeos.musicplayer.model.Track;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Comparator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.function.Consumer;

public final class MusicLibrary {
    private final List<Track> tracks = new CopyOnWriteArrayList<>();
    private final List<Consumer<MusicLibrary>> listeners = new CopyOnWriteArrayList<>();

    public List<Track> getTracks() { return tracks; }

    public void addOrReplace(Track track) {
        tracks.removeIf(t -> Objects.equals(t.identityKey(), track.identityKey()));
        tracks.add(track);
        fire();
    }

    public void removeTrack(String id) {
        if (tracks.removeIf(t -> Objects.equals(t.getId(), id))) fire();
    }

    public Track findById(String id) {
        for (Track t : tracks) if (Objects.equals(t.getId(), id)) return t;
        return null;
    }

    public List<Artist> getArtists() {
        Map<String, Artist> byName = new LinkedHashMap<>();
        for (Track t : tracks) {
            String name = t.getDisplayArtist();
            Artist a = byName.computeIfAbsent(name.toLowerCase(), k -> new Artist(name));
            Album album = a.getAlbums().computeIfAbsent(t.getAlbum().toLowerCase(),
                k -> new Album(t.getAlbum(), name));
            album.addTrack(t);
        }
        for (Artist a : byName.values()) for (Album al : a.getAlbums().values()) al.sortTracks();
        List<Artist> sorted = new ArrayList<>(byName.values());
        sorted.sort(Comparator.comparing(Artist::getName, String.CASE_INSENSITIVE_ORDER));
        return sorted;
    }

    public List<Album> getAlbums() {
        // Gruppierung:
        //  - Wenn ein Track einen expliziten Album-Künstler (TPE2/album-
        //    artist) hat, gruppieren wir per (album, albumArtist). Das ist
        //    der ID3-Standard für Compilations ("Various Artists" etc.).
        //  - Wenn KEIN Album-Künstler gesetzt ist, gruppieren wir nur per
        //    Albumname. Damit landen Compilations, deren Tags nur den
        //    Track-Artist tragen, trotzdem als EIN Album zusammen.
        Map<String, Album> byKey = new LinkedHashMap<>();
        for (Track t : tracks) {
            String albumArtist = t.getAlbumArtist();
            boolean hasAlbumArtist = albumArtist != null && !albumArtist.isBlank();
            String groupKey = hasAlbumArtist
                ? Album.key(t.getAlbum(), albumArtist)
                : "album-only::" + (t.getAlbum() == null ? "" : t.getAlbum().toLowerCase());
            String displayArtist = hasAlbumArtist ? albumArtist : "Various Artists";
            Album album = byKey.computeIfAbsent(groupKey,
                k -> new Album(t.getAlbum(), displayArtist));
            album.addTrack(t);
        }
        // Bei reinen "Various Artists"-Gruppen den Artist erst nach dem
        // Sammeln entscheiden: wenn ALLE Tracks denselben Artist haben,
        // zeigen wir den, sonst "Various Artists".
        for (Album a : byKey.values()) {
            if ("Various Artists".equals(a.getArtist()) && !a.getTracks().isEmpty()) {
                String first = a.getTracks().get(0).getDisplayArtist();
                boolean allSame = true;
                for (Track t : a.getTracks()) {
                    if (!first.equalsIgnoreCase(t.getDisplayArtist())) { allSame = false; break; }
                }
                if (allSame) a.overrideArtist(first);
            }
            a.sortTracks();
        }
        List<Album> sorted = new ArrayList<>(byKey.values());
        sorted.sort(Comparator
            .comparing(Album::getName, String.CASE_INSENSITIVE_ORDER)
            .thenComparing(Album::getArtist, String.CASE_INSENSITIVE_ORDER));
        return sorted;
    }

    public List<Track> search(String query) {
        String q = query == null ? "" : query.trim().toLowerCase();
        if (q.isEmpty()) return new ArrayList<>(tracks);
        List<Track> out = new ArrayList<>();
        for (Track t : tracks) {
            if (t.getTitle().toLowerCase().contains(q)
                || t.getArtist().toLowerCase().contains(q)
                || t.getAlbumArtist().toLowerCase().contains(q)
                || t.getAlbum().toLowerCase().contains(q)
                || t.getGenre().toLowerCase().contains(q)) {
                out.add(t);
            }
        }
        return out;
    }

    public void replaceAll(Collection<Track> newTracks) {
        tracks.clear();
        tracks.addAll(newTracks);
        fire();
    }

    public void addListener(Consumer<MusicLibrary> l) { listeners.add(l); }
    public void removeListener(Consumer<MusicLibrary> l) { listeners.remove(l); }

    public void fire() { for (Consumer<MusicLibrary> l : listeners) l.accept(this); }
}
