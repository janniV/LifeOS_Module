package com.lifeos.musicplayer.ui;

import com.lifeos.musicplayer.library.CoverArtService;
import com.lifeos.musicplayer.library.MusicLibrary;
import com.lifeos.musicplayer.model.Album;
import com.lifeos.musicplayer.model.Artist;
import com.lifeos.musicplayer.model.Track;
import com.lifeos.musicplayer.playback.PlaybackController;
import javafx.application.Platform;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.geometry.Insets;
import javafx.scene.control.Label;
import javafx.scene.control.ListView;
import javafx.scene.control.SplitPane;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.VBox;

import java.util.ArrayList;
import java.util.List;

public final class ArtistsTab extends SplitPane {

    private final ObservableList<Artist> artists = FXCollections.observableArrayList();
    private ListView<Artist> listViewRef;

    public void showArtistDetail(String artistName) {
        for (Artist a : artists) {
            if (a.getName().equalsIgnoreCase(artistName)) {
                if (listViewRef != null) listViewRef.getSelectionModel().select(a);
                break;
            }
        }
    }

    public ArtistsTab(MusicLibrary library, PlaybackController controller, CoverArtService covers) {
        ListView<Artist> list = new ListView<>(artists);
        this.listViewRef = list;
        list.setCellFactory(lv -> new javafx.scene.control.ListCell<>() {
            @Override protected void updateItem(Artist a, boolean empty) {
                super.updateItem(a, empty);
                setText(empty || a == null ? null : a.getName() + "  (" + a.getTrackCount() + ")");
            }
        });

        BorderPane right = new BorderPane();
        right.setPadding(new Insets(12));
        Label hint = new Label("Wähle eine:n Künstler:in.");
        right.setCenter(hint);

        list.getSelectionModel().selectedItemProperty().addListener((obs, o, n) -> {
            if (n == null) { right.setCenter(hint); return; }
            VBox v = new VBox(12);
            for (Album al : n.getAlbums().values()) {
                v.getChildren().add(new AlbumCard(al, controller, covers));
            }
            javafx.scene.control.ScrollPane sp = new javafx.scene.control.ScrollPane(v);
            sp.setFitToWidth(true);
            right.setCenter(sp);
        });

        getItems().addAll(list, right);
        setDividerPositions(0.28);

        library.addListener(lib -> Platform.runLater(() -> refresh(lib)));
        refresh(library);
    }

    private void refresh(MusicLibrary lib) {
        List<Artist> a = new ArrayList<>(lib.getArtists());
        artists.setAll(a);
    }
}
