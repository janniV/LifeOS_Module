package com.lifeos.musicplayer.model;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Objects;

public final class Album {
    private final String name;
    private String artist;
    private final List<Track> tracks = new ArrayList<>();
    private int year;

    public Album(String name, String artist) {
        this.name = name == null ? "" : name;
        this.artist = artist == null ? "" : artist;
    }

    public String getName() { return name; }
    public String getArtist() { return artist; }

    /** Nachträgliche Korrektur, wenn z. B. die "Various Artists"-Heuristik
     *  doch einen eindeutigen gemeinsamen Künstler findet. */
    public void overrideArtist(String newArtist) {
        this.artist = newArtist == null ? "" : newArtist;
    }
    public List<Track> getTracks() { return tracks; }
    public int getYear() { return year; }

    public void addTrack(Track t) {
        tracks.add(t);
        if (t.getYear() > 0 && (year == 0 || t.getYear() < year)) year = t.getYear();
    }

    public void sortTracks() {
        tracks.sort(Comparator
            .comparingInt(Track::getDiscNumber)
            .thenComparingInt(Track::getTrackNumber)
            .thenComparing(Track::getTitle, String.CASE_INSENSITIVE_ORDER));
    }

    public long getTotalDurationMs() {
        long sum = 0;
        for (Track t : tracks) sum += t.getDurationMs();
        return sum;
    }

    public String getKey() { return key(name, artist); }

    public static String key(String name, String artist) {
        return (name == null ? "" : name.toLowerCase()) + ""
             + (artist == null ? "" : artist.toLowerCase());
    }

    @Override public boolean equals(Object o) {
        return o instanceof Album a && Objects.equals(getKey(), a.getKey());
    }
    @Override public int hashCode() { return Objects.hash(getKey()); }
}
