package com.lifeos.musicplayer.playback;

import com.lifeos.musicplayer.model.Track;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.function.Consumer;

public final class PlaybackQueue {
    private final List<Track> tracks = new ArrayList<>();
    private final List<Consumer<PlaybackQueue>> listeners = new CopyOnWriteArrayList<>();
    private int currentIndex = -1;
    private boolean shuffle;
    private RepeatMode repeat = RepeatMode.OFF;

    public List<Track> getTracks() { return tracks; }
    public int getCurrentIndex() { return currentIndex; }

    public Track getCurrent() {
        if (currentIndex < 0 || currentIndex >= tracks.size()) return null;
        return tracks.get(currentIndex);
    }

    public void setTracks(Collection<Track> newTracks, int startIndex) {
        tracks.clear();
        tracks.addAll(newTracks);
        currentIndex = newTracks.isEmpty() ? -1 : Math.max(0, Math.min(startIndex, tracks.size() - 1));
        fire();
    }

    public void append(Track t) { tracks.add(t); fire(); }
    public void appendAll(Collection<Track> ts) { tracks.addAll(ts); fire(); }

    public void playNow(Track t) {
        tracks.add(currentIndex + 1, t);
        currentIndex++;
        fire();
    }

    public void remove(int idx) {
        if (idx < 0 || idx >= tracks.size()) return;
        tracks.remove(idx);
        if (idx < currentIndex) currentIndex--;
        else if (idx == currentIndex && currentIndex >= tracks.size()) currentIndex = tracks.size() - 1;
        fire();
    }

    public void clear() { tracks.clear(); currentIndex = -1; fire(); }

    public boolean isShuffle() { return shuffle; }
    public void setShuffle(boolean shuffle) {
        this.shuffle = shuffle;
        if (shuffle) {
            Track cur = getCurrent();
            Collections.shuffle(tracks);
            if (cur != null) {
                tracks.remove(cur);
                tracks.add(0, cur);
                currentIndex = 0;
            }
        }
        fire();
    }

    public RepeatMode getRepeat() { return repeat; }
    public void setRepeat(RepeatMode r) { this.repeat = r; fire(); }

    public Track next(boolean autoAdvance) {
        if (tracks.isEmpty()) return null;
        if (repeat == RepeatMode.ONE && autoAdvance) return getCurrent();
        if (currentIndex + 1 < tracks.size()) {
            currentIndex++;
        } else if (repeat == RepeatMode.ALL) {
            currentIndex = 0;
        } else {
            return null;
        }
        fire();
        return getCurrent();
    }

    public Track previous() {
        if (tracks.isEmpty()) return null;
        if (currentIndex > 0) currentIndex--;
        else if (repeat == RepeatMode.ALL) currentIndex = tracks.size() - 1;
        fire();
        return getCurrent();
    }

    public void jumpTo(int idx) {
        if (idx < 0 || idx >= tracks.size()) return;
        currentIndex = idx;
        fire();
    }

    public void addListener(Consumer<PlaybackQueue> l) { listeners.add(l); }
    public void removeListener(Consumer<PlaybackQueue> l) { listeners.remove(l); }
    public void fire() { for (Consumer<PlaybackQueue> l : listeners) l.accept(this); }
}
