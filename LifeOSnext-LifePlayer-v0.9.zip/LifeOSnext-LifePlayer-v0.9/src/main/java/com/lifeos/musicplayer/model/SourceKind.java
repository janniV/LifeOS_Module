package com.lifeos.musicplayer.model;

public enum SourceKind {
    LOCAL,
    NAS,
    LIFEOS_WORKSPACE,
    LIFEOS_MODULE;

    public static SourceKind fromRefKind(RefKind k) {
        if (k == null) return LIFEOS_MODULE;
        return switch (k) {
            case LOCAL -> LOCAL;
            case NAS -> NAS;
            case WORKSPACE -> LIFEOS_WORKSPACE;
            case MODULE_DATA, EXPORT -> LIFEOS_MODULE;
        };
    }

    public String displayLabel() {
        return switch (this) {
            case LOCAL -> "Lokal";
            case NAS -> "NAS";
            case LIFEOS_WORKSPACE -> "LifeOS Workspace";
            case LIFEOS_MODULE -> "LifeOS Modulspeicher";
        };
    }
}
