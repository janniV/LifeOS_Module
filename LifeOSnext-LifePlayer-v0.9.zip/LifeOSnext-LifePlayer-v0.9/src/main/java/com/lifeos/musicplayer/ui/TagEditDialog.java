package com.lifeos.musicplayer.ui;

import com.lifeos.musicplayer.library.LibraryStore;
import com.lifeos.musicplayer.library.MusicLibrary;
import com.lifeos.musicplayer.model.Album;
import com.lifeos.musicplayer.model.Track;
import javafx.geometry.Insets;
import javafx.scene.control.ButtonType;
import javafx.scene.control.Dialog;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.GridPane;

import java.util.Optional;

public final class TagEditDialog {

    private TagEditDialog() {}

    /** Editiert Titel/Künstler/Album/Jahr eines einzelnen Tracks. */
    public static void editTrack(Track track, MusicLibrary library, LibraryStore store) {
        if (track == null) return;
        Dialog<Boolean> dialog = new Dialog<>();
        dialog.setTitle("Titel bearbeiten");
        dialog.setHeaderText(track.getTitle());

        TextField title  = new TextField(track.getTitle());
        TextField artist = new TextField(track.getArtist());
        TextField album  = new TextField(track.getAlbum());
        TextField year   = new TextField(track.getYear() > 0 ? String.valueOf(track.getYear()) : "");
        title.setPrefColumnCount(28);

        GridPane grid = new GridPane();
        grid.setHgap(10); grid.setVgap(8); grid.setPadding(new Insets(14, 18, 6, 18));
        grid.add(new Label("Titel"),     0, 0); grid.add(title,  1, 0);
        grid.add(new Label("Künstler"),  0, 1); grid.add(artist, 1, 1);
        grid.add(new Label("Album"),     0, 2); grid.add(album,  1, 2);
        grid.add(new Label("Jahr"),      0, 3); grid.add(year,   1, 3);

        dialog.getDialogPane().setContent(grid);
        dialog.getDialogPane().getButtonTypes().addAll(ButtonType.OK, ButtonType.CANCEL);
        dialog.setResultConverter(bt -> bt == ButtonType.OK);

        Optional<Boolean> result = dialog.showAndWait();
        if (result.isPresent() && result.get()) {
            track.setTitle(title.getText().trim());
            track.setArtist(artist.getText().trim());
            track.setAlbum(album.getText().trim());
            try { track.setYear(year.getText().isBlank() ? 0 : Integer.parseInt(year.getText().trim())); }
            catch (NumberFormatException ignored) {}
            persist(library, store);
        }
    }

    /** Editiert Albumname und Album-Künstler — wird auf ALLE Tracks
     *  des Albums angewendet, damit das Album als Einheit erhalten bleibt. */
    public static void editAlbum(Album album, MusicLibrary library, LibraryStore store) {
        if (album == null || album.getTracks().isEmpty()) return;
        Dialog<Boolean> dialog = new Dialog<>();
        dialog.setTitle("Album bearbeiten");
        dialog.setHeaderText(album.getName());

        TextField name   = new TextField(album.getName());
        TextField artist = new TextField(album.getArtist());
        TextField year   = new TextField(album.getYear() > 0 ? String.valueOf(album.getYear()) : "");
        name.setPrefColumnCount(28);

        GridPane grid = new GridPane();
        grid.setHgap(10); grid.setVgap(8); grid.setPadding(new Insets(14, 18, 6, 18));
        grid.add(new Label("Albumname"),  0, 0); grid.add(name,   1, 0);
        grid.add(new Label("Künstler"),   0, 1); grid.add(artist, 1, 1);
        grid.add(new Label("Jahr"),       0, 2); grid.add(year,   1, 2);
        grid.add(new Label("Wirkt auf " + album.getTracks().size() + " Titel"), 0, 3, 2, 1);

        dialog.getDialogPane().setContent(grid);
        dialog.getDialogPane().getButtonTypes().addAll(ButtonType.OK, ButtonType.CANCEL);
        dialog.setResultConverter(bt -> bt == ButtonType.OK);

        Optional<Boolean> result = dialog.showAndWait();
        if (result.isPresent() && result.get()) {
            String newName   = name.getText().trim();
            String newArtist = artist.getText().trim();
            int newYear;
            try { newYear = year.getText().isBlank() ? 0 : Integer.parseInt(year.getText().trim()); }
            catch (NumberFormatException ex) { newYear = 0; }
            for (Track t : album.getTracks()) {
                t.setAlbum(newName);
                t.setAlbumArtist(newArtist);
                if (newYear > 0) t.setYear(newYear);
            }
            persist(library, store);
        }
    }

    private static void persist(MusicLibrary library, LibraryStore store) {
        if (store != null) {
            try { store.saveTracks(library.getTracks()); } catch (Exception ignored) {}
        }
        library.fire();
    }
}
