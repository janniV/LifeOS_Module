package com.lifeos.musicplayer.playback;

import javafx.application.Platform;
import javafx.scene.media.Media;
import javafx.scene.media.MediaPlayer;
import javafx.util.Duration;

import java.nio.file.Path;

public final class JfxPlaybackEngine implements PlaybackEngine {

    private MediaPlayer player;
    private Listener listener = new Listener() {};
    private double volume = 0.8;
    private PlaybackState state = PlaybackState.IDLE;

    @Override
    public void load(Path localFile) {
        Platform.runLater(() -> {
            disposeInternal();
            try {
                Media media = new Media(localFile.toUri().toString());
                player = new MediaPlayer(media);
                player.setVolume(volume);
                player.setOnReady(() -> notifyPosition());
                player.setOnPlaying(() -> setState(PlaybackState.PLAYING));
                player.setOnPaused(() -> setState(PlaybackState.PAUSED));
                player.setOnStopped(() -> setState(PlaybackState.STOPPED));
                player.setOnEndOfMedia(() -> {
                    setState(PlaybackState.STOPPED);
                    listener.onEndReached();
                });
                player.setOnError(() -> {
                    setState(PlaybackState.ERROR);
                    listener.onError(player.getError() == null ? "Unbekannter Fehler"
                        : player.getError().getMessage());
                });
                player.currentTimeProperty().addListener((obs, o, n) -> notifyPosition());
            } catch (Exception e) {
                setState(PlaybackState.ERROR);
                listener.onError("MediaPlayer konnte Datei nicht laden: " + e.getMessage());
            }
        });
    }

    private void notifyPosition() {
        if (player == null) return;
        long pos = (long) player.getCurrentTime().toMillis();
        Duration d = player.getTotalDuration();
        long dur = d == null || d.isUnknown() || d.isIndefinite() ? 0 : (long) d.toMillis();
        listener.onPositionChanged(pos, dur);
    }

    private void setState(PlaybackState s) {
        this.state = s;
        listener.onStateChanged(s);
    }

    @Override public void play()  { Platform.runLater(() -> { if (player != null) player.play(); }); }
    @Override public void pause() { Platform.runLater(() -> { if (player != null) player.pause(); }); }
    @Override public void stop()  { Platform.runLater(() -> { if (player != null) player.stop(); }); }

    @Override public void seek(long positionMs) {
        Platform.runLater(() -> { if (player != null) player.seek(Duration.millis(positionMs)); });
    }

    @Override public void setVolume(double v) {
        this.volume = Math.max(0, Math.min(1, v));
        Platform.runLater(() -> { if (player != null) player.setVolume(volume); });
    }

    @Override public double getVolume() { return volume; }

    @Override public long getPositionMs() {
        return player == null ? 0 : (long) player.getCurrentTime().toMillis();
    }

    @Override public long getDurationMs() {
        if (player == null) return 0;
        Duration d = player.getTotalDuration();
        return d == null || d.isUnknown() || d.isIndefinite() ? 0 : (long) d.toMillis();
    }

    @Override public PlaybackState getState() { return state; }

    @Override public void setListener(Listener l) { this.listener = l == null ? new Listener() {} : l; }

    @Override public void dispose() {
        Platform.runLater(this::disposeInternal);
    }

    private void disposeInternal() {
        if (player != null) {
            try { player.dispose(); } catch (Exception ignored) {}
            player = null;
        }
    }
}
