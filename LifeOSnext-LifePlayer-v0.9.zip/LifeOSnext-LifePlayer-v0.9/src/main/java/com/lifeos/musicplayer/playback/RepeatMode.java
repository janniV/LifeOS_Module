package com.lifeos.musicplayer.playback;

public enum RepeatMode { OFF, ONE, ALL }
