package com.lifeos.musicplayer.ui;

import atlantafx.base.theme.Styles;
import atlantafx.base.theme.Tweaks;
import com.lifeos.musicplayer.library.LibraryScanner;
import com.lifeos.musicplayer.library.LibraryStore;
import com.lifeos.musicplayer.library.MusicLibrary;
import com.lifeos.musicplayer.library.NasCache;
import com.lifeos.musicplayer.model.ModuleSettings;
import com.lifeos.musicplayer.model.MusicSource;
import com.lifeos.musicplayer.model.RefKind;
import com.lifeos.musicplayer.model.SourceKind;
import com.lifeos.musicplayer.model.Track;
import core.CoreServices;
import core.LifeOSFileReference;
import javafx.application.Platform;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.*;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Priority;
import javafx.scene.layout.Region;
import javafx.scene.layout.VBox;
import javafx.stage.DirectoryChooser;
import javafx.stage.Window;

import java.io.File;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.function.Consumer;

public final class SourcesSettingsView extends BorderPane {

    private final ObservableList<MusicSource> sourceItems = FXCollections.observableArrayList();
    private final MusicLibrary library;
    private final LibraryStore store;
    private final NasCache cache;
    private final CoreServices core;
    private final String moduleId;
    private final ProgressBar progress = new ProgressBar(0);
    private final Label statusLabel = new Label("Bereit.");
    private LibraryScanner currentScanner;
    private ModuleSettings settings;
    private Consumer<ModuleSettings> onSettingsChanged = s -> {};

    public SourcesSettingsView(MusicLibrary library, LibraryStore store, NasCache cache,
                               CoreServices core, String moduleId, List<MusicSource> sources) {
        this(library, store, cache, core, moduleId, sources, new ModuleSettings(), s -> {});
    }

    public SourcesSettingsView(MusicLibrary library, LibraryStore store, NasCache cache,
                               CoreServices core, String moduleId, List<MusicSource> sources,
                               ModuleSettings settings, Consumer<ModuleSettings> onSettingsChanged) {
        this.library = library;
        this.store = store;
        this.cache = cache;
        this.core = core;
        this.moduleId = moduleId;
        this.settings = settings == null ? new ModuleSettings() : settings;
        this.onSettingsChanged = onSettingsChanged == null ? s -> {} : onSettingsChanged;
        sourceItems.setAll(sources);
        getStyleClass().addAll("music-root", "music-settings");
        attachStylesheet();

        VBox stack = new VBox(0, buildHeader(), buildAppearance(), buildList());
        VBox.setVgrow(stack.getChildren().get(2), Priority.ALWAYS);
        setCenter(stack);
        setBottom(buildFooter());
        setPadding(new Insets(0));
        setPrefSize(760, 580);
    }

    private VBox buildAppearance() {
        Label title = new Label("Darstellung");
        title.getStyleClass().addAll("music-settings-section-title", Styles.TITLE_4);

        Label desc = new Label("Wo die Modul-Sidebar erscheinen soll.");
        desc.getStyleClass().addAll(Styles.TEXT_MUTED);

        ToggleButton left = new ToggleButton("Links");
        left.setGraphic(Icons.sidebarLeft(14));
        ToggleButton right = new ToggleButton("Rechts");
        right.setGraphic(Icons.sidebarRight(14));
        ToggleGroup grp = new ToggleGroup();
        left.setToggleGroup(grp);
        right.setToggleGroup(grp);
        left.getStyleClass().add("music-segment-button");
        right.getStyleClass().add("music-segment-button");

        boolean isLeft = settings.getSidebarPosition() == ModuleSettings.SidebarPosition.LEFT;
        left.setSelected(isLeft);
        right.setSelected(!isLeft);

        left.setOnAction(e -> {
            if (!left.isSelected()) { left.setSelected(true); return; }
            settings.setSidebarPosition(ModuleSettings.SidebarPosition.LEFT);
            store.saveSettings(settings);
            onSettingsChanged.accept(settings);
        });
        right.setOnAction(e -> {
            if (!right.isSelected()) { right.setSelected(true); return; }
            settings.setSidebarPosition(ModuleSettings.SidebarPosition.RIGHT);
            store.saveSettings(settings);
            onSettingsChanged.accept(settings);
        });

        HBox segment = new HBox(0, left, right);
        segment.setAlignment(Pos.CENTER_LEFT);
        segment.getStyleClass().add("music-segment");

        Label sidebarLabel = new Label("Sidebar-Position");
        sidebarLabel.getStyleClass().add(Styles.TEXT_BOLD);

        HBox row = new HBox(16, sidebarLabel, segment);
        row.setAlignment(Pos.CENTER_LEFT);

        VBox box = new VBox(8, title, desc, row);
        box.setPadding(new Insets(18, 24, 18, 24));
        box.getStyleClass().add("music-settings-section");
        return box;
    }

    private VBox buildHeader() {
        Label title = new Label("Quellordner");
        title.getStyleClass().addAll("music-settings-title", Styles.TITLE_3);

        Label desc = new Label("Lege fest, wo der Player nach Musik suchen soll. "
            + "Neue Ordner werden direkt nach dem Hinzufügen einmal eingelesen.");
        desc.setWrapText(true);
        desc.getStyleClass().addAll("music-settings-desc", Styles.TEXT_MUTED);

        MenuButton add = new MenuButton("Quelle hinzufügen");
        add.getStyleClass().addAll("music-settings-add", Styles.ACCENT);

        MenuItem local = new MenuItem("Lokaler Ordner (Windows / Datenträger)");
        local.setOnAction(e -> safeRun("chooseLocal", () ->
            chooseLocalFolder(getScene() == null ? null : getScene().getWindow())));
        add.getItems().add(local);

        Menu nasMenu = new Menu("NAS-Ordner");
        rebuildNasMenu(nasMenu);
        nasMenu.setOnShowing(e -> rebuildNasMenu(nasMenu));
        add.getItems().add(nasMenu);

        MenuItem workspace = new MenuItem("LifeOS-Workspace-Ordner …");
        workspace.setOnAction(e -> safeRun("addWorkspace", () -> addManagedSource(RefKind.WORKSPACE)));
        add.getItems().add(workspace);

        MenuItem modStorage = new MenuItem("LifeOS-Modulspeicher (privat) …");
        modStorage.setOnAction(e -> safeRun("addModuleData", () -> addManagedSource(RefKind.MODULE_DATA)));
        add.getItems().add(modStorage);

        HBox titleRow = new HBox(12, title, spacer(), add);
        titleRow.setAlignment(Pos.CENTER_LEFT);

        VBox header = new VBox(8, titleRow, desc);
        header.setPadding(new Insets(22, 24, 14, 24));
        header.getStyleClass().add("music-settings-header");
        return header;
    }

    private ListView<MusicSource> buildList() {
        ListView<MusicSource> list = new ListView<>(sourceItems);
        list.getStyleClass().addAll("music-sources-list", Tweaks.EDGE_TO_EDGE);
        list.setPlaceholder(new Label("Noch keine Quellen. Füge oben einen Ordner hinzu."));
        list.setCellFactory(lv -> new SourceCell());
        return list;
    }

    private HBox buildFooter() {
        progress.setPrefWidth(220);
        progress.getStyleClass().add(Styles.SMALL);
        Button rescanAll = new Button("Alle neu scannen");
        rescanAll.setOnAction(e -> rescanAll());
        Button cancelBtn = new Button("Abbrechen");
        cancelBtn.getStyleClass().add(Styles.FLAT);
        cancelBtn.setOnAction(e -> { if (currentScanner != null) currentScanner.cancel(); });
        statusLabel.getStyleClass().add(Styles.TEXT_MUTED);
        HBox bar = new HBox(12, progress, statusLabel, spacer(), cancelBtn, rescanAll);
        bar.setAlignment(Pos.CENTER_LEFT);
        bar.setPadding(new Insets(14, 24, 18, 24));
        bar.getStyleClass().add("music-settings-footer");
        return bar;
    }

    private Region spacer() {
        Region r = new Region();
        HBox.setHgrow(r, Priority.ALWAYS);
        return r;
    }

    private void attachStylesheet() {
        try {
            String css = getClass().getResource("/com/lifeos/musicplayer/music-player.css").toExternalForm();
            sceneProperty().addListener((obs, oldS, newS) -> {
                if (newS != null && !newS.getStylesheets().contains(css)) {
                    newS.getStylesheets().add(css);
                }
            });
        } catch (Exception ignored) {}
    }

    private void rebuildNasMenu(Menu menu) {
        menu.getItems().clear();
        List<LifeOSFileReference> roots = List.of();
        if (core == null) {
            System.err.println("[MusicPlayer] rebuildNasMenu: CoreServices ist null");
            disabledItem(menu, "Core-Dienst nicht verfügbar");
            return;
        }
        try {
            roots = core.getRemoteFileEntryPoints(moduleId);
            System.err.println("[MusicPlayer] getRemoteFileEntryPoints(" + moduleId + ") -> "
                + (roots == null ? "null" : roots.size() + " Eintrag/Einträge"));
            if (roots != null) for (LifeOSFileReference r : roots) System.err.println("    • " + r);
        } catch (Exception e) {
            System.err.println("[MusicPlayer] getRemoteFileEntryPoints failed: " + e);
            e.printStackTrace();
            disabledItem(menu, "Fehler beim Laden: " + e.getMessage());
            return;
        }
        if (roots == null || roots.isEmpty()) {
            disabledItem(menu, "Keine NAS-Einstiege für dieses Modul freigegeben");
            disabledItem(menu, "    (LifeOS → Einstellungen → NAS-Ordner)");
            return;
        }
        for (LifeOSFileReference root : roots) {
            String label = nasMenuLabel(root);
            MenuItem add = new MenuItem(label + "  (gesamten Ordner)");
            add.setOnAction(e -> safeRun("addNas:root", () -> addNasSource(root, null)));
            menu.getItems().add(add);
            MenuItem sub = new MenuItem("        … Unterordner wählen …");
            sub.setOnAction(e -> safeRun("addNas:sub", () -> askSubpathAndAddNas(root)));
            menu.getItems().add(sub);
        }
    }

    private void disabledItem(Menu menu, String text) {
        MenuItem mi = new MenuItem(text);
        mi.setDisable(true);
        menu.getItems().add(mi);
    }

    private static String nasMenuLabel(LifeOSFileReference root) {
        String displayName = MusicSource.displayNameOf(root);
        if (displayName != null && !displayName.isBlank()) {
            return displayName;
        }
        String path;
        try { path = root.getRelativePath(); }
        catch (Throwable t) {
            try { return String.valueOf(root); } catch (Throwable t2) { return "?"; }
        }
        if (path == null || path.isBlank()) {
            try { return String.valueOf(root); } catch (Throwable t) { return "?"; }
        }
        int marker = path.indexOf("nas_roots/");
        if (marker >= 0) {
            String uuid = path.substring(marker + "nas_roots/".length());
            if (uuid.length() > 12) uuid = uuid.substring(0, 8) + "…";
            return "NAS-Root " + uuid;
        }
        if (path.length() > 48) path = path.substring(0, 24) + "…" + path.substring(path.length() - 20);
        return path;
    }

    private void askSubpathAndAddNas(LifeOSFileReference root) {
        TextInputDialog d = new TextInputDialog();
        d.setTitle("NAS-Unterordner");
        d.setHeaderText("Pfad unterhalb von " + nasMenuLabel(root));
        d.setContentText("Relativer Unterpfad:");
        d.showAndWait().filter(s -> !s.isBlank()).ifPresent(sub -> addNasSource(root, sub.trim()));
    }

    private void addNasSource(LifeOSFileReference root, String subPath) {
        System.err.println("[MusicPlayer] addNasSource: root=" + root + " subPath=" + subPath);
        String rootPath;
        try { rootPath = root.getRelativePath(); }
        catch (Throwable t) { rootPath = String.valueOf(root); }
        String displayLabel = (subPath == null || subPath.isBlank())
            ? MusicSource.displayNameOf(root)
            : "NAS: " + lastSegment(subPath);
        if (displayLabel == null || displayLabel.isBlank()) {
            displayLabel = "NAS: " + lastSegment(rootPath);
        }
        MusicSource s;
        try {
            s = MusicSource.ofNas(root, displayLabel);
        } catch (Throwable t) {
            System.err.println("[MusicPlayer] MusicSource.ofNas warf: " + t);
            t.printStackTrace();
            statusLabel.setText("Fehler beim Anlegen der Quelle: " + t.getMessage());
            return;
        }
        if (subPath != null && !subPath.isBlank()) s.setSubPath(subPath);
        sourceItems.add(s);
        System.err.println("[MusicPlayer] Quelle hinzugefügt, persistiere …");
        try { persistSources(); }
        catch (Throwable t) {
            System.err.println("[MusicPlayer] persistSources warf: " + t);
            t.printStackTrace();
        }
        System.err.println("[MusicPlayer] starte rescan");
        rescan(s);
    }

    private void addManagedSource(RefKind kind) {
        if (core == null || core.getFileService() == null) {
            statusLabel.setText("LifeOS-Dateidienst nicht verfügbar.");
            return;
        }
        boolean isWorkspace = kind == RefKind.WORKSPACE;
        TextInputDialog d = new TextInputDialog("Musik");
        d.setTitle(isWorkspace ? "Workspace-Ordner" : "Modul-Ordner");
        d.setHeaderText(isWorkspace
            ? "Pfad innerhalb des LifeOS-Workspace:"
            : "Pfad innerhalb des Modul-Speichers:");
        d.setContentText("Relativer Pfad:");
        d.showAndWait().filter(s -> !s.isBlank()).ifPresent(path -> {
            String trimmed = path.trim();
            LifeOSFileReference ref = isWorkspace
                ? core.getFileService().getWorkspaceReference(trimmed)
                : core.getFileService().getModuleDataReference(moduleId, trimmed);
            if (ref == null) {
                statusLabel.setText("Pfad konnte nicht aufgelöst werden.");
                return;
            }
            String label = (isWorkspace ? "Workspace: " : "Modul: ") + lastSegment(trimmed);
            MusicSource s = isWorkspace
                ? MusicSource.ofWorkspace(trimmed, label)
                : MusicSource.ofModuleData(trimmed, label);
            sourceItems.add(s);
            persistSources();
            rescan(s);
        });
    }

    private void chooseLocalFolder(Window owner) {
        DirectoryChooser dc = new DirectoryChooser();
        dc.setTitle("Lokalen Musikordner wählen");
        File picked = dc.showDialog(owner);
        if (picked == null) return;
        MusicSource s = MusicSource.ofLocal(picked);
        sourceItems.add(s);
        persistSources();
        rescan(s);
    }

    public void rescanAll() {
        new Thread(() -> {
            for (MusicSource s : new ArrayList<>(sourceItems)) {
                rescanBlocking(s);
            }
        }, "music-rescan-all").start();
    }

    public void rescan(MusicSource s) {
        Thread t = new Thread(() -> {
            try { rescanBlocking(s); }
            catch (Throwable th) {
                System.err.println("[MusicPlayer] rescan-Thread crash: " + th);
                th.printStackTrace();
                Platform.runLater(() -> statusLabel.setText("Scan-Fehler: " + th.getMessage()));
            }
        }, "music-rescan");
        t.setDaemon(true);
        t.start();
    }

    private void rescanBlocking(MusicSource s) {
        if (core == null) {
            System.err.println("[MusicPlayer] rescanBlocking: core ist null, abbrechen");
            return;
        }
        System.err.println("[MusicPlayer] rescanBlocking start für: " + s.getLabel()
            + " (kind=" + s.getKind() + ", path=" + s.getPath() + ")");
        currentScanner = new LibraryScanner(core.getFileService(), cache, moduleId, core);
        Platform.runLater(() -> {
            progress.setProgress(ProgressBar.INDETERMINATE_PROGRESS);
            statusLabel.setText("Scanne: " + s.getLabel());
        });
        List<Track> found = currentScanner.scan(s, new LibraryScanner.ProgressCallback() {
            @Override public void onProgress(String currentItem, int done, int total) {
                Platform.runLater(() -> {
                    if (total > 0) progress.setProgress(done / (double) total);
                    statusLabel.setText(currentItem + (total > 0 ? "  (" + done + "/" + total + ")" : ""));
                });
            }
            @Override public void onError(String message) {
                System.err.println("[MusicPlayer] scan-error: " + message);
                Platform.runLater(() -> statusLabel.setText("Fehler: " + message));
            }
        });
        System.err.println("[MusicPlayer] rescanBlocking: " + found.size() + " Tracks gefunden");
        List<Track> merged = new ArrayList<>(library.getTracks());
        for (Track t : found) {
            String key = t.identityKey();
            merged.removeIf(x -> Objects.equals(x.identityKey(), key));
            merged.add(t);
        }
        library.replaceAll(merged);
        store.saveTracks(merged);
        persistSources();
        Platform.runLater(() -> {
            progress.setProgress(1.0);
            statusLabel.setText(found.size() + " Titel von " + s.getLabel() + " indexiert.");
        });
    }

    public List<MusicSource> getSources() { return new ArrayList<>(sourceItems); }

    private void persistSources() {
        store.saveSources(new ArrayList<>(sourceItems));
    }

    private static String lastSegment(String path) {
        if (path == null || path.isBlank()) return "";
        String cleaned = path.replace('\\', '/');
        int slash = cleaned.lastIndexOf('/');
        return slash < 0 ? cleaned : cleaned.substring(slash + 1);
    }

    private void safeRun(String tag, Runnable r) {
        System.err.println("[MusicPlayer] UI-Aktion: " + tag);
        try { r.run(); }
        catch (Throwable t) {
            System.err.println("[MusicPlayer] UI-Aktion '" + tag + "' warf: " + t);
            t.printStackTrace();
            statusLabel.setText("Fehler: " + t.getMessage());
        }
    }

    private final class SourceCell extends ListCell<MusicSource> {
        @Override protected void updateItem(MusicSource s, boolean empty) {
            super.updateItem(s, empty);
            if (empty || s == null) { setText(null); setGraphic(null); return; }
            SourceKind k = s.getKindResolved();
            Label kindBadge = new Label(k.displayLabel());
            kindBadge.getStyleClass().addAll("music-source-badge", "music-source-badge-" + k.name().toLowerCase());

            String displayName = s.getLabel() == null || s.getLabel().isBlank() ? lastSegment(s.getDisplayPath()) : s.getLabel();
            Label name = new Label(displayName);
            name.getStyleClass().addAll("music-source-name", Styles.TEXT_BOLD);

            Label path = new Label(s.getDisplayPath());
            path.getStyleClass().addAll("music-source-path", Styles.TEXT_SMALL, Styles.TEXT_MUTED);

            String stats = (s.getTrackCount() > 0 ? s.getTrackCount() + " Titel" : "noch nicht gescannt")
                + (s.getLastScannedEpochMs() > 0
                    ? "  ·  zuletzt " + Formatting.relativeTime(s.getLastScannedEpochMs())
                    : "");
            Label statsLabel = new Label(stats);
            statsLabel.getStyleClass().addAll("music-source-stats", Styles.TEXT_SMALL, Styles.TEXT_SUBTLE);

            VBox lines = new VBox(3, new HBox(8, kindBadge, name), path, statsLabel);
            lines.setAlignment(Pos.CENTER_LEFT);

            Button rescan = new Button("Scannen");
            rescan.getStyleClass().add(Styles.FLAT);
            rescan.setOnAction(e -> rescan(s));

            Button remove = new Button("Entfernen");
            remove.getStyleClass().addAll(Styles.FLAT, Styles.DANGER);
            remove.setOnAction(e -> {
                sourceItems.remove(s);
                persistSources();
            });

            HBox row = new HBox(12, lines, spacer(), rescan, remove);
            row.setAlignment(Pos.CENTER_LEFT);
            row.setPadding(new Insets(12, 16, 12, 16));
            row.getStyleClass().add("music-source-row");
            setGraphic(row);
            setText(null);
        }
    }
}
