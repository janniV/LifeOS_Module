package com.lifeos.musicplayer.ui;

import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Node;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Priority;
import javafx.scene.layout.Region;
import javafx.scene.layout.VBox;

import java.util.ArrayList;
import java.util.List;
import java.util.function.Consumer;

public final class MusicSidebar extends VBox {

    public enum Entry {
        RECENT("Zuletzt hinzugefügt", "clock"),
        ARTISTS("Künstler:innen", "artist"),
        ALBUMS("Alben", "album"),
        TRACKS("Titel", "track"),
        GENRES("Genres", "genres"),
        NEW_PLAYLIST("Neue Playlist", "plus"),
        FAVORITES("Lieblingssongs", "heart");

        public final String label;
        public final String iconKey;
        Entry(String l, String i) { this.label = l; this.iconKey = i; }
    }

    private final List<EntryRow> rows = new ArrayList<>();
    private Entry active = Entry.ALBUMS;
    private final TextField search = new TextField();
    private Consumer<Entry> onSelect = e -> {};
    private Consumer<String> onSearch = s -> {};

    public MusicSidebar() {
        getStyleClass().add("music-sidebar");
        setSpacing(6);
        setPadding(new Insets(16, 14, 16, 14));
        setMinWidth(220);
        setPrefWidth(232);
        setMaxWidth(260);

        search.setPromptText("Suchen");
        search.getStyleClass().add("music-sidebar-search");
        HBox searchBox = new HBox(8, Icons.search(14), search);
        searchBox.setAlignment(Pos.CENTER_LEFT);
        searchBox.getStyleClass().add("music-sidebar-search-box");
        HBox.setHgrow(search, Priority.ALWAYS);
        search.textProperty().addListener((obs, o, n) -> onSearch.accept(n));

        Label libHeader = sectionHeader("BIBLIOTHEK");

        EntryRow recent   = entryRow(Entry.RECENT);
        EntryRow artists  = entryRow(Entry.ARTISTS);
        EntryRow albums   = entryRow(Entry.ALBUMS);
        EntryRow tracks   = entryRow(Entry.TRACKS);
        EntryRow genres   = entryRow(Entry.GENRES);

        Label plHeader = sectionHeader("PLAYLISTS");
        plHeader.setPadding(new Insets(14, 8, 6, 8));

        EntryRow newPl    = entryRow(Entry.NEW_PLAYLIST);
        EntryRow favs     = entryRow(Entry.FAVORITES);

        Region pad = new Region();
        pad.setMinHeight(8);

        getChildren().addAll(
            searchBox,
            pad,
            libHeader, recent, artists, albums, tracks, genres,
            plHeader, newPl, favs
        );
        setActive(Entry.ALBUMS);
    }

    public void setOnSelect(Consumer<Entry> handler) {
        this.onSelect = handler == null ? e -> {} : handler;
    }

    public void setOnSearch(Consumer<String> handler) {
        this.onSearch = handler == null ? s -> {} : handler;
    }

    public void setActive(Entry e) {
        this.active = e;
        for (EntryRow r : rows) r.refresh(e);
    }

    public Entry getActive() { return active; }

    private Label sectionHeader(String text) {
        Label l = new Label(text);
        l.getStyleClass().add("music-sidebar-section");
        l.setPadding(new Insets(8, 8, 4, 8));
        return l;
    }

    private EntryRow entryRow(Entry e) {
        EntryRow row = new EntryRow(e);
        row.refresh(active);
        row.setOnMouseClicked((MouseEvent ev) -> {
            setActive(e);
            onSelect.accept(e);
        });
        rows.add(row);
        return row;
    }

    private static Node iconFor(Entry e) {
        return switch (e.iconKey) {
            case "clock"   -> Icons.clock(16);
            case "artist"  -> Icons.artist(16);
            case "album"   -> Icons.album(16);
            case "track"   -> Icons.track(16);
            case "genres"  -> Icons.genres(16);
            case "plus"    -> Icons.plus(16);
            case "heart"   -> Icons.heart(16);
            default        -> Icons.musicNote(16);
        };
    }

    private static final class EntryRow extends HBox {
        private final Entry entry;
        EntryRow(Entry e) {
            this.entry = e;
            setSpacing(10);
            setAlignment(Pos.CENTER_LEFT);
            setPadding(new Insets(8, 12, 8, 12));
            Label label = new Label(e.label);
            label.setMouseTransparent(true);
            label.getStyleClass().add("music-sidebar-entry-label");
            Node icon = iconFor(e);
            if (icon != null) icon.setMouseTransparent(true);
            getChildren().addAll(icon, label);
            getStyleClass().add("music-sidebar-entry");
            setCursor(javafx.scene.Cursor.HAND);
        }
        void refresh(Entry active) {
            if (entry == active) {
                if (!getStyleClass().contains("active")) getStyleClass().add("active");
            } else {
                getStyleClass().remove("active");
            }
        }
    }
}
