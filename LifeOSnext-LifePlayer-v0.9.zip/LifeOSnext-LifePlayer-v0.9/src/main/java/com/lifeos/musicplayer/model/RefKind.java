package com.lifeos.musicplayer.model;

/**
 * Modul-eigene Variante von core.LifeOSFileReference.Scope.
 *
 * Der echte LifeOS-Core hat keine innere {@code Scope}-Enum (Stub und reale
 * Implementierung passten nicht zusammen). Damit wir nie versehentlich die
 * innere Klasse des Cores referenzieren und einen NoClassDefFoundError
 * auslösen, halten wir die Kind-Information ausschließlich in dieser
 * lokalen Enum.
 */
public enum RefKind {
    LOCAL,
    NAS,
    WORKSPACE,
    MODULE_DATA,
    EXPORT
}
