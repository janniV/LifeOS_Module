package com.lifeos.musicplayer.ui;

public final class Formatting {
    private Formatting() {}

    public static String time(long ms) {
        if (ms < 0) ms = 0;
        long total = ms / 1000;
        long h = total / 3600;
        long m = (total % 3600) / 60;
        long s = total % 60;
        return h > 0 ? String.format("%d:%02d:%02d", h, m, s)
                     : String.format("%d:%02d", m, s);
    }

    public static String relativeTime(long epochMs) {
        if (epochMs <= 0) return "nie";
        long diff = System.currentTimeMillis() - epochMs;
        if (diff < 0) return "gerade eben";
        long s = diff / 1000;
        if (s < 60) return "gerade eben";
        long m = s / 60;
        if (m < 60) return m + " Min";
        long h = m / 60;
        if (h < 24) return h + " Std";
        long d = h / 24;
        if (d < 30) return d + " Tag" + (d == 1 ? "" : "e");
        long mo = d / 30;
        if (mo < 12) return mo + " Monat" + (mo == 1 ? "" : "e");
        return (mo / 12) + " Jahr" + (mo / 12 == 1 ? "" : "e");
    }
}
