package com.lifeos.musicplayer.ui;

import com.lifeos.musicplayer.library.CoverArtService;
import com.lifeos.musicplayer.model.Track;
import com.lifeos.musicplayer.playback.PlaybackController;
import com.lifeos.musicplayer.playback.PlaybackState;
import javafx.application.Platform;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.ProgressBar;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;

public final class DashboardWidget extends VBox {

    public DashboardWidget(PlaybackController controller, CoverArtService covers) {
        setSpacing(6);
        setPadding(new Insets(12));
        getStyleClass().add("music-dashboard");

        CoverView cover = new CoverView(covers, 120);
        cover.setAlignment(Pos.CENTER);
        Label title = new Label("—");
        title.setStyle("-fx-font-weight: bold;");
        Label artist = new Label("");
        artist.setStyle("-fx-opacity: 0.8;");
        ProgressBar progress = new ProgressBar(0);
        progress.setMaxWidth(Double.MAX_VALUE);

        Button prev = new Button("⏮");
        Button play = new Button("▶");
        Button next = new Button("⏭");
        prev.setOnAction(e -> controller.previous());
        play.setOnAction(e -> controller.togglePlay());
        next.setOnAction(e -> controller.next());

        HBox controls = new HBox(6, prev, play, next);
        controls.setAlignment(Pos.CENTER);

        HBox coverRow = new HBox(cover);
        coverRow.setAlignment(Pos.CENTER);
        setAlignment(Pos.TOP_CENTER);
        getChildren().addAll(new Label("Musik"), coverRow, title, artist, progress, controls);

        controller.addListener(new PlaybackController.Listener() {
            @Override public void onTrackChanged(Track t) {
                Platform.runLater(() -> {
                    title.setText(t == null ? "—" : t.getTitle());
                    artist.setText(t == null ? "" : t.getDisplayArtist());
                    cover.showTrack(t);
                });
            }
            @Override public void onStateChanged(PlaybackState s) {
                Platform.runLater(() -> play.setText(s == PlaybackState.PLAYING ? "⏸" : "▶"));
            }
            @Override public void onPosition(long pos, long dur) {
                Platform.runLater(() -> progress.setProgress(dur > 0 ? pos / (double) dur : 0));
            }
        });
    }
}
