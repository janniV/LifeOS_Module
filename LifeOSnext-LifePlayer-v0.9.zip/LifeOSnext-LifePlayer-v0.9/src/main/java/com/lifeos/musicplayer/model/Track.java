package com.lifeos.musicplayer.model;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import core.CoreServices;
import core.LifeOSFileReference;
import core.LifeOSFileService;

import java.io.File;
import java.util.List;
import java.util.Objects;
import java.util.UUID;

@JsonIgnoreProperties(ignoreUnknown = true)
public final class Track {
    private String id = UUID.randomUUID().toString();
    private String title = "";
    private String artist = "";
    private String albumArtist = "";
    private String album = "";
    private String genre = "";
    private int year;
    private int trackNumber;
    private int discNumber;
    private long durationMs;
    private String format = "";

    private RefKind refKind = RefKind.LOCAL;
    /** LOCAL: absoluter Pfad. Managed: gespeicherter Anzeigepfad. */
    private String filePath = "";
    /** Schlüssel zur Wiederfindung der LifeOSFileReference im Core (managed). */
    private String refKey = "";
    /** Pfad innerhalb der Quelle (z.B. relativ zu einer NAS-Wurzel). */
    private String fileSubPath = "";
    /** Schlüssel der Quell-Root, damit wir die Track-Referenz beim Wieder-Auflösen
        an der zugehörigen MusicSource-Wurzel ankoppeln können. */
    private String sourceRefKey = "";

    private long sizeBytes;
    private long addedAtEpochMs = System.currentTimeMillis();
    private long lastPlayedEpochMs;
    private int playCount;

    @JsonIgnore
    private transient LifeOSFileReference cachedRef;

    public Track() {}

    /** Setzt eine vom Core gelieferte Referenz. Für LOCAL nutze {@link #setLocalFile}. */
    public void setManagedReference(LifeOSFileReference ref, RefKind kind, String sourceKey) {
        if (ref == null) return;
        this.refKind = kind;
        this.cachedRef = ref;
        this.refKey = MusicSource.stableReferenceKey(ref);
        this.sourceRefKey = sourceKey == null ? "" : sourceKey;
        try { this.filePath = ref.getRelativePath(); } catch (Throwable t) { this.filePath = String.valueOf(ref); }
    }

    public void setLocalFile(File file) {
        this.refKind = RefKind.LOCAL;
        this.filePath = file.getAbsolutePath();
        this.cachedRef = null;
        this.refKey = "";
    }

    @JsonIgnore
    public LifeOSFileReference resolve(CoreServices core, String moduleId) {
        if (refKind == RefKind.LOCAL) return null;
        if (cachedRef != null) return cachedRef;
        if (core == null) return null;
        LifeOSFileService fs = core.getFileService();
        switch (refKind) {
            case NAS -> {
                try {
                    List<LifeOSFileReference> roots = core.getRemoteFileEntryPoints(moduleId);
                    if (roots == null) return null;
                    for (LifeOSFileReference r : roots) {
                        if (matchesSourceRoot(r)) {
                            cachedRef = referenceWithPath(r, filePath);
                            return cachedRef;
                        }
                    }
                } catch (Exception ignored) {}
                return null;
            }
            case WORKSPACE -> { return fs == null ? null : (cachedRef = fs.getWorkspaceReference(filePath)); }
            case MODULE_DATA -> { return fs == null ? null : (cachedRef = fs.getModuleDataReference(moduleId, filePath)); }
            case EXPORT -> { return fs == null ? null : (cachedRef = fs.getExportReference(filePath)); }
            default -> { return null; }
        }
    }

    @JsonIgnore
    public File getLocalFile() {
        return refKind == RefKind.LOCAL && filePath != null ? new File(filePath) : null;
    }

    /** Identitätsschlüssel für Dedup: localPath für LOCAL, refKey sonst. */
    @JsonIgnore
    public String identityKey() {
        if (refKind == RefKind.LOCAL) return "local:" + filePath;
        return refKind + ":" + refKey;
    }

    @JsonIgnore
    public boolean isLocal()  { return refKind == RefKind.LOCAL; }
    @JsonIgnore
    public boolean isRemote() { return refKind == RefKind.NAS; }

    private boolean matchesSourceRoot(LifeOSFileReference root) {
        if (root == null) return false;
        String sourceKey = sourceRefKey == null ? "" : sourceRefKey;
        if (!sourceKey.isBlank()) {
            if (sourceKey.equals(MusicSource.stableReferenceKey(root))) return true;
            if (sourceKey.equals(String.valueOf(root))) return true;
        }
        String rootPath = invokeString(root, "getRelativePath");
        return rootPath != null && !rootPath.isBlank()
            && filePath != null && filePath.startsWith(rootPath);
    }

    private static LifeOSFileReference referenceWithPath(LifeOSFileReference template, String relativePath) {
        if (template == null || relativePath == null || relativePath.isBlank()) return template;
        try {
            Object scope = template.getClass().getMethod("getScope").invoke(template);
            Object created = template.getClass()
                .getConstructor(String.class, scope.getClass(), String.class, String.class)
                .newInstance(
                    invokeString(template, "getProviderId"),
                    scope,
                    invokeString(template, "getOwnerId"),
                    relativePath
                );
            if (created instanceof LifeOSFileReference ref) return ref;
        } catch (Throwable ignored) {}
        return template;
    }

    private static String invokeString(Object target, String method) {
        if (target == null) return "";
        try {
            Object value = target.getClass().getMethod(method).invoke(target);
            return value == null ? "" : value.toString();
        } catch (Throwable ignored) {
            return "";
        }
    }

    public String getId() { return id; }
    public void setId(String id) { this.id = id; }
    public String getTitle() { return title; }
    public void setTitle(String title) { this.title = title == null ? "" : title; }
    public String getArtist() { return artist; }
    public void setArtist(String artist) { this.artist = artist == null ? "" : artist; }
    public String getAlbumArtist() { return albumArtist; }
    public void setAlbumArtist(String albumArtist) { this.albumArtist = albumArtist == null ? "" : albumArtist; }
    public String getAlbum() { return album; }
    public void setAlbum(String album) { this.album = album == null ? "" : album; }
    public String getGenre() { return genre; }
    public void setGenre(String genre) { this.genre = genre == null ? "" : genre; }
    public int getYear() { return year; }
    public void setYear(int year) { this.year = year; }
    public int getTrackNumber() { return trackNumber; }
    public void setTrackNumber(int v) { this.trackNumber = v; }
    public int getDiscNumber() { return discNumber; }
    public void setDiscNumber(int v) { this.discNumber = v; }
    public long getDurationMs() { return durationMs; }
    public void setDurationMs(long v) { this.durationMs = v; }
    public String getFormat() { return format; }
    public void setFormat(String format) { this.format = format == null ? "" : format.toLowerCase(); }

    public RefKind getRefKind() { return refKind; }
    public void setRefKind(RefKind refKind) { this.refKind = refKind == null ? RefKind.LOCAL : refKind; }
    public String getFilePath() { return filePath; }
    public void setFilePath(String filePath) { this.filePath = filePath == null ? "" : filePath; }
    public String getRefKey() { return refKey; }
    public void setRefKey(String refKey) { this.refKey = refKey == null ? "" : refKey; }
    public String getFileSubPath() { return fileSubPath; }
    public void setFileSubPath(String fileSubPath) { this.fileSubPath = fileSubPath == null ? "" : fileSubPath; }
    public String getSourceRefKey() { return sourceRefKey; }
    public void setSourceRefKey(String sourceRefKey) { this.sourceRefKey = sourceRefKey == null ? "" : sourceRefKey; }

    public long getSizeBytes() { return sizeBytes; }
    public void setSizeBytes(long v) { this.sizeBytes = v; }
    public long getAddedAtEpochMs() { return addedAtEpochMs; }
    public void setAddedAtEpochMs(long v) { this.addedAtEpochMs = v; }
    public long getLastPlayedEpochMs() { return lastPlayedEpochMs; }
    public void setLastPlayedEpochMs(long v) { this.lastPlayedEpochMs = v; }
    public int getPlayCount() { return playCount; }
    public void setPlayCount(int v) { this.playCount = v; }

    public String getDisplayArtist() {
        return albumArtist != null && !albumArtist.isBlank() ? albumArtist : artist;
    }

    @Override public boolean equals(Object o) {
        return o instanceof Track t && Objects.equals(id, t.id);
    }
    @Override public int hashCode() { return Objects.hash(id); }
}
