package com.lifeos.musicplayer.ui;

import atlantafx.base.theme.Styles;
import atlantafx.base.theme.Tweaks;
import com.lifeos.musicplayer.library.MusicLibrary;
import com.lifeos.musicplayer.model.Track;
import com.lifeos.musicplayer.playback.PlaybackController;
import javafx.application.Platform;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;

import java.util.function.Consumer;

public final class TracksTab extends BorderPane {

    private final ObservableList<Track> rows = FXCollections.observableArrayList();
    private final FilteredTableHelper filter = new FilteredTableHelper();
    private Consumer<String> onAlbumClick;
    private Consumer<String> onArtistClick;

    public void setOnAlbumClick(Consumer<String> consumer) { this.onAlbumClick = consumer; }
    public void setOnArtistClick(Consumer<String> consumer) { this.onArtistClick = consumer; }

    public TracksTab(MusicLibrary library, PlaybackController controller) {
        TableView<Track> table = new TableView<>();
        table.getStyleClass().addAll("music-table", Styles.STRIPED, Tweaks.EDGE_TO_EDGE, Tweaks.ALIGN_LEFT);
        table.setPlaceholder(new Label("Noch keine Titel — füge oben eine Quelle hinzu."));
        TableColumn<Track, String> cTitle = column("Titel", "title", 280);

        TableColumn<Track, String> cArtist = column("Künstler:in", "displayArtist", 200);
        cArtist.setCellFactory(c -> new TableCell<>() {
            @Override protected void updateItem(String item, boolean empty) {
                super.updateItem(item, empty);
                if (empty || item == null) {
                    setGraphic(null);
                    setText(null);
                } else {
                    Label l = new Label(item);
                    l.setStyle("-fx-cursor: hand; -fx-underline: true;");
                    l.setOnMouseClicked(e -> {
                        if (onArtistClick != null) onArtistClick.accept(item);
                    });
                    setGraphic(l);
                    setText(null);
                }
            }
        });

        TableColumn<Track, String> cAlbum = column("Album", "album", 220);
        cAlbum.setCellFactory(c -> new TableCell<>() {
            @Override protected void updateItem(String item, boolean empty) {
                super.updateItem(item, empty);
                if (empty || item == null) {
                    setGraphic(null);
                    setText(null);
                } else {
                    Label l = new Label(item);
                    l.setStyle("-fx-cursor: hand; -fx-underline: true;");
                    l.setOnMouseClicked(e -> {
                        if (onAlbumClick != null) onAlbumClick.accept(item);
                    });
                    setGraphic(l);
                    setText(null);
                }
            }
        });

        TableColumn<Track, Integer> cYear = column("Jahr", "year", 70);
        TableColumn<Track, String> cFormat = column("Format", "format", 80);
        TableColumn<Track, Long> cDur = new TableColumn<>("Dauer");
        cDur.setCellValueFactory(new PropertyValueFactory<>("durationMs"));
        cDur.setCellFactory(c -> new TableCell<>() {
            @Override protected void updateItem(Long v, boolean empty) {
                super.updateItem(v, empty);
                setText(empty || v == null ? "" : Formatting.time(v));
            }
        });
        cDur.setPrefWidth(80);
        table.getColumns().addAll(cTitle, cArtist, cAlbum, cYear, cFormat, cDur);
        table.setItems(rows);
        table.setRowFactory(tv -> {
            TableRow<Track> row = new TableRow<>();
            row.setOnMouseClicked(e -> {
                if (e.getClickCount() == 2 && !row.isEmpty()) {
                    controller.playAll(rows, row.getIndex());
                }
            });
            return row;
        });

        TextField search = new TextField();
        search.getStyleClass().add("music-search-field");
        search.setPromptText("Suche Titel, Künstler:in oder Album …");
        search.textProperty().addListener((obs, o, n) -> refresh(library, n));

        HBox top = new HBox(8, search);
        top.getStyleClass().add("music-search-row");
        setTop(top);
        setCenter(table);

        library.addListener(lib -> Platform.runLater(() -> refresh(lib, search.getText())));
        refresh(library, "");
    }

    private void refresh(MusicLibrary lib, String q) {
        var list = lib.search(q == null ? "" : q);
        list.sort((a, b) -> a.getTitle().compareToIgnoreCase(b.getTitle()));
        rows.setAll(list);
    }

    private <T> TableColumn<Track, T> column(String name, String prop, double width) {
        TableColumn<Track, T> c = new TableColumn<>(name);
        c.setCellValueFactory(new PropertyValueFactory<>(prop));
        c.setPrefWidth(width);
        return c;
    }

    private static final class FilteredTableHelper {}
}
