package com.lifeos.musicplayer.ui;

import com.lifeos.musicplayer.library.CoverArtService;
import com.lifeos.musicplayer.model.Album;
import com.lifeos.musicplayer.model.Track;
import javafx.application.Platform;
import javafx.scene.canvas.Canvas;
import javafx.scene.canvas.GraphicsContext;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.StackPane;
import javafx.scene.paint.Color;
import javafx.scene.paint.LinearGradient;
import javafx.scene.paint.Stop;
import javafx.scene.shape.Rectangle;
import javafx.scene.text.Font;
import javafx.scene.text.TextAlignment;

import java.nio.file.Path;
import java.util.concurrent.CompletableFuture;

public final class CoverView extends StackPane {

    private final CoverArtService covers;
    private final ImageView imageView = new ImageView();
    private final Canvas placeholder;
    private final double size;
    private final double cornerRadius;

    public CoverView(CoverArtService covers, double size) {
        this(covers, size, Math.max(4, size * 0.08));
    }

    public CoverView(CoverArtService covers, double size, double cornerRadius) {
        this.covers = covers;
        this.size = size;
        this.cornerRadius = cornerRadius;
        this.placeholder = new Canvas(size, size);
        imageView.setFitWidth(size);
        imageView.setFitHeight(size);
        imageView.setPreserveRatio(false);
        imageView.setSmooth(true);
        Rectangle clip = new Rectangle(size, size);
        clip.setArcWidth(cornerRadius * 2);
        clip.setArcHeight(cornerRadius * 2);
        imageView.setClip(new Rectangle(size, size) {{
            setArcWidth(cornerRadius * 2);
            setArcHeight(cornerRadius * 2);
        }});
        setClip(clip);
        setPrefSize(size, size);
        setMinSize(size, size);
        setMaxSize(size, size);
        getStyleClass().add("music-cover");
        getChildren().add(placeholder);
    }

    public void showAlbum(Album album) {
        clearImage(album == null ? "" : album.getName(),
                   album == null ? "" : album.getArtist());
        if (album == null) return;
        Path quick = album.getTracks().isEmpty() ? null
            : covers.lookup(album.getTracks().get(0));
        if (quick != null) { setImage(quick); return; }
        CompletableFuture.runAsync(() -> {
            Path p = covers.getForAlbum(album);
            if (p != null) Platform.runLater(() -> setImage(p));
        });
    }

    public void showTrack(Track track) {
        clearImage(track == null ? "" : track.getAlbum(),
                   track == null ? "" : track.getDisplayArtist());
        if (track == null) return;
        Path quick = covers.lookup(track);
        if (quick != null) { setImage(quick); return; }
        CompletableFuture.runAsync(() -> {
            Path p = covers.getOrExtract(track);
            if (p != null) Platform.runLater(() -> setImage(p));
        });
    }

    private void setImage(Path p) {
        try {
            Image img = new Image(p.toUri().toString(), size, size, false, true, true);
            imageView.setImage(img);
            // Placeholder bleibt darunter sichtbar, bis das Bild asynchron
            // dekodiert ist und ImageView ihn verdeckt.
            getChildren().setAll(placeholder, imageView);
        } catch (Exception ignored) {}
    }

    private void clearImage(String album, String artist) {
        imageView.setImage(null);
        drawPlaceholder(album, artist);
        getChildren().setAll(placeholder);
    }

    private void drawPlaceholder(String album, String artist) {
        GraphicsContext g = placeholder.getGraphicsContext2D();
        g.clearRect(0, 0, size, size);
        long seed = ((album == null ? "" : album).toLowerCase()
                  + "" + (artist == null ? "" : artist).toLowerCase()).hashCode();
        double hue = Math.floorMod(seed, 360);
        Color c1 = Color.hsb(hue, 0.45, 0.55);
        Color c2 = Color.hsb((hue + 40) % 360, 0.55, 0.30);
        g.setFill(new LinearGradient(0, 0, 1, 1, true,
            javafx.scene.paint.CycleMethod.NO_CYCLE,
            new Stop(0, c1), new Stop(1, c2)));
        g.fillRect(0, 0, size, size);

        String letter = "♪";
        if (album != null && !album.isBlank()) letter = album.substring(0, 1).toUpperCase();
        else if (artist != null && !artist.isBlank()) letter = artist.substring(0, 1).toUpperCase();
        g.setFill(Color.color(1, 1, 1, 0.88));
        g.setFont(Font.font(size * 0.45));
        g.setTextAlign(TextAlignment.CENTER);
        g.fillText(letter, size / 2.0, size * 0.62);
    }
}
