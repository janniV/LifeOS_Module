package com.lifeos.musicplayer.playback;

import org.bytedeco.ffmpeg.global.avutil;
import org.bytedeco.javacv.FFmpegFrameGrabber;
import org.bytedeco.javacv.Frame;
import org.bytedeco.javacv.FrameGrabber;

import javax.sound.sampled.AudioFormat;
import javax.sound.sampled.AudioSystem;
import javax.sound.sampled.DataLine;
import javax.sound.sampled.FloatControl;
import javax.sound.sampled.SourceDataLine;
import java.nio.Buffer;
import java.nio.ShortBuffer;
import java.nio.file.Path;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicLong;

/**
 * Wiedergabe-Engine auf Basis von FFmpeg (via JavaCPP / JavaCV).
 * Dekodiert alles, was FFmpeg lesen kann, nach 16-bit PCM und spielt
 * es über javax.sound.sampled ab. Ab v0.9 die primäre Engine — ersetzt
 * den JavaFX-MediaPlayer und macht den jflac-Fallback überflüssig.
 */
public final class FFmpegPlaybackEngine implements PlaybackEngine {

    static {
        // FFmpeg-Logging dämpfen; wir reichen Fehler über den Listener weiter.
        try { avutil.av_log_set_level(avutil.AV_LOG_ERROR); } catch (Throwable ignored) {}
    }

    private final AtomicBoolean paused = new AtomicBoolean();
    private final AtomicBoolean stopRequested = new AtomicBoolean();
    private final AtomicLong positionMs = new AtomicLong();
    private final AtomicLong durationMs = new AtomicLong();
    private final AtomicLong seekTargetMs = new AtomicLong(-1);

    private Path file;
    private Thread playThread;
    private volatile SourceDataLine line;
    private volatile FFmpegFrameGrabber grabber;
    private volatile Listener listener = new Listener() {};
    private volatile double volume = 0.8;
    private volatile PlaybackState state = PlaybackState.IDLE;

    @Override
    public void load(Path localFile) {
        stop();
        this.file = localFile;
        positionMs.set(0);
        // Vor dem ersten Frame haben wir noch keine echte Dauer. setKnownDurationMs
        // darf vom Controller schon vorher gerufen werden und wird beibehalten,
        // bis FFmpeg in runPlayback() den exakten Wert kennt.
        setState(PlaybackState.IDLE);
    }

    @Override
    public void setKnownDurationMs(long ms) {
        if (ms > 0) durationMs.set(ms);
    }

    @Override
    public synchronized void play() {
        if (state == PlaybackState.PAUSED && playThread != null && playThread.isAlive()) {
            paused.set(false);
            synchronized (paused) { paused.notifyAll(); }
            setState(PlaybackState.PLAYING);
            return;
        }
        if (file == null) return;
        stopRequested.set(false);
        paused.set(false);
        playThread = new Thread(this::runPlayback, "FFmpegPlayback");
        playThread.setDaemon(true);
        playThread.start();
    }

    @Override
    public void pause() {
        if (state == PlaybackState.PLAYING) {
            paused.set(true);
            setState(PlaybackState.PAUSED);
        }
    }

    @Override
    public synchronized void stop() {
        stopRequested.set(true);
        paused.set(false);
        synchronized (paused) { paused.notifyAll(); }
        SourceDataLine l = this.line;
        if (l != null) {
            try { l.stop(); } catch (Exception ignored) {}
        }
        Thread t = this.playThread;
        if (t != null) {
            try { t.join(1500); } catch (InterruptedException ignored) {}
            this.playThread = null;
        }
        closeResources();
        positionMs.set(0);
        if (state != PlaybackState.ERROR) setState(PlaybackState.STOPPED);
    }

    @Override
    public void seek(long target) {
        seekTargetMs.set(Math.max(0, target));
    }

    @Override
    public void setVolume(double v) {
        this.volume = Math.max(0, Math.min(1, v));
        applyVolume();
    }

    private void applyVolume() {
        SourceDataLine l = this.line;
        if (l == null) return;
        try {
            if (l.isControlSupported(FloatControl.Type.MASTER_GAIN)) {
                FloatControl gain = (FloatControl) l.getControl(FloatControl.Type.MASTER_GAIN);
                float dB = (float) (volume <= 0.0001 ? gain.getMinimum() : 20.0 * Math.log10(volume));
                gain.setValue(Math.max(gain.getMinimum(), Math.min(gain.getMaximum(), dB)));
            }
        } catch (Exception ignored) {}
    }

    @Override public double getVolume()   { return volume; }
    @Override public long getPositionMs() { return positionMs.get(); }
    @Override public long getDurationMs() { return durationMs.get(); }
    @Override public PlaybackState getState() { return state; }
    @Override public void setListener(Listener l) { this.listener = l == null ? new Listener() {} : l; }
    @Override public void dispose() { stop(); }

    private void runPlayback() {
        FFmpegFrameGrabber local = null;
        SourceDataLine localLine = null;
        try {
            setState(PlaybackState.BUFFERING);

            local = new FFmpegFrameGrabber(file.toFile());
            local.setSampleMode(FrameGrabber.SampleMode.SHORT);
            local.start();
            this.grabber = local;

            int channels = local.getAudioChannels();
            int sampleRate = local.getSampleRate();
            if (channels <= 0 || sampleRate <= 0) {
                throw new Exception("Audio-Parameter ungültig (Kanäle=" + channels
                                    + ", Rate=" + sampleRate + ")");
            }

            long durUs = local.getLengthInTime();
            if (durUs > 0) durationMs.set(durUs / 1000);

            AudioFormat format = new AudioFormat(
                AudioFormat.Encoding.PCM_SIGNED,
                sampleRate, 16, channels,
                channels * 2, sampleRate,
                false  // little endian: passt zu FFmpegs AV_SAMPLE_FMT_S16-Ausgabe
            );

            DataLine.Info info = new DataLine.Info(SourceDataLine.class, format);
            localLine = (SourceDataLine) AudioSystem.getLine(info);
            localLine.open(format);
            this.line = localLine;
            applyVolume();
            localLine.start();

            setState(PlaybackState.PLAYING);

            byte[] writeBuf = new byte[8192];

            while (!stopRequested.get()) {
                while (paused.get() && !stopRequested.get()) {
                    synchronized (paused) {
                        try { paused.wait(200); }
                        catch (InterruptedException e) { Thread.currentThread().interrupt(); break; }
                    }
                }
                if (stopRequested.get()) break;

                long seekTo = seekTargetMs.getAndSet(-1);
                if (seekTo >= 0) {
                    try {
                        local.setTimestamp(seekTo * 1000L, true);
                        positionMs.set(seekTo);
                        localLine.flush();
                    } catch (Exception ignored) {}
                }

                Frame frame = local.grabSamples();
                if (frame == null) break;
                if (frame.samples == null) continue;

                int totalShorts = 0;
                for (Buffer buf : frame.samples) {
                    if (buf instanceof ShortBuffer sb) totalShorts += sb.remaining();
                }
                if (totalShorts == 0) continue;
                int totalBytes = totalShorts * 2;
                if (writeBuf.length < totalBytes) writeBuf = new byte[totalBytes];

                int off = 0;
                for (Buffer buf : frame.samples) {
                    if (buf instanceof ShortBuffer sb) {
                        ShortBuffer dup = sb.duplicate();
                        while (dup.hasRemaining()) {
                            short s = dup.get();
                            writeBuf[off++] = (byte) (s & 0xFF);
                            writeBuf[off++] = (byte) ((s >> 8) & 0xFF);
                        }
                    }
                }

                localLine.write(writeBuf, 0, totalBytes);

                long ts = local.getTimestamp();  // Mikrosekunden
                if (ts > 0) {
                    long pos = ts / 1000;
                    positionMs.set(pos);
                    listener.onPositionChanged(pos, durationMs.get());
                }
            }

            if (!stopRequested.get()) {
                try { localLine.drain(); } catch (Exception ignored) {}
                setState(PlaybackState.STOPPED);
                listener.onEndReached();
            }
        } catch (Throwable e) {
            setState(PlaybackState.ERROR);
            listener.onError("FFmpeg-Wiedergabe fehlgeschlagen: " + e.getMessage());
        } finally {
            closeResources();
        }
    }

    private synchronized void closeResources() {
        SourceDataLine l = this.line;
        if (l != null) {
            try { l.close(); } catch (Exception ignored) {}
            this.line = null;
        }
        FFmpegFrameGrabber g = this.grabber;
        if (g != null) {
            try { g.stop(); } catch (Exception ignored) {}
            try { g.release(); } catch (Exception ignored) {}
            this.grabber = null;
        }
    }

    private void setState(PlaybackState s) {
        this.state = s;
        listener.onStateChanged(s);
    }
}
