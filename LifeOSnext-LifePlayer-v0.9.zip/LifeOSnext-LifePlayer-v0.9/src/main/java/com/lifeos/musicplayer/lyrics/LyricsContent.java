package com.lifeos.musicplayer.lyrics;

import java.util.List;

/** Ergebnis aus {@link LyricsService#loadLyrics}. Enthält den Rohtext
 *  (für den Editor) und – falls vorhanden – die geparsten Zeit-Zeilen. */
public record LyricsContent(String rawText, List<LrcParser.TimedLine> timedLines) {

    public boolean isTimed() {
        return timedLines != null && !timedLines.isEmpty();
    }

    public boolean isEmpty() {
        return (rawText == null || rawText.isBlank())
            && (timedLines == null || timedLines.isEmpty());
    }

    public static LyricsContent empty() {
        return new LyricsContent("", List.of());
    }

    public static LyricsContent plain(String text) {
        return new LyricsContent(text == null ? "" : text, List.of());
    }

    public static LyricsContent of(String text) {
        if (text == null || text.isBlank()) return empty();
        if (LrcParser.looksLikeLrc(text)) {
            return new LyricsContent(text, LrcParser.parse(text));
        }
        return plain(text);
    }
}
