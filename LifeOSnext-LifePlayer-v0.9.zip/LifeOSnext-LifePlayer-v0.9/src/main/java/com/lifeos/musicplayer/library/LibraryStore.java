package com.lifeos.musicplayer.library;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.lifeos.musicplayer.model.ModuleSettings;
import com.lifeos.musicplayer.model.MusicSource;
import com.lifeos.musicplayer.model.Playlist;
import com.lifeos.musicplayer.model.Track;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public final class LibraryStore {
    private final ObjectMapper json = new ObjectMapper().enable(SerializationFeature.INDENT_OUTPUT);
    private final Path storagePath;

    public LibraryStore(Path storagePath) {
        this.storagePath = storagePath;
        try { Files.createDirectories(storagePath); } catch (IOException ignored) {}
    }

    public Path libraryFile()  { return storagePath.resolve("library.json"); }
    public Path sourcesFile()  { return storagePath.resolve("sources.json"); }
    public Path playlistsFile(){ return storagePath.resolve("playlists.json"); }
    public Path settingsFile() { return storagePath.resolve("settings.json"); }
    public Path cacheDir()     { return storagePath.resolve("cache"); }
    public Path lyricsDir()    { return storagePath.resolve("lyrics"); }
    public Path coversDir()    { return storagePath.resolve("covers"); }

    public List<Track> loadTracks() {
        return readList(libraryFile(), Track[].class);
    }

    public void saveTracks(List<Track> tracks) {
        write(libraryFile(), tracks.toArray(new Track[0]));
    }

    public List<MusicSource> loadSources() {
        return readList(sourcesFile(), MusicSource[].class);
    }

    public void saveSources(List<MusicSource> sources) {
        write(sourcesFile(), sources.toArray(new MusicSource[0]));
    }

    public List<Playlist> loadPlaylists() {
        return readList(playlistsFile(), Playlist[].class);
    }

    public void savePlaylists(List<Playlist> playlists) {
        write(playlistsFile(), playlists.toArray(new Playlist[0]));
    }

    public ModuleSettings loadSettings() {
        if (!Files.exists(settingsFile())) return new ModuleSettings();
        try {
            return json.readValue(settingsFile().toFile(), ModuleSettings.class);
        } catch (IOException e) {
            return new ModuleSettings();
        }
    }

    public void saveSettings(ModuleSettings settings) {
        write(settingsFile(), settings == null ? new ModuleSettings() : settings);
    }

    private <T> List<T> readList(Path p, Class<T[]> type) {
        if (!Files.exists(p)) return new ArrayList<>();
        try {
            T[] arr = json.readValue(p.toFile(), type);
            return new ArrayList<>(Arrays.asList(arr));
        } catch (IOException e) {
            return new ArrayList<>();
        }
    }

    private void write(Path p, Object value) {
        try {
            Files.createDirectories(p.getParent());
            json.writeValue(p.toFile(), value);
        } catch (IOException e) {
            System.err.println("[LibraryStore] write failed: " + e.getMessage());
        }
    }
}
