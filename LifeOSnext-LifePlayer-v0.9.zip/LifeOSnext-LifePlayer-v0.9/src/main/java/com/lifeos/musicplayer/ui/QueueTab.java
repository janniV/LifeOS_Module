package com.lifeos.musicplayer.ui;

import com.lifeos.musicplayer.model.Track;
import com.lifeos.musicplayer.playback.PlaybackController;
import com.lifeos.musicplayer.playback.PlaybackQueue;
import javafx.application.Platform;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.scene.control.ListCell;
import javafx.scene.control.ListView;
import javafx.scene.layout.BorderPane;

public final class QueueTab extends BorderPane {

    private final ObservableList<Track> items = FXCollections.observableArrayList();

    public QueueTab(PlaybackController controller) {
        PlaybackQueue q = controller.getQueue();
        ListView<Track> list = new ListView<>(items);
        list.setCellFactory(lv -> new ListCell<>() {
            @Override protected void updateItem(Track t, boolean empty) {
                super.updateItem(t, empty);
                if (empty || t == null) { setText(null); return; }
                int idx = getIndex();
                String marker = idx == q.getCurrentIndex() ? "▶ " : "   ";
                setText(marker + t.getTitle() + " — " + t.getDisplayArtist());
            }
        });
        list.setOnMouseClicked(e -> {
            if (e.getClickCount() == 2 && list.getSelectionModel().getSelectedIndex() >= 0) {
                q.jumpTo(list.getSelectionModel().getSelectedIndex());
                Track t = q.getCurrent();
                if (t != null) controller.playAll(q.getTracks(), q.getCurrentIndex());
            }
        });
        setCenter(list);
        q.addListener(qu -> Platform.runLater(() -> {
            items.setAll(qu.getTracks());
            list.refresh();
        }));
        items.setAll(q.getTracks());
    }
}
