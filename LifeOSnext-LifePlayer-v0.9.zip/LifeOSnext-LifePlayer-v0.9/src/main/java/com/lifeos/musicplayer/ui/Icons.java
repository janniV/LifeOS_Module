package com.lifeos.musicplayer.ui;

import javafx.geometry.Pos;
import javafx.scene.Node;
import javafx.scene.layout.StackPane;
import javafx.scene.shape.SVGPath;

public final class Icons {

    private Icons() {}

    public static Node musicNote(double size)    { return svg(size, "M12 3v10.55c-.59-.34-1.27-.55-2-.55-2.21 0-4 1.79-4 4s1.79 4 4 4 4-1.79 4-4V7h4V3h-6z"); }
    public static Node track(double size)        { return svg(size, "M12 3v10.55A4 4 0 1 0 14 17V7h4V3h-6Z"); }
    public static Node artist(double size)       { return svg(size, "M12 12a4 4 0 1 0 0-8 4 4 0 0 0 0 8Zm0 2c-4 0-8 2-8 6v2h16v-2c0-4-4-6-8-6Z"); }
    public static Node album(double size)        { return svg(size, "M12 2a10 10 0 1 0 0 20 10 10 0 0 0 0-20Zm0 4a6 6 0 1 1 0 12 6 6 0 0 1 0-12Zm0 4a2 2 0 1 0 0 4 2 2 0 0 0 0-4Z"); }
    public static Node playlist(double size)     { return svg(size, "M3 6h13v2H3V6Zm0 5h13v2H3v-2Zm0 5h8v2H3v-2Zm15-3 5 3-5 3v-6Z"); }
    public static Node queueIcon(double size)    { return svg(size, "M3 6h18v2H3V6Zm0 5h13v2H3v-2Zm0 5h13v2H3v-2Zm15-1 5 3-5 3v-6Z"); }
    public static Node lyrics(double size)       { return svg(size, "M4 4h16v2H4V4Zm0 4h12v2H4V8Zm0 4h16v2H4v-2Zm0 4h12v2H4v-2Z"); }
    public static Node clock(double size)        { return svg(size, "M12 22a10 10 0 1 1 0-20 10 10 0 0 1 0 20Zm.5-15h-2v6.4l5 3 1-1.7-4-2.4V7Z"); }
    public static Node genres(double size)       { return svg(size, "M4 4h7v7H4V4Zm9 0h7v7h-7V4ZM4 13h7v7H4v-7Zm12.5-1A4.5 4.5 0 1 1 21 16.5 4.5 4.5 0 0 1 16.5 12Z"); }
    public static Node heart(double size)        { return svg(size, "M12 21s-7-4.5-9.5-9A5.5 5.5 0 0 1 12 5a5.5 5.5 0 0 1 9.5 7c-2.5 4.5-9.5 9-9.5 9Z"); }
    public static Node moreVertical(double size) { return svg(size, "M12 8a2 2 0 1 1 0-4 2 2 0 0 1 0 4Zm0 6a2 2 0 1 1 0-4 2 2 0 0 1 0 4Zm0 6a2 2 0 1 1 0-4 2 2 0 0 1 0 4Z"); }
    public static Node moreHorizontal(double size){ return svg(size, "M6 12a2 2 0 1 1-4 0 2 2 0 0 1 4 0Zm8 0a2 2 0 1 1-4 0 2 2 0 0 1 4 0Zm8 0a2 2 0 1 1-4 0 2 2 0 0 1 4 0Z"); }
    public static Node play(double size)         { return svg(size, "M7 4v16l13-8L7 4Z"); }
    public static Node pause(double size)        { return svg(size, "M6 4h4v16H6V4Zm8 0h4v16h-4V4Z"); }
    public static Node skipPrev(double size)     { return svg(size, "M6 5h2v14H6V5Zm14 0v14L9 12l11-7Z"); }
    public static Node skipNext(double size)     { return svg(size, "M16 5h2v14h-2V5ZM4 5l11 7-11 7V5Z"); }
    public static Node shuffle(double size)      { return svg(size, "M16 3h5v5l-1.6-1.6-3 3-1.4-1.4 3-3L16 3ZM3 5h4l11 14h3l-1.6 1.6 1.6 1.4h-5L4.4 7.6 3 5Zm0 14 4-5 1.3 1.6-2.7 3.4H3v0Z"); }
    public static Node repeat(double size)       { return svg(size, "M7 7h10V5l4 3.5L17 12v-2H9v3H7V7Zm10 10H7v2l-4-3.5L7 12v2h8v-3h2v6Z"); }
    public static Node repeatOne(double size)    { return svg(size, "M7 7h10V5l4 3.5L17 12v-2H9v3H7V7Zm10 10H7v2l-4-3.5L7 12v2h8v-3h2v6Zm-5-7h-1v-1l-1 .5v-1l1-.5h1V10Z"); }
    public static Node volume(double size)       { return svg(size, "M3 9v6h4l5 4V5L7 9H3Zm13 3a4 4 0 0 0-2-3.4v6.8c1.2-.7 2-2 2-3.4Zm-2-7v2.1A5 5 0 0 1 19 12a5 5 0 0 1-5 4.9V19a7 7 0 0 0 0-14Z"); }
    public static Node search(double size)       { return svg(size, "M10 4a6 6 0 1 0 3.7 10.7l4.6 4.6 1.4-1.4-4.6-4.6A6 6 0 0 0 10 4Zm0 2a4 4 0 1 1 0 8 4 4 0 0 1 0-8Z"); }
    public static Node settingsGear(double size) { return svg(size, "M19.4 13a7.4 7.4 0 0 0 0-2l2-1.5-2-3.4-2.4 1a7.4 7.4 0 0 0-1.7-1L15 3.4h-4l-.3 2.6a7.4 7.4 0 0 0-1.7 1l-2.4-1-2 3.4 2 1.5a7.4 7.4 0 0 0 0 2l-2 1.5 2 3.4 2.4-1c.5.4 1.1.7 1.7 1L11 20.6h4l.3-2.6c.6-.3 1.2-.6 1.7-1l2.4 1 2-3.4-2-1.5ZM13 15a3 3 0 1 1 0-6 3 3 0 0 1 0 6Z"); }
    public static Node plus(double size)         { return svg(size, "M11 4h2v7h7v2h-7v7h-2v-7H4v-2h7V4Z"); }
    public static Node sidebarLeft(double size)  { return svg(size, "M3 5h18v14H3V5Zm2 2v10h5V7H5Z"); }
    public static Node sidebarRight(double size) { return svg(size, "M3 5h18v14H3V5Zm14 2v10h4V7h-4Z"); }
    public static Node chevronLeft(double size)  { return svg(size, "M15.41 16.59 10.83 12l4.58-4.59L14 6l-6 6 6 6 1.41-1.41z"); }
    public static Node chevronDown(double size)  { return svg(size, "M7 10l5 5 5-5H7Z"); }
    public static Node listView(double size)     { return svg(size, "M4 6h16v2H4V6Zm0 5h16v2H4v-2Zm0 5h16v2H4v-2Z"); }
    public static Node gridView(double size)     { return svg(size, "M4 4h7v7H4V4Zm9 0h7v7h-7V4ZM4 13h7v7H4v-7Zm9 0h7v7h-7v-7Z"); }

    private static Node svg(double size, String path) {
        SVGPath p = new SVGPath();
        p.setContent(path);
        p.getStyleClass().add("music-icon");
        double s = size / 24.0;
        p.setScaleX(s);
        p.setScaleY(s);
        StackPane wrap = new StackPane(p);
        wrap.setMinSize(size, size);
        wrap.setPrefSize(size, size);
        wrap.setMaxSize(size, size);
        wrap.setAlignment(Pos.CENTER);
        wrap.setPickOnBounds(false);
        wrap.getStyleClass().add("music-icon-wrap");
        return wrap;
    }
}
