package com.lifeos.musicplayer.playback;

import java.nio.file.Path;

public interface PlaybackEngine {
    interface Listener {
        default void onStateChanged(PlaybackState state) {}
        default void onPositionChanged(long positionMs, long durationMs) {}
        default void onEndReached() {}
        default void onError(String message) {}
    }

    void load(Path localFile);
    default void setKnownDurationMs(long durationMs) {}
    void play();
    void pause();
    void stop();
    void seek(long positionMs);
    void setVolume(double volume0to1);
    double getVolume();
    long getPositionMs();
    long getDurationMs();
    PlaybackState getState();

    void setListener(Listener listener);
    void dispose();
}
