package com.lifeos.musicplayer.ai;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.lifeos.musicplayer.library.LibraryStore;
import com.lifeos.musicplayer.library.MusicLibrary;
import com.lifeos.musicplayer.model.Album;
import com.lifeos.musicplayer.model.Playlist;
import com.lifeos.musicplayer.model.Track;
import com.lifeos.musicplayer.playback.PlaybackController;
import com.lifeos.musicplayer.ui.PlaylistsTab;
import core.AITool;
import core.AIToolSafety;
import core.AgentToolResult;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

public final class MusicAITools {

    private static final ObjectMapper M = new ObjectMapper();

    private MusicAITools() {}

    public static List<AITool> create(MusicLibrary library,
                                      LibraryStore store,
                                      PlaybackController controller,
                                      PlaylistsTab playlistsTab) {
        List<AITool> tools = new ArrayList<>();

        tools.add(new AITool(
            "music_search",
            "Sucht in der Musikbibliothek nach Titeln, Alben und Künstler:innen.",
            "{\"query\":\"Suchtext\"}",
            AIToolSafety.READ_ONLY, false,
            json -> {
                try {
                    String q = text(parse(json), "query");
                    List<Track> hits = library.search(q);
                    hits.sort(Comparator.comparing(Track::getTitle, String.CASE_INSENSITIVE_ORDER));
                    if (hits.isEmpty()) return AgentToolResult.success("Keine Treffer.");
                    StringBuilder sb = new StringBuilder();
                    int limit = Math.min(20, hits.size());
                    for (int i = 0; i < limit; i++) {
                        Track t = hits.get(i);
                        sb.append(i + 1).append(". ").append(t.getTitle())
                          .append(" — ").append(t.getDisplayArtist())
                          .append("  [").append(t.getAlbum()).append("]\n");
                    }
                    if (hits.size() > limit) sb.append("... +").append(hits.size() - limit).append(" weitere");
                    return AgentToolResult.success(sb.toString());
                } catch (Exception e) { return AgentToolResult.error(e.getMessage()); }
            }
        ));

        tools.add(new AITool(
            "music_play",
            "Spielt etwas ab. Genau eines der Felder title, artist oder album angeben.",
            "{\"title\":\"...\",\"artist\":\"...\",\"album\":\"...\"}",
            AIToolSafety.UI_ACTION, false,
            json -> {
                try {
                    JsonNode n = parse(json);
                    String title  = text(n, "title");
                    String artist = text(n, "artist");
                    String album  = text(n, "album");
                    if (!album.isBlank()) {
                        for (Album a : library.getAlbums()) {
                            if (a.getName().equalsIgnoreCase(album)) {
                                controller.playAll(a.getTracks(), 0);
                                return AgentToolResult.success("Album '" + a.getName() + "' gestartet.");
                            }
                        }
                        return AgentToolResult.error("Album nicht gefunden: " + album);
                    }
                    if (!artist.isBlank()) {
                        List<Track> all = new ArrayList<>();
                        for (Track t : library.getTracks())
                            if (t.getDisplayArtist().equalsIgnoreCase(artist)) all.add(t);
                        if (all.isEmpty()) return AgentToolResult.error("Künstler:in nicht gefunden: " + artist);
                        controller.playAll(all, 0);
                        return AgentToolResult.success(all.size() + " Titel von " + artist + " gestartet.");
                    }
                    if (!title.isBlank()) {
                        List<Track> hits = library.search(title);
                        if (hits.isEmpty()) return AgentToolResult.error("Titel nicht gefunden: " + title);
                        controller.playTrack(hits.get(0));
                        return AgentToolResult.success("Spiele: " + hits.get(0).getTitle());
                    }
                    return AgentToolResult.error("Bitte title, artist oder album angeben.");
                } catch (Exception e) { return AgentToolResult.error(e.getMessage()); }
            }
        ));

        tools.add(new AITool(
            "music_queue_add",
            "Fügt Suchergebnisse zur Warteschlange hinzu.",
            "{\"query\":\"...\"}",
            AIToolSafety.UI_ACTION, false,
            json -> {
                try {
                    List<Track> hits = library.search(text(parse(json), "query"));
                    if (hits.isEmpty()) return AgentToolResult.error("Keine Treffer.");
                    controller.getQueue().appendAll(hits);
                    return AgentToolResult.success(hits.size() + " Titel zur Warteschlange hinzugefügt.");
                } catch (Exception e) { return AgentToolResult.error(e.getMessage()); }
            }
        ));

        tools.add(new AITool(
            "music_pause",
            "Pausiert oder setzt die Wiedergabe fort.",
            "{}",
            AIToolSafety.UI_ACTION, false,
            json -> { controller.togglePlay(); return AgentToolResult.success("Play/Pause umgeschaltet."); }
        ));

        tools.add(new AITool(
            "music_next",
            "Springt zum nächsten Titel.",
            "{}",
            AIToolSafety.UI_ACTION, false,
            json -> { controller.next(); return AgentToolResult.success("Nächster Titel."); }
        ));

        tools.add(new AITool(
            "music_create_playlist",
            "Legt eine neue Playlist an. Optional: fromQuery füllt sie mit passenden Titeln.",
            "{\"name\":\"Mein Mix\",\"fromQuery\":\"chill\"}",
            AIToolSafety.USER_DATA_WRITE, false,
            json -> {
                try {
                    JsonNode n = parse(json);
                    String name = text(n, "name");
                    if (name.isBlank()) return AgentToolResult.error("Feld name fehlt.");
                    Playlist p = new Playlist(name);
                    String q = text(n, "fromQuery");
                    if (!q.isBlank()) for (Track t : library.search(q)) p.getTrackIds().add(t.getId());
                    playlistsTab.addPlaylist(p);
                    return AgentToolResult.success("Playlist '" + name + "' mit " + p.getTrackIds().size() + " Titeln erstellt.");
                } catch (Exception e) { return AgentToolResult.error(e.getMessage()); }
            }
        ));

        return tools;
    }

    private static JsonNode parse(String input) throws Exception {
        return M.readTree(input == null || input.isBlank() ? "{}" : input);
    }

    private static String text(JsonNode n, String field) {
        JsonNode v = n == null ? null : n.get(field);
        return v == null || v.isNull() ? "" : v.asText("");
    }
}
