package com.lifeos.musicplayer.playback;

public enum PlaybackState {
    IDLE, BUFFERING, PLAYING, PAUSED, STOPPED, ERROR
}
