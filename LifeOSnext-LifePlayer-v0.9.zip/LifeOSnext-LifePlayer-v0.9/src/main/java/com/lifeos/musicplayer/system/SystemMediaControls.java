package com.lifeos.musicplayer.system;

import com.lifeos.musicplayer.model.Track;
import com.lifeos.musicplayer.playback.PlaybackState;

/**
 * Anbindung an die Medien-Steuerung des Betriebssystems
 * (Windows SMTC, macOS MPNowPlayingInfoCenter, Linux MPRIS).
 * Eine konkrete Implementierung wird von LifeOS oder einem
 * nativen Adapter zur Laufzeit eingehängt. Standardmäßig No-Op.
 */
public interface SystemMediaControls {

    interface Handler {
        default void onPlay() {}
        default void onPause() {}
        default void onTogglePlay() {}
        default void onNext() {}
        default void onPrevious() {}
        default void onStop() {}
        default void onSeek(long positionMs) {}
        default void onSetVolume(double volume) {}
    }

    void setHandler(Handler handler);
    void updateNowPlaying(Track track);
    void updateState(PlaybackState state, long positionMs, long durationMs);
    void shutdown();

    SystemMediaControls NO_OP = new SystemMediaControls() {
        @Override public void setHandler(Handler handler) {}
        @Override public void updateNowPlaying(Track track) {}
        @Override public void updateState(PlaybackState state, long positionMs, long durationMs) {}
        @Override public void shutdown() {}
    };
}
