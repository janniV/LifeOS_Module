package com.lifeos.musicplayer.playback;

import org.jflac.sound.spi.FlacAudioFileReader;

import javax.sound.sampled.AudioFormat;
import javax.sound.sampled.AudioInputStream;
import javax.sound.sampled.AudioSystem;
import javax.sound.sampled.DataLine;
import javax.sound.sampled.FloatControl;
import javax.sound.sampled.SourceDataLine;
import java.io.BufferedInputStream;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicLong;

/**
 * Streamt FLAC dekodiert ans Default-Audio-Device. Verwendet die SPI von jflac-codec.
 * JavaFX MediaPlayer kann FLAC nicht nativ.
 */
public final class FlacPlaybackEngine implements PlaybackEngine {

    private Thread playThread;
    private SourceDataLine line;
    private Path file;
    private Listener listener = new Listener() {};
    private final AtomicBoolean paused = new AtomicBoolean(false);
    private final AtomicBoolean stopRequested = new AtomicBoolean(false);
    private final AtomicLong positionMs = new AtomicLong();
    private final AtomicLong durationMs = new AtomicLong();
    private double volume = 0.8;
    private long seekTargetMs = -1;
    private PlaybackState state = PlaybackState.IDLE;

    @Override
    public void load(Path localFile) {
        stop();
        this.file = localFile;
        if (durationMs.get() <= 0) {
            try { durationMs.set(estimateDurationMs(Files.size(localFile))); }
            catch (Exception ignored) {}
        }
        positionMs.set(0);
        setState(PlaybackState.IDLE);
    }

    @Override
    public void setKnownDurationMs(long ms) {
        if (ms > 0) durationMs.set(ms);
    }

    @Override
    public synchronized void play() {
        if (state == PlaybackState.PAUSED && playThread != null && playThread.isAlive()) {
            paused.set(false);
            setState(PlaybackState.PLAYING);
            synchronized (paused) { paused.notifyAll(); }
            return;
        }
        if (file == null) return;
        stopRequested.set(false);
        paused.set(false);
        playThread = new Thread(this::runPlayback, "FlacPlayback");
        playThread.setDaemon(true);
        playThread.start();
    }

    @Override
    public void pause() {
        if (state == PlaybackState.PLAYING) {
            paused.set(true);
            setState(PlaybackState.PAUSED);
        }
    }

    @Override
    public synchronized void stop() {
        stopRequested.set(true);
        paused.set(false);
        synchronized (paused) { paused.notifyAll(); }
        if (line != null) try { line.stop(); line.close(); } catch (Exception ignored) {}
        if (playThread != null) {
            try { playThread.join(500); } catch (InterruptedException ignored) {}
        }
        playThread = null;
        line = null;
        positionMs.set(0);
        setState(PlaybackState.STOPPED);
    }

    @Override
    public void seek(long target) {
        seekTargetMs = Math.max(0, target);
    }

    @Override
    public void setVolume(double v) {
        this.volume = Math.max(0, Math.min(1, v));
        applyVolume();
    }

    private void applyVolume() {
        if (line == null) return;
        try {
            if (line.isControlSupported(FloatControl.Type.MASTER_GAIN)) {
                FloatControl gain = (FloatControl) line.getControl(FloatControl.Type.MASTER_GAIN);
                float dB = (float) (volume <= 0.0001 ? gain.getMinimum()
                                                     : (20.0 * Math.log10(volume)));
                gain.setValue(Math.max(gain.getMinimum(), Math.min(gain.getMaximum(), dB)));
            }
        } catch (Exception ignored) {}
    }

    @Override public double getVolume()  { return volume; }
    @Override public long getPositionMs(){ return positionMs.get(); }
    @Override public long getDurationMs(){ return durationMs.get(); }
    @Override public PlaybackState getState() { return state; }
    @Override public void setListener(Listener l) { this.listener = l == null ? new Listener() {} : l; }
    @Override public void dispose() { stop(); }

    private void runPlayback() {
        AudioInputStream in = null;
        AudioInputStream pcm = null;
        try {
            setState(PlaybackState.BUFFERING);
            InputStream raw = new BufferedInputStream(Files.newInputStream(file));
            in = new FlacAudioFileReader().getAudioInputStream(raw);
            AudioFormat base = in.getFormat();
            int sampleBits = base.getSampleSizeInBits();
            if (sampleBits <= 0) sampleBits = 16;

            org.jflac.sound.spi.FlacFormatConversionProvider provider =
                new org.jflac.sound.spi.FlacFormatConversionProvider();

            // 1) Versuch: native Tiefe abspielen (24-bit FLACs ohne Verlust).
            //    Wir bauen ein PCM-Target mit der gleichen Sample-Tiefe wie
            //    die Quelle. jflac liefert die PCM-Bytes 1:1 durch, und die
            //    Soundkarte spielt sie nativ ab — sofern sie das Format
            //    unterstützt. Klappt das nicht, fällt der catch unten auf
            //    16-bit zurück, wobei wir 24->16 selbst quantisieren.
            AudioFormat target = buildPcmTarget(base, sampleBits);
            try {
                pcm = provider.getAudioInputStream(target, in);
                DataLine.Info info = new DataLine.Info(SourceDataLine.class, target);
                line = (SourceDataLine) AudioSystem.getLine(info);
                line.open(target);
            } catch (Exception nativeFailed) {
                // 2) Fallback: 16-bit Target. Wenn jflacs eigener Konverter
                //    24->16 nicht kann, lesen wir das native PCM und kürzen
                //    die Samples selbst auf 16-bit.
                try { if (pcm != null) pcm.close(); } catch (Exception ignored) {}
                pcm = null;
                if (line != null) { try { line.close(); } catch (Exception ignored) {} line = null; }

                AudioFormat target16 = buildPcmTarget(base, 16);
                try {
                    pcm = provider.getAudioInputStream(target16, in);
                } catch (Exception convFailed) {
                    // jflac kann nicht. Wir lesen PCM in nativer Tiefe und
                    // wandeln 24->16 selbst (high-byte-extract, little-endian).
                    AudioFormat targetNative = buildPcmTarget(base, sampleBits);
                    AudioInputStream nativePcm = provider.getAudioInputStream(targetNative, in);
                    pcm = new DownmixTo16BitStream(nativePcm, targetNative);
                }
                target = target16;
                DataLine.Info info = new DataLine.Info(SourceDataLine.class, target);
                line = (SourceDataLine) AudioSystem.getLine(info);
                line.open(target);
            }
            applyVolume();
            line.start();

            setState(PlaybackState.PLAYING);

            long bytesPerMs = (long) (target.getSampleRate() * target.getFrameSize() / 1000.0);
            byte[] buf = new byte[4096];
            long bytesRead = 0;
            int n;
            while ((n = pcm.read(buf)) != -1 && !stopRequested.get()) {
                while (paused.get() && !stopRequested.get()) {
                    synchronized (paused) {
                        try { paused.wait(200); } catch (InterruptedException e) { break; }
                    }
                }
                if (stopRequested.get()) break;
                if (seekTargetMs >= 0) {
                    long skipMs = seekTargetMs - positionMs.get();
                    if (skipMs > 0) {
                        long skipBytes = skipMs * bytesPerMs;
                        long skipped = pcm.skip(skipBytes);
                        bytesRead += skipped;
                        positionMs.set(bytesPerMs == 0 ? 0 : bytesRead / bytesPerMs);
                    }
                    seekTargetMs = -1;
                }
                line.write(buf, 0, n);
                bytesRead += n;
                long pos = bytesPerMs == 0 ? 0 : bytesRead / bytesPerMs;
                positionMs.set(pos);
                listener.onPositionChanged(pos, durationMs.get());
            }
            line.drain();
            if (!stopRequested.get()) {
                setState(PlaybackState.STOPPED);
                listener.onEndReached();
            }
        } catch (Exception e) {
            setState(PlaybackState.ERROR);
            listener.onError("FLAC-Wiedergabe fehlgeschlagen: " + e.getMessage());
        } finally {
            try { if (pcm != null) pcm.close(); } catch (Exception ignored) {}
            try { if (in != null) in.close(); } catch (Exception ignored) {}
            if (line != null) { try { line.close(); } catch (Exception ignored) {} }
        }
    }

    private long estimateDurationMs(long sizeBytes) {
        return sizeBytes / 100;
    }

    private void setState(PlaybackState s) {
        this.state = s;
        listener.onStateChanged(s);
    }

    private static AudioFormat buildPcmTarget(AudioFormat base, int bits) {
        int bytesPerSample = bits / 8;
        int frameSize = base.getChannels() * bytesPerSample;
        return new AudioFormat(
            AudioFormat.Encoding.PCM_SIGNED,
            base.getSampleRate(),
            bits,
            base.getChannels(),
            frameSize,
            base.getSampleRate(),
            false
        );
    }

    /** Wraps a 24-bit PCM stream and emits 16-bit PCM by discarding the
     *  low byte of each little-endian sample. Used as last-resort
     *  fallback when neither the soundcard supports the native bit
     *  depth nor jflac's own provider can convert it. */
    private static final class DownmixTo16BitStream extends AudioInputStream {
        private final AudioInputStream src;
        private final int srcSampleBytes;
        private final byte[] readBuf = new byte[8192];

        DownmixTo16BitStream(AudioInputStream src, AudioFormat sourceFormat) {
            super(src, buildPcmTarget(sourceFormat, 16), AudioSystem.NOT_SPECIFIED);
            this.src = src;
            this.srcSampleBytes = sourceFormat.getSampleSizeInBits() / 8;
        }

        @Override public int read() throws java.io.IOException {
            byte[] one = new byte[1];
            int n = read(one, 0, 1);
            return n < 0 ? -1 : one[0] & 0xff;
        }

        @Override public int read(byte[] dst, int off, int len) throws java.io.IOException {
            if (srcSampleBytes == 2) return src.read(dst, off, len);
            int outSamples = len / 2;
            int wantBytes = outSamples * srcSampleBytes;
            if (wantBytes > readBuf.length) wantBytes = (readBuf.length / srcSampleBytes) * srcSampleBytes;
            int got = src.read(readBuf, 0, wantBytes);
            if (got <= 0) return got;
            int samples = got / srcSampleBytes;
            int o = off;
            for (int i = 0; i < samples; i++) {
                int base = i * srcSampleBytes;
                // little-endian: high byte is at base + srcSampleBytes-1
                dst[o++] = readBuf[base + srcSampleBytes - 2];
                dst[o++] = readBuf[base + srcSampleBytes - 1];
            }
            return samples * 2;
        }

        @Override public void close() throws java.io.IOException { src.close(); }
    }
}
