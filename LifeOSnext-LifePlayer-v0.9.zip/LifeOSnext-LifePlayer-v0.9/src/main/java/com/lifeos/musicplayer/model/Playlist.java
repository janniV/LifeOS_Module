package com.lifeos.musicplayer.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

@JsonIgnoreProperties(ignoreUnknown = true)
public final class Playlist {
    private String id = UUID.randomUUID().toString();
    private String name = "";
    private final List<String> trackIds = new ArrayList<>();
    private long createdEpochMs = System.currentTimeMillis();

    public Playlist() {}

    public Playlist(String name) {
        this.name = name;
    }

    public String getId() { return id; }
    public void setId(String id) { this.id = id; }
    public String getName() { return name; }
    public void setName(String name) { this.name = name; }
    public List<String> getTrackIds() { return trackIds; }
    public long getCreatedEpochMs() { return createdEpochMs; }
    public void setCreatedEpochMs(long v) { this.createdEpochMs = v; }
}
