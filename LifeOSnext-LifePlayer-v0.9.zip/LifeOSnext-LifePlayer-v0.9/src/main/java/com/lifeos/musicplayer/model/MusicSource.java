package com.lifeos.musicplayer.model;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import core.CoreServices;
import core.LifeOSFileReference;
import core.LifeOSFileService;

import java.io.File;
import java.util.List;
import java.util.UUID;

/**
 * Eine konfigurierte Musikquelle (lokaler Ordner, NAS-Wurzel, Workspace-Pfad
 * oder Modul-Daten). LifeOSFileReference wird als opake Klasse behandelt:
 * niemals selbst konstruieren, immer über CoreServices/LifeOSFileService
 * holen.
 */
@JsonIgnoreProperties(ignoreUnknown = true)
public final class MusicSource {

    private String id = UUID.randomUUID().toString();
    private String label = "";
    private RefKind kind = RefKind.LOCAL;

    /** Für LOCAL: absoluter Pfad. Für WORKSPACE/MODULE_DATA: relativer Pfad. Für NAS: Anzeige-Pfad. */
    private String path = "";

    /** Stabiler Wiederfindungs-Schlüssel für NAS-Wurzeln (toString der LifeOSFileReference). */
    private String refKey = "";

    /** Optionaler Unterordner (NUR informativ — die echte Auflösung läuft via Core). */
    private String subPath = "";

    private long lastScannedEpochMs;
    private int trackCount;

    /** Im Speicher gehaltene Original-Referenz vom Core (nicht persistiert). */
    @JsonIgnore
    private transient LifeOSFileReference cachedRef;

    public MusicSource() {}

    public static MusicSource ofLocal(File folder) {
        MusicSource s = new MusicSource();
        s.kind = RefKind.LOCAL;
        s.label = folder.getName();
        s.path = folder.getAbsolutePath();
        return s;
    }

    public static MusicSource ofNas(LifeOSFileReference root, String displayLabel) {
        MusicSource s = new MusicSource();
        s.kind = RefKind.NAS;
        s.label = displayLabel;
        s.path = safe(callGetRelativePath(root));
        s.refKey = stableReferenceKey(root);
        s.cachedRef = root;
        return s;
    }

    public static MusicSource ofWorkspace(String relativePath, String displayLabel) {
        MusicSource s = new MusicSource();
        s.kind = RefKind.WORKSPACE;
        s.label = displayLabel;
        s.path = relativePath;
        return s;
    }

    public static MusicSource ofModuleData(String relativePath, String displayLabel) {
        MusicSource s = new MusicSource();
        s.kind = RefKind.MODULE_DATA;
        s.label = displayLabel;
        s.path = relativePath;
        return s;
    }

    /** Resolved die Quelle in eine LifeOSFileReference des Cores. Liefert null für LOCAL. */
    @JsonIgnore
    public LifeOSFileReference resolve(CoreServices core, String moduleId) {
        if (kind == RefKind.LOCAL) return null;
        if (cachedRef != null) return cachedRef;
        if (core == null) return null;
        switch (kind) {
            case NAS -> {
                List<LifeOSFileReference> roots;
                try { roots = core.getRemoteFileEntryPoints(moduleId); }
                catch (Exception e) { return null; }
                if (roots == null) return null;
                for (LifeOSFileReference r : roots) {
                    if (matchesRemoteRoot(r)) {
                        cachedRef = r;
                        return r;
                    }
                }
                return null;
            }
            case WORKSPACE -> {
                LifeOSFileService fs = core.getFileService();
                if (fs == null) return null;
                cachedRef = fs.getWorkspaceReference(path);
                return cachedRef;
            }
            case MODULE_DATA -> {
                LifeOSFileService fs = core.getFileService();
                if (fs == null) return null;
                cachedRef = fs.getModuleDataReference(moduleId, path);
                return cachedRef;
            }
            case EXPORT -> {
                LifeOSFileService fs = core.getFileService();
                if (fs == null) return null;
                cachedRef = fs.getExportReference(path);
                return cachedRef;
            }
            default -> { return null; }
        }
    }

    @JsonIgnore
    public File getLocalFile() {
        return kind == RefKind.LOCAL && path != null ? new File(path) : null;
    }

    @JsonIgnore
    public SourceKind getKindResolved() { return SourceKind.fromRefKind(kind); }

    @JsonIgnore
    public boolean isLocal()  { return kind == RefKind.LOCAL; }
    @JsonIgnore
    public boolean isRemote() { return kind == RefKind.NAS; }

    private static String safe(String s) { return s == null ? "" : s; }

    private static String callGetRelativePath(LifeOSFileReference r) {
        if (r == null) return null;
        try { return r.getRelativePath(); } catch (Throwable t) { return String.valueOf(r); }
    }

    private boolean matchesRemoteRoot(LifeOSFileReference candidate) {
        if (candidate == null) return false;
        String key = refKey == null ? "" : refKey;
        if (!key.isBlank()) {
            if (key.equals(stableReferenceKey(candidate))) return true;
            if (key.equals(String.valueOf(candidate))) return true;
        }
        String candidatePath = safe(callGetRelativePath(candidate));
        return !safe(path).isBlank() && safe(path).equals(candidatePath);
    }

    public static String stableReferenceKey(LifeOSFileReference r) {
        if (r == null) return "";
        String provider = invokeString(r, "getProviderId");
        String scope = invokeString(r, "getScope");
        String owner = invokeString(r, "getOwnerId");
        String relative = invokeString(r, "getRelativePath");
        if (relative == null || relative.isBlank()) return String.valueOf(r);
        return safe(provider) + "|" + safe(scope) + "|" + safe(owner) + "|" + safe(relative);
    }

    public static String displayNameOf(LifeOSFileReference r) {
        if (r == null) return "";
        for (String method : new String[] { "getLabel", "getDisplayName", "getName" }) {
            String value = invokeString(r, method);
            if (value != null && !value.isBlank()) return value;
        }
        String text = String.valueOf(r);
        return text == null ? "" : text;
    }

    private static String invokeString(Object target, String method) {
        if (target == null) return "";
        try {
            Object value = target.getClass().getMethod(method).invoke(target);
            return value == null ? "" : value.toString();
        } catch (Throwable ignored) {
            return "";
        }
    }

    public String getId() { return id; }
    public void setId(String id) { this.id = id; }
    public String getLabel() { return label; }
    public void setLabel(String label) { this.label = label; }
    public RefKind getKind() { return kind; }
    public void setKind(RefKind kind) { this.kind = kind; }
    public String getPath() { return path; }
    public void setPath(String path) { this.path = path; }
    public String getRefKey() { return refKey; }
    public void setRefKey(String refKey) { this.refKey = refKey; }
    public String getSubPath() { return subPath; }
    public void setSubPath(String subPath) { this.subPath = subPath; }
    public long getLastScannedEpochMs() { return lastScannedEpochMs; }
    public void setLastScannedEpochMs(long v) { this.lastScannedEpochMs = v; }
    public int getTrackCount() { return trackCount; }
    public void setTrackCount(int v) { this.trackCount = v; }

    /** Anzeige-Pfad (für die UI). */
    @JsonIgnore
    public String getDisplayPath() {
        String p = path == null ? "" : path;
        if (subPath != null && !subPath.isBlank()) {
            return p + "/" + subPath.replaceFirst("^/+", "");
        }
        return p;
    }
}
