package com.lifeos.musicplayer.lyrics;

import com.lifeos.musicplayer.library.NasCache;
import com.lifeos.musicplayer.model.Track;
import core.CoreServices;
import core.LifeOSFileReference;
import org.jaudiotagger.audio.AudioFile;
import org.jaudiotagger.audio.AudioFileIO;
import org.jaudiotagger.tag.FieldKey;
import org.jaudiotagger.tag.Tag;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.concurrent.CompletableFuture;

public final class LyricsService {

    private final Path lyricsDir;
    private final NasCache cache;
    private final CoreServices core;
    private final String moduleId;

    public LyricsService(Path lyricsDir, NasCache cache, CoreServices core, String moduleId) {
        this.lyricsDir = lyricsDir;
        this.cache = cache;
        this.core = core;
        this.moduleId = moduleId;
        try { Files.createDirectories(lyricsDir); } catch (IOException ignored) {}
    }

    /** Lädt Lyrics in dieser Reihenfolge: gespeicherte .lrc → gespeicherte .txt
     *  → ID3/Tag des Audiofiles → leer. Erkennt LRC-Inhalt automatisch. */
    public CompletableFuture<LyricsContent> loadLyrics(Track t) {
        return CompletableFuture.supplyAsync(() -> {
            String lrc = readFile(lrcFile(t));
            if (lrc != null && !lrc.isBlank()) {
                return new LyricsContent(lrc, LrcParser.parse(lrc));
            }
            String plain = readFile(txtFile(t));
            if (plain != null && !plain.isBlank()) {
                return LyricsContent.of(plain);
            }
            String fromTag = readLyricsFromTag(t);
            if (fromTag != null && !fromTag.isBlank()) {
                saveLyrics(t, fromTag);
                return LyricsContent.of(fromTag);
            }
            return LyricsContent.empty();
        });
    }

    /** Erkennt LRC-Inhalt am Text und schreibt entsprechend in .lrc oder .txt.
     *  Räumt die jeweils andere Variante weg, damit beim nächsten Laden
     *  keine Geisterdatei gewinnt. */
    public void saveLyrics(Track t, String content) {
        String text = content == null ? "" : content;
        try {
            if (LrcParser.looksLikeLrc(text)) {
                Files.writeString(lrcFile(t), text, StandardCharsets.UTF_8);
                Files.deleteIfExists(txtFile(t));
            } else {
                Files.writeString(txtFile(t), text, StandardCharsets.UTF_8);
                Files.deleteIfExists(lrcFile(t));
            }
        } catch (IOException ignored) {}
    }

    public CompletableFuture<String> fetchFromLLM(Track t) {
        if (core == null) return CompletableFuture.completedFuture("");
        if (!core.isModulePermissionAllowed(moduleId, "lifeos.llm.internal")) {
            return CompletableFuture.completedFuture("");
        }
        String system = "Du bist ein Lyrics-Helfer im LifeOS Music Player. Antworte ohne Kommentar nur mit dem Text.";
        String prompt = "Liefere den vollständigen Songtext zu \"" + t.getTitle()
            + "\" von \"" + t.getDisplayArtist() + "\". Falls unbekannt, antworte nur mit: UNBEKANNT.";
        return CompletableFuture.supplyAsync(() -> {
            try {
                String r = core.completeWithInternalLLM(moduleId, system, prompt, false);
                if (r == null || r.isBlank() || r.trim().equalsIgnoreCase("UNBEKANNT")) return "";
                saveLyrics(t, r);
                return r;
            } catch (Exception e) { return ""; }
        }).exceptionally(e -> "");
    }

    private Path txtFile(Track t) { return lyricsDir.resolve(t.getId() + ".txt"); }
    private Path lrcFile(Track t) { return lyricsDir.resolve(t.getId() + ".lrc"); }

    private String readFile(Path f) {
        if (!Files.exists(f)) return null;
        try { return Files.readString(f, StandardCharsets.UTF_8); }
        catch (IOException e) { return null; }
    }

    private String readLyricsFromTag(Track t) {
        try {
            Path local;
            if (t.isLocal()) {
                java.io.File f = t.getLocalFile();
                if (f == null) return null;
                local = f.toPath();
            } else {
                LifeOSFileReference ref = t.resolve(core, moduleId);
                if (ref == null) return null;
                local = cache.ensureCached(ref);
            }
            if (!Files.exists(local)) return null;
            AudioFile af = AudioFileIO.read(local.toFile());
            Tag tag = af.getTag();
            if (tag == null) return null;
            return tag.getFirst(FieldKey.LYRICS);
        } catch (Exception e) {
            return null;
        }
    }
}
