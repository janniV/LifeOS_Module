package com.lifeos.musicplayer;

import com.lifeos.musicplayer.ai.MusicAITools;
import com.lifeos.musicplayer.library.CoverArtService;
import com.lifeos.musicplayer.library.LibraryStore;
import com.lifeos.musicplayer.library.MusicLibrary;
import com.lifeos.musicplayer.library.NasCache;
import com.lifeos.musicplayer.lyrics.LyricsService;
import com.lifeos.musicplayer.model.ModuleSettings;
import com.lifeos.musicplayer.model.MusicSource;
import com.lifeos.musicplayer.model.Playlist;
import com.lifeos.musicplayer.model.Track;
import com.lifeos.musicplayer.playback.PlaybackController;
import com.lifeos.musicplayer.playback.PlaybackQueue;
import com.lifeos.musicplayer.playback.PlaybackState;
import com.lifeos.musicplayer.system.DefaultSystemMediaControls;
import com.lifeos.musicplayer.ui.DashboardWidget;
import com.lifeos.musicplayer.ui.MusicPlayerView;
import core.AITool;
import core.CoreServices;
import core.LifeModule;
import core.LifeOSMediaCenter;
import core.LifeOSMediaController;
import core.LifeOSMediaSession;
import core.LifeOSThemeState;
import core.ModuleAIContext;
import javafx.scene.Node;

import java.nio.file.Path;
import java.util.List;

public final class MusicPlayerModule implements LifeModule {

    public static final String MODULE_ID = "com.lifeos.musicplayer";

    private CoreServices core;
    private MusicLibrary library;
    private LibraryStore store;
    private NasCache cache;
    private CoverArtService covers;
    private PlaybackQueue queue;
    private PlaybackController controller;
    private LyricsService lyrics;
    private MusicPlayerView mainView;
    private DefaultSystemMediaControls systemControls;
    private List<AITool> aiTools = List.of();

    public MusicPlayerModule() {}

    @Override public String getModuleName()    { return "Musik"; }
    @Override public String getModuleId()      { return MODULE_ID; }
    @Override public String getFontIconName()  { return "fas-music"; }
    @Override public String getModuleIconPath(){ return null; }

    @Override
    public void onInitialize(CoreServices core) {
        this.core = core;
        Path storage = core.getModuleStoragePath(MODULE_ID);

        this.store = new LibraryStore(storage);
        this.library = new MusicLibrary();
        this.library.replaceAll(store.loadTracks());

        this.cache = new NasCache(store.cacheDir(), core.getFileService());
        this.covers = new CoverArtService(store.coversDir(), cache, core, MODULE_ID);

        this.queue = new PlaybackQueue();
        this.controller = new PlaybackController(queue, cache, core, MODULE_ID);
        this.systemControls = new DefaultSystemMediaControls();
        this.controller.setSystemMediaControls(systemControls);

        this.lyrics = new LyricsService(store.lyricsDir(), cache, core, MODULE_ID);

        List<MusicSource> sources = store.loadSources();
        List<Playlist> playlists = store.loadPlaylists();
        ModuleSettings settings = store.loadSettings();

        this.mainView = new MusicPlayerView(library, store, cache, covers, controller, lyrics,
                                            core, MODULE_ID, sources, playlists, settings);

        this.controller.setOnPlayStarted(t -> {
            t.setLastPlayedEpochMs(System.currentTimeMillis());
            t.setPlayCount(t.getPlayCount() + 1);
            store.saveTracks(library.getTracks());
        });

        this.controller.addListener(new PlaybackController.Listener() {
            @Override public void onError(String msg) {
                core.sendNotification("Musik-Player: " + msg);
            }
        });

        wireMediaCenter();

        this.aiTools = MusicAITools.create(library, store, controller, mainView.getPlaylistsTab());
    }

    private void wireMediaCenter() {
        LifeOSMediaCenter mc = core.getMediaCenter();
        if (mc == null) return;

        LifeOSMediaController mediaController = new LifeOSMediaController() {
            @Override public void playPause()  { controller.togglePlay(); }
            @Override public void previous()   { controller.previous(); }
            @Override public void next()       { controller.next(); }
            @Override public void stop()       { controller.stop(); }
            @Override public void seek(long positionMs) { controller.seek(positionMs); }
            @Override public void setVolume(double v) { controller.setVolume(v); }
            @Override public void volumeDown() { controller.setVolume(Math.max(0, controller.getVolume() - 0.1)); }
            @Override public void volumeUp()   { controller.setVolume(Math.min(1, controller.getVolume() + 0.1)); }
        };

        java.util.concurrent.atomic.AtomicLong lastPositionPublishNs = new java.util.concurrent.atomic.AtomicLong();
        controller.addListener(new PlaybackController.Listener() {
            @Override public void onTrackChanged(Track t) {
                lastPositionPublishNs.set(0);
                publishSession(mc, mediaController, t,
                    controller.getState() == PlaybackState.PLAYING,
                    controller.getPositionMs(), controller.getDurationMs());
            }
            @Override public void onStateChanged(PlaybackState s) {
                publishSession(mc, mediaController, controller.getCurrentTrack(),
                    s == PlaybackState.PLAYING,
                    controller.getPositionMs(), controller.getDurationMs());
            }
            @Override public void onPosition(long posMs, long durMs) {
                long now = System.nanoTime();
                long last = lastPositionPublishNs.get();
                if (now - last < 1_000_000_000L) return;
                lastPositionPublishNs.set(now);
                publishSession(mc, mediaController, controller.getCurrentTrack(),
                    controller.getState() == PlaybackState.PLAYING, posMs, durMs);
            }
        });
    }

    private void publishSession(LifeOSMediaCenter mc, LifeOSMediaController ctrl, Track t,
                                boolean playing, long positionMs, long durationMs) {
        LifeOSMediaSession s = new LifeOSMediaSession();
        s.setModuleId(MODULE_ID);
        s.setModuleName(getModuleName());
        s.setTitle(t == null ? "" : t.getTitle());
        s.setArtist(t == null ? "" : t.getDisplayArtist());
        s.setAlbum(t == null ? "" : t.getAlbum());
        s.setPlaying(playing);
        s.setCanPlayPause(true);
        s.setCanGoPrevious(queue.getCurrentIndex() > 0 || queue.getRepeat() != com.lifeos.musicplayer.playback.RepeatMode.OFF);
        s.setCanGoNext(!queue.getTracks().isEmpty());
        s.setCanChangeVolume(true);
        s.setCanSeek(durationMs > 0);
        s.setPositionMs(positionMs);
        s.setDurationMs(durationMs > 0 ? durationMs : (t == null ? 0 : t.getDurationMs()));
        s.setVolume(controller.getVolume());
        if (t != null && covers != null) {
            Path coverPath = covers.lookup(t);
            if (coverPath != null) s.setCoverImagePath(coverPath.toString());
        }
        mc.publish(s, ctrl);
    }

    /** Hosts oder native Adapter (Windows SMTC, Linux MPRIS, macOS MPNowPlaying)
     *  können hier eine Bridge andocken, ohne den PlaybackController zu kennen. */
    public DefaultSystemMediaControls getSystemMediaControls() {
        return systemControls;
    }

    @Override
    public Node getMainView() { return mainView; }

    @Override
    public Node getDashboardWidget() { return new DashboardWidget(controller, covers); }

    @Override
    public ModuleAIContext getAIContext() {
        return new ModuleAIContext(
            "Du steuerst den LifeOS Musik-Player. Du kannst Titel, Alben und Künstler:innen suchen, "
            + "Wiedergabe starten/pausieren/überspringen, zur Warteschlange hinzufügen und Playlists anlegen. "
            + "Nutze Tools nur, wenn die Nutzer:in wirklich Musik steuern oder finden möchte.",
            null,
            aiTools
        );
    }

    @Override
    public void onThemeChanged(LifeOSThemeState theme) {}

    @Override
    public void onShutdown() {
        try {
            if (controller != null) controller.stop();
            if (systemControls != null) systemControls.shutdown();
            if (core != null && core.getMediaCenter() != null) core.getMediaCenter().clear(MODULE_ID);
            if (library != null && store != null) store.saveTracks(library.getTracks());
        } catch (Exception e) {
            System.err.println("[MusicPlayer] shutdown error: " + e.getMessage());
        }
    }
}
