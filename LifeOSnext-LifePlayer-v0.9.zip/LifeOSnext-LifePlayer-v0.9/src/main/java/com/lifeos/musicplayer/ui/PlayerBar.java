package com.lifeos.musicplayer.ui;

import com.lifeos.musicplayer.library.CoverArtService;
import com.lifeos.musicplayer.model.Track;
import com.lifeos.musicplayer.playback.PlaybackController;
import com.lifeos.musicplayer.playback.PlaybackState;
import com.lifeos.musicplayer.playback.RepeatMode;
import javafx.application.Platform;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.Slider;
import javafx.scene.control.ToggleButton;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Pane;
import javafx.scene.layout.Priority;
import javafx.scene.layout.Region;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import javafx.scene.shape.Rectangle;

public final class PlayerBar extends StackPane {

    private final PlaybackController controller;
    private final Label titleLabel = new Label("—");
    private final Label artistLabel = new Label("");
    private final Label hdBadge = new Label("HD");
    private final Slider seek = new Slider();
    private final Label position = new Label("0:00");
    private final Label duration = new Label("0:00");
    private final Button playPause = new Button();
    private final Button next = new Button();
    private final Button prev = new Button();
    private final ToggleButton shuffle = new ToggleButton();
    private final ToggleButton repeat = new ToggleButton();
    private final ToggleButton favorite = new ToggleButton();
    private final Button trackMore = new Button();
    private final Button queueButton = new Button();
    private boolean seekDragging;

    private final CoverView cover;
    private Runnable onInfoClick;

    public void setOnInfoClick(Runnable r) { this.onInfoClick = r; }

    public PlayerBar(PlaybackController controller, CoverArtService covers) {
        this.controller = controller;
        this.cover = new CoverView(covers, 56, 6);
        getStyleClass().add("music-player-bar");

        Region glow = new Region();
        glow.getStyleClass().add("music-player-glow");
        glow.setMouseTransparent(true);
        glow.setMaxWidth(680);
        glow.setMaxHeight(120);
        glow.setMinSize(680, 120);
        glow.setPrefSize(680, 120);

        VBox bar = buildBar();
        getChildren().addAll(glow, bar);
        StackPane.setAlignment(glow, Pos.CENTER);
        StackPane.setAlignment(bar, Pos.CENTER);

        controller.addListener(new PlaybackController.Listener() {
            @Override public void onTrackChanged(Track t) {
                Platform.runLater(() -> {
                    titleLabel.setText(t == null ? "—" : t.getTitle());
                    artistLabel.setText(t == null ? "" : t.getDisplayArtist()
                        + (t.getAlbum() == null || t.getAlbum().isBlank() ? "" : "  ·  " + t.getAlbum()));
                    cover.showTrack(t);
                    hdBadge.setVisible(isHd(t));
                    hdBadge.setManaged(isHd(t));
                });
            }
            @Override public void onStateChanged(PlaybackState s) {
                Platform.runLater(() -> playPause.setGraphic(
                    s == PlaybackState.PLAYING ? Icons.pause(20) : Icons.play(20)));
            }
            @Override public void onPosition(long pos, long dur) {
                if (seekDragging) return;
                Platform.runLater(() -> {
                    position.setText(Formatting.time(pos));
                    duration.setText(Formatting.time(dur));
                    if (dur > 0) seek.setValue(pos / (double) dur);
                });
            }
        });
        updateRepeatGraphic(controller.getQueue().getRepeat());
    }

    private VBox buildBar() {
        titleLabel.getStyleClass().add("music-track-title");
        artistLabel.getStyleClass().add("music-track-artist");
        hdBadge.getStyleClass().add("music-hd-badge");
        hdBadge.setVisible(false);
        hdBadge.setManaged(false);

        HBox titleRow = new HBox(8, titleLabel, hdBadge);
        titleRow.setAlignment(Pos.CENTER_LEFT);
        VBox text = new VBox(2, titleRow, artistLabel);
        text.setAlignment(Pos.CENTER_LEFT);
        text.setStyle("-fx-cursor: hand;");
        text.setOnMouseClicked(e -> { if (onInfoClick != null) onInfoClick.run(); });
        cover.setStyle("-fx-cursor: hand;");
        cover.setOnMouseClicked(e -> { if (onInfoClick != null) onInfoClick.run(); });

        favorite.setGraphic(Icons.heart(18));
        favorite.getStyleClass().add("music-favorite-button");
        trackMore.setGraphic(Icons.moreHorizontal(18));
        trackMore.getStyleClass().add("music-icon-button");

        HBox info = new HBox(12, cover, text, favorite, trackMore);
        info.setAlignment(Pos.CENTER_LEFT);
        info.setMinWidth(260);
        info.setPrefWidth(320);
        info.setMaxWidth(360);
        info.getStyleClass().add("music-player-info");

        prev.setGraphic(Icons.skipPrev(20));
        next.setGraphic(Icons.skipNext(20));
        playPause.setGraphic(Icons.play(20));
        shuffle.setGraphic(Icons.shuffle(18));
        repeat.setGraphic(Icons.repeat(18));

        for (Button b : new Button[] {prev, next}) b.getStyleClass().addAll("music-transport-button", "music-icon-button");
        playPause.getStyleClass().addAll("music-transport-button", "music-transport-primary");
        for (ToggleButton tb : new ToggleButton[] {shuffle, repeat}) tb.getStyleClass().addAll("music-transport-button", "music-icon-button");

        prev.setOnAction(e -> controller.previous());
        next.setOnAction(e -> controller.next());
        playPause.setOnAction(e -> controller.togglePlay());

        shuffle.setOnAction(e -> controller.getQueue().setShuffle(shuffle.isSelected()));
        repeat.setOnAction(e -> {
            RepeatMode cur = controller.getQueue().getRepeat();
            RepeatMode nxt = switch (cur) { case OFF -> RepeatMode.ALL; case ALL -> RepeatMode.ONE; case ONE -> RepeatMode.OFF; };
            controller.getQueue().setRepeat(nxt);
            updateRepeatGraphic(nxt);
        });

        seek.setMin(0);
        seek.setMax(1);
        seek.getStyleClass().add("music-seek");
        seek.setOnMousePressed(e -> seekDragging = true);
        seek.setOnMouseReleased(e -> {
            long dur = controller.getDurationMs();
            controller.seek((long) (seek.getValue() * dur));
            seekDragging = false;
        });

        // Orange "filled" track behind the slider. The slider's own track is
        // styled transparent in CSS so this rectangle shows through.
        Rectangle baseTrack = new Rectangle();
        baseTrack.setHeight(4);
        baseTrack.setArcWidth(4);
        baseTrack.setArcHeight(4);
        baseTrack.getStyleClass().add("music-seek-base");
        baseTrack.setMouseTransparent(true);
        Rectangle fill = new Rectangle();
        fill.setHeight(4);
        fill.setArcWidth(4);
        fill.setArcHeight(4);
        fill.getStyleClass().add("music-seek-fill");
        fill.setMouseTransparent(true);
        Pane fillLayer = new Pane(baseTrack, fill);
        fillLayer.setMouseTransparent(true);
        fillLayer.setManaged(false);
        Runnable updateFill = () -> {
            double w = seek.getWidth();
            double h = seek.getHeight();
            if (w <= 0 || h <= 0) return;
            double v = Math.max(0, Math.min(1, seek.getValue()));
            double startX = 7;
            double trackW = Math.max(0, w - 14);
            double y = h / 2.0 - 2;
            baseTrack.setX(startX);
            baseTrack.setY(y);
            baseTrack.setWidth(trackW);
            fill.setX(startX);
            fill.setY(y);
            fill.setWidth(trackW * v);
        };
        seek.valueProperty().addListener((obs, o, n) -> updateFill.run());
        seek.widthProperty().addListener((obs, o, n) -> updateFill.run());
        seek.heightProperty().addListener((obs, o, n) -> updateFill.run());

        position.getStyleClass().add("music-time-label");
        duration.getStyleClass().add("music-time-label");

        StackPane seekStack = new StackPane(fillLayer, seek);
        seekStack.setAlignment(Pos.CENTER_LEFT);
        // Keep the fill aligned to the slider's actual track area
        seek.layoutBoundsProperty().addListener((obs, o, n) -> {
            fillLayer.setLayoutX(seek.getLayoutX());
            fillLayer.setLayoutY(seek.getLayoutY());
            fillLayer.resize(seek.getWidth(), seek.getHeight());
        });
        HBox seekRow = new HBox(10, position, seekStack, duration);
        seekRow.setAlignment(Pos.CENTER);
        seekRow.setPadding(new Insets(0, 18, 0, 18));
        HBox.setHgrow(seekStack, Priority.ALWAYS);
        HBox.setHgrow(seek, Priority.ALWAYS);
        seek.setMaxWidth(Double.MAX_VALUE);
        seekRow.getStyleClass().add("music-seek-row");

        // 1. Die harte Begrenzung der Leiste (100 Pixel breit, 14 Pixel hoch)
        Pane customVolume = new Pane();
        customVolume.setPrefSize(100, 14);
        customVolume.setMinSize(100, 14);
        customVolume.setMaxSize(100, 14);
        customVolume.setCursor(javafx.scene.Cursor.HAND);

        // 2. Der statische Hintergrund-Track
        Rectangle volBase = new Rectangle(0, 5, 100, 4);
        volBase.getStyleClass().add("music-seek-base");
        volBase.setArcWidth(4);
        volBase.setArcHeight(4);

        // 3. Der farbige Füllstand (berechnet aus der aktuellen Controller-Lautstärke)
        Rectangle volFill = new Rectangle(0, 5, 100 * controller.getVolume(), 4);
        volFill.getStyleClass().add("music-seek-fill");
        volFill.setArcWidth(4);
        volFill.setArcHeight(4);

        // 4. Der runde Anfasser (Thumb)
        javafx.scene.shape.Circle volThumb = new javafx.scene.shape.Circle(100 * controller.getVolume(), 7, 7);
        volThumb.setStyle("-fx-fill: -music-accent;");
        volThumb.setEffect(new javafx.scene.effect.DropShadow(4, 0, 1, javafx.scene.paint.Color.rgb(0, 0, 0, 0.5)));

        customVolume.getChildren().addAll(volBase, volFill, volThumb);

        // 5. Die Logik: Maus-Klick und -Bewegung auslesen
        javafx.event.EventHandler<javafx.scene.input.MouseEvent> handleVolMouse = e -> {
            double x = Math.max(0, Math.min(100, e.getX())); // Beschränkt den Klick auf 0 bis 100 Pixel
            double newVol = x / 100.0; // Umrechnung in den Wertebereich 0.0 bis 1.0

            controller.setVolume(newVol);
            volFill.setWidth(x);       // Füllstand optisch anpassen
            volThumb.setCenterX(x);    // Anfasser optisch verschieben
        };

        customVolume.setOnMousePressed(handleVolMouse);
        customVolume.setOnMouseDragged(handleVolMouse);

        // 6. Zusammenbauen der Box mit festen Grenzen
        Label vIcon = new Label();
        vIcon.setGraphic(Icons.volume(16));
        vIcon.getStyleClass().add("music-volume-icon");

        // Lautstärkeregler4 verschoben zu den Transport Controls
        HBox transport = new HBox(12, vIcon, customVolume, shuffle, prev, playPause, next, repeat);
        transport.setAlignment(Pos.CENTER);

        queueButton.setGraphic(Icons.queueIcon(18));
        queueButton.getStyleClass().add("music-icon-button");

        HBox volBox = new HBox(10, queueButton);
        volBox.setAlignment(Pos.CENTER_RIGHT);
        volBox.setMinWidth(180);
        volBox.setPrefWidth(180);
        volBox.setMaxWidth(180);
        volBox.getStyleClass().add("music-player-volbox");

        // Control row: info left, transport center, volume right.
        StackPane transportCenter = new StackPane(transport);
        StackPane.setAlignment(transport, Pos.CENTER);

        BorderPane controlRow = new BorderPane();
        controlRow.setLeft(info);
        controlRow.setCenter(transportCenter);
        controlRow.setRight(volBox);
        BorderPane.setAlignment(info, Pos.CENTER_LEFT);
        BorderPane.setAlignment(volBox, Pos.CENTER_RIGHT);
        BorderPane.setMargin(info, new Insets(0, 16, 0, 0));
        BorderPane.setMargin(volBox, new Insets(0, 0, 0, 16));

        // Final composition: seek bar on its OWN row at the top of the
        // player, controls below. This eliminates any overlap between
        // the seek-track (which spans the player width) and the volume
        // slider (which sits in a 200px box on the right).
        VBox bar = new VBox(6, seekRow, controlRow);
        bar.setAlignment(Pos.CENTER);
        bar.setPadding(new Insets(8, 18, 8, 14));
        bar.getStyleClass().add("music-player-bar-inner");
        return bar;
    }

    private static boolean isHd(Track t) {
        if (t == null) return false;
        String f = t.getFormat() == null ? "" : t.getFormat().toLowerCase();
        return f.contains("flac") || f.contains("wav") || f.contains("alac") || f.contains("aiff");
    }

    private void updateRepeatGraphic(RepeatMode m) {
        repeat.setGraphic(m == RepeatMode.ONE ? Icons.repeatOne(18) : Icons.repeat(18));
        repeat.setSelected(m != RepeatMode.OFF);
    }
}
