package com.lifeos.musicplayer.ui;

import com.lifeos.musicplayer.library.CoverArtService;
import com.lifeos.musicplayer.library.LibraryStore;
import com.lifeos.musicplayer.library.MusicLibrary;
import com.lifeos.musicplayer.model.Album;
import com.lifeos.musicplayer.playback.PlaybackController;
import javafx.application.Platform;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.Button;
import javafx.scene.control.ScrollPane;
import javafx.scene.control.ToggleButton;
import javafx.scene.control.ToggleGroup;
import javafx.scene.input.MouseButton;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.TilePane;
import javafx.scene.layout.VBox;

public final class AlbumsTab extends BorderPane {

    enum Layout { LIST, GRID }

    private final MusicLibrary library;
    private final PlaybackController controller;
    private final CoverArtService covers;
    private final LibraryStore store;
    private final VBox listContainer = new VBox(10);
    private final TilePane gridContainer = new TilePane();
    private final VBox detailContainer = new VBox(12);
    private final ScrollPane scroller = new ScrollPane();
    private Layout layout = Layout.LIST;
    private Album detailAlbum;

    public void showAlbumDetail(String albumName) {
        for (Album a : library.getAlbums()) {
            if (a.getName().equalsIgnoreCase(albumName)) {
                openDetail(a);
                break;
            }
        }
    }

    public AlbumsTab(MusicLibrary library, PlaybackController controller, CoverArtService covers) {
        this(library, controller, covers, null);
    }

    public AlbumsTab(MusicLibrary library, PlaybackController controller, CoverArtService covers, LibraryStore store) {
        this.library = library;
        this.controller = controller;
        this.covers = covers;
        this.store = store;

        // Innen-Padding so, dass die Scrollbar nicht an der Fensterkante klebt.
        listContainer.setPadding(new Insets(8, 28, 24, 24));

        gridContainer.setHgap(20);
        gridContainer.setVgap(24);
        gridContainer.setPadding(new Insets(8, 28, 24, 24));
        gridContainer.setPrefColumns(0);
        gridContainer.setPrefTileWidth(180);

        detailContainer.setPadding(new Insets(8, 28, 24, 24));

        scroller.setFitToWidth(true);
        scroller.getStyleClass().add("music-albums-scroll");
        scroller.setContent(listContainer);
        installMiddleClickAutoscroll(scroller);

        setTop(buildToolbar());
        setCenter(scroller);

        library.addListener(lib -> Platform.runLater(this::refresh));
        refresh();
    }

    private HBox buildToolbar() {
        ToggleGroup group = new ToggleGroup();
        ToggleButton listBtn = new ToggleButton("Liste");
        listBtn.setGraphic(Icons.listView(14));
        listBtn.getStyleClass().add("music-segment-button");
        listBtn.setToggleGroup(group);
        listBtn.setSelected(true);

        ToggleButton gridBtn = new ToggleButton("Raster");
        gridBtn.setGraphic(Icons.gridView(14));
        gridBtn.getStyleClass().add("music-segment-button");
        gridBtn.setToggleGroup(group);

        listBtn.setOnAction(e -> {
            if (!listBtn.isSelected()) { listBtn.setSelected(true); return; }
            setLayout(Layout.LIST);
        });
        gridBtn.setOnAction(e -> {
            if (!gridBtn.isSelected()) { gridBtn.setSelected(true); return; }
            setLayout(Layout.GRID);
        });

        HBox segment = new HBox(0, listBtn, gridBtn);
        segment.getStyleClass().add("music-segment");
        segment.setAlignment(Pos.CENTER_LEFT);

        HBox toolbar = new HBox(12, segment);
        toolbar.setAlignment(Pos.CENTER_LEFT);
        toolbar.setPadding(new Insets(14, 24, 6, 24));
        return toolbar;
    }

    private void setLayout(Layout l) {
        if (this.layout == l && detailAlbum == null) return;
        this.layout = l;
        this.detailAlbum = null;
        scroller.setContent(l == Layout.LIST ? listContainer : gridContainer);
        refresh();
    }

    private void refresh() {
        if (detailAlbum != null) {
            showDetail(detailAlbum);
            return;
        }
        if (layout == Layout.LIST) {
            listContainer.getChildren().clear();
            for (Album a : library.getAlbums()) {
                listContainer.getChildren().add(new AlbumCard(a, controller, covers, library, store));
            }
        } else {
            gridContainer.getChildren().clear();
            for (Album a : library.getAlbums()) {
                AlbumGridCell cell = new AlbumGridCell(a, controller, covers);
                cell.setOnMouseClicked(e -> {
                    if (e.getButton() != MouseButton.PRIMARY) return;
                    if (e.getClickCount() == 2) controller.playAll(a.getTracks(), 0);
                    else if (e.getClickCount() == 1) openDetail(a);
                });
                gridContainer.getChildren().add(cell);
            }
        }
    }

    private void openDetail(Album album) {
        this.detailAlbum = album;
        scroller.setContent(detailContainer);
        showDetail(album);
    }

    private void showDetail(Album album) {
        Button back = new Button("Zurück zur Rasteransicht");
        back.setGraphic(Icons.chevronDown(14));
        back.getGraphic().setRotate(90);
        back.getStyleClass().add("music-header-button");
        back.setOnAction(e -> {
            detailAlbum = null;
            scroller.setContent(gridContainer);
            refresh();
        });

        AlbumCard card = new AlbumCard(album, controller, covers, library, store);
        card.expand();

        detailContainer.getChildren().setAll(back, card);
    }

    /** Mausrad-Klick togglet einen Auto-Scroll-Modus: die Maus-Y-Position
     *  steuert dann die Scroll-Geschwindigkeit, bis erneut geklickt wird.
     *  Standardverhalten in vielen Desktop-Apps, JavaFX bringt es nicht mit. */
    private void installMiddleClickAutoscroll(ScrollPane sp) {
        AutoScrollState state = new AutoScrollState();
        sp.addEventFilter(javafx.scene.input.MouseEvent.MOUSE_PRESSED, e -> {
            if (e.getButton() != MouseButton.MIDDLE) return;
            e.consume();
            if (state.active) {
                state.stop();
            } else {
                state.start(sp, e.getSceneY());
            }
        });
        sp.addEventFilter(javafx.scene.input.MouseEvent.MOUSE_MOVED, e -> {
            if (!state.active) return;
            state.currentY = e.getSceneY();
        });
    }

    private static final class AutoScrollState {
        boolean active;
        double anchorY;
        double currentY;
        javafx.animation.AnimationTimer timer;

        void start(ScrollPane sp, double y) {
            active = true;
            anchorY = y;
            currentY = y;
            timer = new javafx.animation.AnimationTimer() {
                @Override public void handle(long now) {
                    double dy = (currentY - anchorY) / 30.0;
                    double v = Math.max(0, Math.min(1, sp.getVvalue() + dy * 0.002));
                    sp.setVvalue(v);
                }
            };
            timer.start();
            sp.setCursor(javafx.scene.Cursor.V_RESIZE);
        }

        void stop() {
            active = false;
            if (timer != null) timer.stop();
        }
    }
}
