package com.lifeos.musicplayer.ui;

import com.lifeos.musicplayer.library.CoverArtService;
import com.lifeos.musicplayer.lyrics.LrcParser;
import com.lifeos.musicplayer.lyrics.LyricsContent;
import com.lifeos.musicplayer.lyrics.LyricsService;
import com.lifeos.musicplayer.model.Track;
import com.lifeos.musicplayer.playback.PlaybackController;
import javafx.animation.Interpolator;
import javafx.animation.KeyFrame;
import javafx.animation.KeyValue;
import javafx.animation.Timeline;
import javafx.application.Platform;
import javafx.beans.property.SimpleDoubleProperty;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.ScrollPane;
import javafx.scene.control.TextArea;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Priority;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import javafx.stage.FileChooser;
import javafx.util.Duration;

import java.io.File;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.util.ArrayList;
import java.util.List;

public final class LyricsTab extends BorderPane {

    private final LyricsService lyrics;
    private final PlaybackController controller;
    private final CoverView cover;

    private final TextArea textArea = new TextArea();
    private final VBox timedBox = new VBox(4);
    private final ScrollPane timedScroll = new ScrollPane(timedBox);

    private final StackPane lyricsHost = new StackPane();
    private final Label addPrompt = new Label("Keine Lyrics für diesen Titel gespeichert.");
    private final Button addBtn = new Button("Lyrics hinzufügen");
    private final Button uploadBtn = new Button("Hochladen");
    private final Button uploadInlineBtn = new Button(".lrc / .txt hochladen");
    private final Button fetchBtn = new Button("Per LifeOS-LLM holen");
    private final Button saveBtn = new Button("Speichern");
    private final Button editBtn = new Button("Bearbeiten");

    private final Label titleLabel = new Label("Kein Titel gewählt");
    private final Label artistLabel = new Label("");
    private final Label metaLabel = new Label("");

    private Track shownTrack;
    private Runnable onBack;

    private List<LrcParser.TimedLine> timedLines = List.of();
    private List<Label> timedLabels = List.of();
    private int currentLineIdx = -1;
    private Timeline scrollAnim;

    public void setOnBack(Runnable onBack) {
        this.onBack = onBack;
    }

    public LyricsTab(PlaybackController controller, LyricsService lyrics, CoverArtService covers) {
        this.controller = controller;
        this.lyrics = lyrics;
        this.cover = new CoverView(covers, 220, 14);

        titleLabel.getStyleClass().add("music-nowplaying-title");
        artistLabel.getStyleClass().add("music-nowplaying-artist");
        metaLabel.getStyleClass().add("music-nowplaying-meta");
        titleLabel.setWrapText(true);

        textArea.setWrapText(true);
        textArea.setEditable(true);
        textArea.getStyleClass().add("music-lyrics-text");

        timedBox.setPadding(new Insets(60, 8, 60, 8));
        timedBox.setAlignment(Pos.TOP_LEFT);
        timedBox.getStyleClass().add("music-lyrics-timed");
        timedScroll.setFitToWidth(true);
        timedScroll.setHbarPolicy(ScrollPane.ScrollBarPolicy.NEVER);
        timedScroll.getStyleClass().add("music-lyrics-timed-scroll");

        addBtn.setOnAction(e -> openEditor(""));
        uploadBtn.setOnAction(e -> pickAndLoadFile());
        uploadInlineBtn.setOnAction(e -> pickAndLoadFile());
        fetchBtn.setOnAction(e -> {
            if (shownTrack == null) return;
            openEditor("Lade …");
            lyrics.fetchFromLLM(shownTrack).thenAccept(r -> Platform.runLater(() -> {
                textArea.setText(r == null ? "" : r);
                if (shownTrack != null) lyrics.saveLyrics(shownTrack, textArea.getText());
                reloadCurrent();
            }));
        });
        saveBtn.setOnAction(e -> {
            if (shownTrack == null) return;
            lyrics.saveLyrics(shownTrack, textArea.getText());
            reloadCurrent();
        });
        editBtn.setOnAction(e -> openEditor(currentRawText()));

        showEmptyState();

        HBox toolbar = new HBox(8, saveBtn, editBtn, fetchBtn, uploadBtn);
        toolbar.setAlignment(Pos.CENTER_RIGHT);

        VBox metaBox = new VBox(4, titleLabel, artistLabel, metaLabel);
        metaBox.setAlignment(Pos.CENTER_LEFT);
        HBox.setHgrow(metaBox, Priority.ALWAYS);

        Button backBtn = new Button("Zurück");
        backBtn.getStyleClass().add("music-header-button");
        backBtn.setGraphic(Icons.chevronLeft(16));
        backBtn.setOnAction(e -> { if (onBack != null) onBack.run(); });

        HBox header = new HBox(20, backBtn, cover, metaBox, toolbar);
        header.setAlignment(Pos.CENTER_LEFT);
        header.setPadding(new Insets(18, 24, 14, 24));
        header.getStyleClass().add("music-nowplaying-header");

        lyricsHost.setPadding(new Insets(0, 24, 24, 24));

        setTop(header);
        setCenter(lyricsHost);

        controller.addListener(new PlaybackController.Listener() {
            @Override public void onTrackChanged(Track t) { showTrack(t); }
            @Override public void onPosition(long posMs, long durMs) {
                if (timedLines.isEmpty()) return;
                Platform.runLater(() -> updateActiveLine(posMs));
            }
        });
    }

    private String currentRawText() {
        if (!timedLines.isEmpty()) {
            StringBuilder sb = new StringBuilder();
            for (LrcParser.TimedLine l : timedLines) {
                sb.append(String.format("[%02d:%02d.%02d]%s%n",
                    l.timeMs() / 60_000,
                    (l.timeMs() / 1000) % 60,
                    (l.timeMs() / 10) % 100,
                    l.text()));
            }
            return sb.toString();
        }
        return textArea.getText();
    }

    private void reloadCurrent() {
        if (shownTrack != null) showTrack(shownTrack);
    }

    private void pickAndLoadFile() {
        FileChooser chooser = new FileChooser();
        chooser.setTitle("Lyrics-Datei wählen");
        chooser.getExtensionFilters().addAll(
            new FileChooser.ExtensionFilter("Lyrics (LRC, TXT, MD, NFO)", "*.lrc", "*.txt", "*.md", "*.nfo"),
            new FileChooser.ExtensionFilter("Alle Dateien", "*.*"));
        File f = chooser.showOpenDialog(getScene() == null ? null : getScene().getWindow());
        if (f == null) return;
        try {
            String content = Files.readString(f.toPath(), StandardCharsets.UTF_8);
            if (shownTrack != null) {
                lyrics.saveLyrics(shownTrack, content);
                reloadCurrent();
            } else {
                openEditor(content);
            }
        } catch (Exception ex) {
            openEditor("Fehler beim Lesen: " + ex.getMessage());
        }
    }

    private void openEditor(String text) {
        textArea.setText(text == null ? "" : text);
        lyricsHost.getChildren().setAll(textArea);
        editBtn.setDisable(true);
        saveBtn.setDisable(false);
    }

    private void showEmptyState() {
        Label hint = new Label("Tipp: .lrc-Dateien mit [mm:ss.xx]-Markern laufen automatisch zum Song mit.");
        hint.getStyleClass().add("music-lyrics-empty-hint");
        hint.setWrapText(true);
        hint.setMaxWidth(420);
        VBox empty = new VBox(12, addPrompt, addBtn, uploadInlineBtn, fetchBtn, hint);
        empty.setAlignment(Pos.CENTER);
        empty.getStyleClass().add("music-lyrics-empty");
        lyricsHost.getChildren().setAll(empty);
        timedLines = List.of();
        timedLabels = List.of();
        currentLineIdx = -1;
        editBtn.setDisable(true);
        saveBtn.setDisable(false);
    }

    private void showPlainText(String text) {
        textArea.setText(text == null ? "" : text);
        textArea.setEditable(true);
        lyricsHost.getChildren().setAll(textArea);
        timedLines = List.of();
        timedLabels = List.of();
        currentLineIdx = -1;
        editBtn.setDisable(true);
        saveBtn.setDisable(false);
    }

    private void showTimed(List<LrcParser.TimedLine> lines) {
        this.timedLines = lines;
        timedBox.getChildren().clear();
        List<Label> labels = new ArrayList<>(lines.size());
        for (LrcParser.TimedLine l : lines) {
            Label lbl = new Label(l.text().isEmpty() ? " " : l.text());
            lbl.getStyleClass().add("music-lyrics-line");
            lbl.setWrapText(true);
            lbl.setMaxWidth(Double.MAX_VALUE);
            labels.add(lbl);
            timedBox.getChildren().add(lbl);
        }
        this.timedLabels = labels;
        this.currentLineIdx = -1;
        lyricsHost.getChildren().setAll(timedScroll);
        editBtn.setDisable(false);
        saveBtn.setDisable(true);
        // Direkt auf aktuelle Position springen, damit nicht erst der nächste
        // Position-Tick die richtige Zeile findet.
        updateActiveLine(controller.getPositionMs());
    }

    private void updateActiveLine(long posMs) {
        if (timedLines.isEmpty() || timedLabels.isEmpty()) return;
        int active = findActiveLine(posMs);
        if (active == currentLineIdx) return;
        if (currentLineIdx >= 0 && currentLineIdx < timedLabels.size()) {
            timedLabels.get(currentLineIdx).getStyleClass().remove("music-lyrics-line-active");
        }
        currentLineIdx = active;
        if (active < 0) return;
        Label l = timedLabels.get(active);
        if (!l.getStyleClass().contains("music-lyrics-line-active")) {
            l.getStyleClass().add("music-lyrics-line-active");
        }
        smoothScrollToLabel(l);
    }

    private int findActiveLine(long posMs) {
        int lo = 0, hi = timedLines.size() - 1, best = -1;
        while (lo <= hi) {
            int mid = (lo + hi) >>> 1;
            if (timedLines.get(mid).timeMs() <= posMs) { best = mid; lo = mid + 1; }
            else hi = mid - 1;
        }
        return best;
    }

    private void smoothScrollToLabel(Label l) {
        double contentH = timedBox.getHeight();
        double viewH = timedScroll.getViewportBounds().getHeight();
        if (contentH <= viewH || l.getHeight() == 0) return;
        double targetCenterY = l.getBoundsInParent().getMinY() + l.getHeight() / 2.0;
        double targetV = (targetCenterY - viewH / 2.0) / (contentH - viewH);
        targetV = Math.max(0, Math.min(1, targetV));

        if (scrollAnim != null) scrollAnim.stop();
        SimpleDoubleProperty v = new SimpleDoubleProperty(timedScroll.getVvalue());
        v.addListener((obs, o, n) -> timedScroll.setVvalue(n.doubleValue()));
        scrollAnim = new Timeline(new KeyFrame(Duration.millis(280),
            new KeyValue(v, targetV, Interpolator.EASE_BOTH)));
        scrollAnim.play();
    }

    public void showTrack(Track t) {
        this.shownTrack = t;
        Platform.runLater(() -> {
            if (t == null) {
                titleLabel.setText("Kein Titel gewählt");
                artistLabel.setText("");
                metaLabel.setText("");
                cover.showTrack(null);
                showEmptyState();
                return;
            }
            titleLabel.setText(t.getTitle());
            artistLabel.setText(t.getDisplayArtist());
            StringBuilder meta = new StringBuilder();
            if (t.getAlbum() != null && !t.getAlbum().isBlank()) meta.append(t.getAlbum());
            if (t.getYear() > 0) {
                if (meta.length() > 0) meta.append("  ·  ");
                meta.append(t.getYear());
            }
            metaLabel.setText(meta.toString());
            cover.showTrack(t);
        });
        lyrics.loadLyrics(t).thenAccept(content -> Platform.runLater(() -> {
            if (t != shownTrack) return;  // Inzwischen umgeschaltet
            if (content == null || content.isEmpty()) {
                showEmptyState();
            } else if (content.isTimed()) {
                showTimed(content.timedLines());
            } else {
                showPlainText(content.rawText());
            }
        }));
    }
}
