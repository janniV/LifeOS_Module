package com.lifeos.musicplayer.ui;

import com.lifeos.musicplayer.library.CoverArtService;
import com.lifeos.musicplayer.library.LibraryStore;
import com.lifeos.musicplayer.library.MusicLibrary;
import com.lifeos.musicplayer.model.Album;
import com.lifeos.musicplayer.model.Track;
import com.lifeos.musicplayer.playback.PlaybackController;
import javafx.animation.RotateTransition;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Node;
import javafx.scene.control.Button;
import javafx.scene.control.ContextMenu;
import javafx.scene.control.Label;
import javafx.scene.control.MenuItem;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Priority;
import javafx.scene.layout.Region;
import javafx.scene.layout.VBox;
import javafx.util.Duration;

public final class AlbumCard extends VBox {

    private VBox tracksBoxRef;
    private Node chevronRef;

    public AlbumCard(Album album, PlaybackController controller, CoverArtService covers) {
        this(album, controller, covers, null, null);
    }

    public AlbumCard(Album album, PlaybackController controller, CoverArtService covers,
                     MusicLibrary library, LibraryStore store) {
        getStyleClass().add("music-album-card");
        setSpacing(6);
        setPadding(new Insets(10, 14, 10, 10));

        CoverView cover = new CoverView(covers, 72, 8);
        cover.showAlbum(album);

        Label header = new Label(album.getName().isBlank() ? "(Unbekanntes Album)" : album.getName());
        header.getStyleClass().add("music-album-title");
        header.setWrapText(true);

        Label sub = new Label(album.getArtist()
            + (album.getYear() > 0 ? "  ·  " + album.getYear() : "")
            + "  ·  " + album.getTracks().size() + " Titel  ·  " + Formatting.time(album.getTotalDurationMs()));
        sub.getStyleClass().add("music-album-subtitle");

        Button playAll = new Button("Album abspielen");
        playAll.setGraphic(Icons.play(12));
        playAll.getStyleClass().add("music-album-play");
        playAll.setOnAction(e -> controller.playAll(album.getTracks(), 0));

        Button more = new Button();
        more.setGraphic(Icons.moreVertical(16));
        more.getStyleClass().add("music-album-more");
        ContextMenu moreMenu = new ContextMenu();
        MenuItem mAdd = new MenuItem("Zur Warteschlange hinzufügen");
        mAdd.setOnAction(e -> controller.getQueue().appendAll(album.getTracks()));
        moreMenu.getItems().add(mAdd);
        if (library != null) {
            MenuItem mEdit = new MenuItem("Album bearbeiten…");
            mEdit.setOnAction(e -> TagEditDialog.editAlbum(album, library, store));
            moreMenu.getItems().add(mEdit);
        }
        more.setOnAction(e -> moreMenu.show(more, javafx.geometry.Side.BOTTOM, 0, 0));

        VBox tracksBox = new VBox(2);
        tracksBox.setPadding(new Insets(6, 0, 0, 86));
        for (int i = 0; i < album.getTracks().size(); i++) {
            Track t = album.getTracks().get(i);
            final int idx = i;
            Label line = new Label(formatTrackNumber(t) + "  " + t.getTitle()
                + "      " + Formatting.time(t.getDurationMs()));
            line.getStyleClass().add("music-album-track");
            line.setOnMouseClicked(e -> {
                if (e.getButton() != javafx.scene.input.MouseButton.PRIMARY) return;
                // Einfach-Klick startet den Titel sofort (innerhalb des Albums).
                controller.playAll(album.getTracks(), idx);
            });
            if (library != null) {
                ContextMenu rowMenu = new ContextMenu();
                MenuItem mEditTrack = new MenuItem("Titel bearbeiten…");
                mEditTrack.setOnAction(ev -> TagEditDialog.editTrack(t, library, store));
                rowMenu.getItems().add(mEditTrack);
                line.setOnContextMenuRequested(ev ->
                    rowMenu.show(line, ev.getScreenX(), ev.getScreenY()));
            }
            tracksBox.getChildren().add(line);
        }
        tracksBox.setVisible(false);
        tracksBox.setManaged(false);
        this.tracksBoxRef = tracksBox;

        Button expand = new Button();
        Node chevron = Icons.chevronDown(18);
        this.chevronRef = chevron;
        expand.setGraphic(chevron);
        expand.getStyleClass().add("music-album-expand");
        expand.setOnAction(e -> toggleExpansion(tracksBox, chevron));

        Region spacer = new Region();
        HBox.setHgrow(spacer, Priority.ALWAYS);
        VBox titles = new VBox(4, header, sub);
        titles.setAlignment(Pos.CENTER_LEFT);
        HBox actions = new HBox(8, playAll, more, expand);
        actions.setAlignment(Pos.CENTER_RIGHT);
        HBox top = new HBox(18, cover, titles, spacer, actions);
        top.setAlignment(Pos.CENTER_LEFT);

        // Klick auf Cover oder Titel klappt das Album ebenfalls auf/zu.
        cover.setOnMouseClicked(e -> toggleExpansion(tracksBox, chevron));
        titles.setOnMouseClicked(e -> toggleExpansion(tracksBox, chevron));
        cover.setStyle("-fx-cursor: hand;");
        titles.setStyle("-fx-cursor: hand;");

        getChildren().addAll(top, tracksBox);
    }

    private void toggleExpansion(VBox tracksBox, Node chevron) {
        setExpansion(tracksBox, chevron, !tracksBox.isManaged());
    }

    private void setExpansion(VBox tracksBox, Node chevron, boolean expanded) {
        tracksBox.setManaged(expanded);
        tracksBox.setVisible(expanded);
        RotateTransition rt = new RotateTransition(Duration.millis(180), chevron);
        rt.setToAngle(expanded ? 180 : 0);
        rt.play();
    }

    /** Klappt die Track-Liste programmatisch auf (z. B. für die
     *  Detail-Ansicht aus der Rasteransicht heraus). */
    public void expand() {
        if (tracksBoxRef != null && chevronRef != null) {
            setExpansion(tracksBoxRef, chevronRef, true);
        }
    }

    private static String formatTrackNumber(Track t) {
        int n = t.getTrackNumber();
        return n > 0 ? String.format("%2d.", n) : "  •";
    }
}
