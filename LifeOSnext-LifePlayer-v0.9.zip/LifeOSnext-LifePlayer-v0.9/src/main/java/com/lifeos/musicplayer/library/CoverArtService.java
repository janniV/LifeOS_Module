package com.lifeos.musicplayer.library;

import com.lifeos.musicplayer.model.Album;
import com.lifeos.musicplayer.model.Track;
import core.CoreServices;
import core.LifeOSFileReference;
import core.LifeOSFileService;
import org.jaudiotagger.audio.AudioFile;
import org.jaudiotagger.audio.AudioFileIO;
import org.jaudiotagger.tag.Tag;
import org.jaudiotagger.tag.images.Artwork;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.security.MessageDigest;
import java.util.HexFormat;
import java.util.List;
import java.util.concurrent.ConcurrentHashMap;

public final class CoverArtService {

    private final Path coversDir;
    private final NasCache cache;
    private final CoreServices core;
    private final String moduleId;
    private final ConcurrentHashMap<String, Path> resolved = new ConcurrentHashMap<>();
    private final ConcurrentHashMap<String, Boolean> missing = new ConcurrentHashMap<>();

    public CoverArtService(Path coversDir, NasCache cache) {
        this(coversDir, cache, null, null);
    }

    public CoverArtService(Path coversDir, NasCache cache, CoreServices core, String moduleId) {
        this.coversDir = coversDir;
        this.cache = cache;
        this.core = core;
        this.moduleId = moduleId;
        try { Files.createDirectories(coversDir); } catch (IOException ignored) {}
    }

    /** Liefert den Cover-Pfad eines Tracks oder null. Blockierend; immer von Hintergrundthread aufrufen. */
    public Path getOrExtract(Track track) {
        if (track == null) return null;
        String key = albumKey(track.getAlbum(), track.getDisplayArtist());
        Path cached = resolved.get(key);
        if (cached != null && Files.exists(cached)) return cached;
        if (Boolean.TRUE.equals(missing.get(key))) return null;

        for (String ext : new String[] {"jpg", "png"}) {
            Path candidate = coversDir.resolve(hash(key) + "." + ext);
            if (Files.exists(candidate) && fileSize(candidate) > 0) {
                resolved.put(key, candidate);
                return candidate;
            }
        }
        Path extracted = extractFromTrack(track, key);
        if (extracted != null) resolved.put(key, extracted);
        else missing.put(key, Boolean.TRUE);
        return extracted;
    }

    /** Quick-Lookup ohne Extraktion. Sicher vom FX-Thread aufrufbar. */
    public Path lookup(Track track) {
        if (track == null) return null;
        String key = albumKey(track.getAlbum(), track.getDisplayArtist());
        Path cached = resolved.get(key);
        if (cached != null && Files.exists(cached)) return cached;
        for (String ext : new String[] {"jpg", "png"}) {
            Path candidate = coversDir.resolve(hash(key) + "." + ext);
            if (Files.exists(candidate) && fileSize(candidate) > 0) {
                resolved.put(key, candidate);
                return candidate;
            }
        }
        return null;
    }

    public Path getForAlbum(Album album) {
        if (album == null || album.getTracks().isEmpty()) return null;
        return getOrExtract(album.getTracks().get(0));
    }

    private Path extractFromTrack(Track track, String key) {
        try {
            if (track.isLocal()) {
                File f = track.getLocalFile();
                if (f == null) return null;
                Path local = f.toPath();
                if (!Files.exists(local)) return null;
                Path folderCover = findCoverInFolder(local.getParent());
                if (folderCover != null) {
                    Path target = copyToCoversDir(folderCover, key);
                    return target != null ? target : folderCover;
                }
                return extractEmbeddedArtwork(local, key);
            }

            // Remote: bevor wir den ganzen Track ziehen, prüfen wir der
            // Reihe nach drei billige Quellen ab. Erst wenn alles
            // fehlschlägt, wird der komplette Track ggf. heruntergeladen.
            LifeOSFileReference ref = track.resolve(core, moduleId);
            if (ref == null) return null;

            // 1) Cover-Datei im Remote-Album-Ordner (cover.jpg/folder.png/...).
            Path remoteCover = findCoverInRemoteFolder(ref, key);
            if (remoteCover != null) return remoteCover;

            // 2) Falls der Track schon mal abgespielt und gecacht wurde:
            //    eingebettetes Artwork aus der lokalen Kopie ziehen, ohne
            //    irgendetwas neu herunterzuladen.
            Path alreadyCached = cache.resolve(ref);
            if (alreadyCached != null && Files.exists(alreadyCached) && fileSize(alreadyCached) > 0) {
                Path embedded = extractEmbeddedArtwork(alreadyCached, key);
                if (embedded != null) return embedded;
            }

            // 3) Partial-Read: die ersten ~8 MB der Remote-Datei streamen
            //    (ID3v2- und FLAC-Metadaten + Artwork liegen am Datei-
            //    anfang). Spart den vollständigen Track-Download.
            Path headCover = extractFromRemoteHead(ref, key);
            if (headCover != null) return headCover;

            // 4) Last resort: den ganzen Track cachen (nur falls die Datei
            //    Artwork am Dateiende hat, z. B. einige MP4-Container).
            Path local = cache.ensureCached(ref);
            if (!Files.exists(local)) return null;
            return extractEmbeddedArtwork(local, key);
        } catch (Exception e) {
            return null;
        }
    }

    /** Liest die ersten {@code HEAD_BYTES} der Remote-Datei in eine
     *  temporäre Datei und versucht daraus das eingebettete Artwork zu
     *  lesen. Funktioniert für MP3, FLAC, Ogg/Opus, WAV/AIFF — also für
     *  alle Formate, die ihre Tag-Blöcke an den Dateianfang stellen. */
    private static final long HEAD_BYTES = 8L * 1024 * 1024;
    private static final java.util.Set<String> HEAD_FORMATS = java.util.Set.of(
        "mp3", "flac", "ogg", "opus", "oga", "wav", "aiff", "aif"
    );

    private Path extractFromRemoteHead(LifeOSFileReference ref, String key) {
        if (core == null || ref == null) return null;
        LifeOSFileService fs = core.getFileService();
        if (fs == null) return null;
        String ext = extensionOf(baseName(ref));
        if (!HEAD_FORMATS.contains(ext)) return null;

        Path tmp = null;
        try {
            tmp = Files.createTempFile(coversDir, "head-", "." + ext);
            try (InputStream in = fs.openReadStream(ref);
                 OutputStream out = Files.newOutputStream(tmp)) {
                byte[] buf = new byte[64 * 1024];
                long total = 0;
                int n;
                while (total < HEAD_BYTES
                       && (n = in.read(buf, 0, (int) Math.min(buf.length, HEAD_BYTES - total))) >= 0) {
                    out.write(buf, 0, n);
                    total += n;
                }
            }
            return extractEmbeddedArtwork(tmp, key);
        } catch (Exception ignored) {
            return null;
        } finally {
            if (tmp != null) {
                try { Files.deleteIfExists(tmp); } catch (IOException ignored) {}
            }
        }
    }

    private Path extractEmbeddedArtwork(Path local, String key) {
        try {
            AudioFile af = AudioFileIO.read(local.toFile());
            Tag tag = af.getTag();
            if (tag == null) return null;
            Artwork art = tag.getFirstArtwork();
            if (art == null || art.getBinaryData() == null || art.getBinaryData().length == 0) return null;

            String ext = inferExtension(art.getMimeType());
            Path target = coversDir.resolve(hash(key) + "." + ext);
            Files.write(target, art.getBinaryData());
            return target;
        } catch (Exception e) {
            return null;
        }
    }

    private Path copyToCoversDir(Path source, String key) {
        try {
            String ext = extensionOf(source.getFileName().toString());
            Path target = coversDir.resolve(hash(key) + "." + ext);
            Files.copy(source, target, StandardCopyOption.REPLACE_EXISTING);
            if (Files.exists(target) && fileSize(target) > 0) return target;
        } catch (IOException ignored) {}
        return null;
    }

    private Path findCoverInRemoteFolder(LifeOSFileReference trackRef, String key) {
        if (core == null || trackRef == null) return null;
        LifeOSFileService fs = core.getFileService();
        if (fs == null) return null;
        LifeOSFileReference parent = parentReference(trackRef);
        if (parent == null) return null;

        List<LifeOSFileReference> children;
        try {
            children = fs.list(parent);
        } catch (Exception e) {
            return null;
        }
        if (children == null || children.isEmpty()) return null;

        // 1) Bevorzugte Namen (cover/folder/album/front/...).
        for (String name : COVER_NAMES) {
            for (String ext : COVER_EXTS) {
                LifeOSFileReference hit = findChildByName(children, name + "." + ext);
                if (hit != null) {
                    Path saved = downloadRemoteCover(fs, hit, key);
                    if (saved != null) return saved;
                }
            }
        }
        // 2) Fallback: erste beliebige Bilddatei im Ordner.
        for (LifeOSFileReference child : children) {
            String n = baseName(child).toLowerCase();
            if (isImageName(n)) {
                Path saved = downloadRemoteCover(fs, child, key);
                if (saved != null) return saved;
            }
        }
        return null;
    }

    private static LifeOSFileReference findChildByName(List<LifeOSFileReference> children, String wantedLower) {
        for (LifeOSFileReference child : children) {
            if (baseName(child).equalsIgnoreCase(wantedLower)) return child;
        }
        return null;
    }

    private Path downloadRemoteCover(LifeOSFileService fs, LifeOSFileReference ref, String key) {
        String ext = extensionOf(baseName(ref));
        Path target = coversDir.resolve(hash(key) + "." + ext);
        try (InputStream in = fs.openReadStream(ref)) {
            Files.copy(in, target, StandardCopyOption.REPLACE_EXISTING);
            if (Files.exists(target) && fileSize(target) > 0) return target;
        } catch (Exception ignored) {
            try { Files.deleteIfExists(target); } catch (IOException ignore2) {}
        }
        return null;
    }

    private static LifeOSFileReference parentReference(LifeOSFileReference ref) {
        if (ref == null) return null;
        String rel = ref.getRelativePath();
        if (rel == null || rel.isBlank()) return null;
        String normalized = rel.replace('\\', '/');
        while (normalized.endsWith("/")) normalized = normalized.substring(0, normalized.length() - 1);
        int slash = normalized.lastIndexOf('/');
        if (slash <= 0) return null;
        String parent = normalized.substring(0, slash);
        return new LifeOSFileReference(ref.getProviderId(), ref.getScope(), ref.getOwnerId(), parent);
    }

    private static String baseName(LifeOSFileReference ref) {
        if (ref == null) return "";
        String rel = ref.getRelativePath();
        if (rel == null) return "";
        String normalized = rel.replace('\\', '/');
        while (normalized.endsWith("/")) normalized = normalized.substring(0, normalized.length() - 1);
        int slash = normalized.lastIndexOf('/');
        return slash < 0 ? normalized : normalized.substring(slash + 1);
    }

    private static boolean isImageName(String name) {
        return name.endsWith(".jpg") || name.endsWith(".jpeg")
            || name.endsWith(".png") || name.endsWith(".webp");
    }

    private static final String[] COVER_NAMES = {
        "cover", "folder", "album", "front", "albumart", "albumartsmall"
    };
    private static final String[] COVER_EXTS = {"jpg", "jpeg", "png", "webp"};

    private static Path findCoverInFolder(Path folder) {
        if (folder == null || !Files.isDirectory(folder)) return null;
        for (String name : COVER_NAMES) {
            for (String ext : COVER_EXTS) {
                Path p = folder.resolve(name + "." + ext);
                if (Files.exists(p) && fileSize(p) > 0) return p;
                Path p2 = folder.resolve(name.toUpperCase() + "." + ext);
                if (Files.exists(p2) && fileSize(p2) > 0) return p2;
            }
        }
        // Fallback: any image file in folder
        try (java.util.stream.Stream<Path> stream = Files.list(folder)) {
            return stream.filter(p -> {
                String n = p.getFileName().toString().toLowerCase();
                return n.endsWith(".jpg") || n.endsWith(".jpeg")
                    || n.endsWith(".png") || n.endsWith(".webp");
            }).findFirst().orElse(null);
        } catch (IOException e) {
            return null;
        }
    }

    private static String extensionOf(String name) {
        int dot = name.lastIndexOf('.');
        if (dot < 0 || dot >= name.length() - 1) return "jpg";
        String ext = name.substring(dot + 1).toLowerCase();
        if ("jpeg".equals(ext)) return "jpg";
        return ext;
    }

    private static String albumKey(String album, String artist) {
        String a = album == null ? "" : album.toLowerCase().trim();
        String b = artist == null ? "" : artist.toLowerCase().trim();
        return a + "" + b;
    }

    private static String inferExtension(String mime) {
        if (mime == null) return "jpg";
        String m = mime.toLowerCase();
        if (m.contains("png")) return "png";
        return "jpg";
    }

    private static String hash(String key) {
        try {
            MessageDigest md = MessageDigest.getInstance("SHA-1");
            return HexFormat.of().formatHex(md.digest(key.getBytes()));
        } catch (Exception e) {
            return Integer.toHexString(key.hashCode());
        }
    }

    private static long fileSize(Path p) {
        try { return Files.size(p); } catch (IOException e) { return 0; }
    }
}
