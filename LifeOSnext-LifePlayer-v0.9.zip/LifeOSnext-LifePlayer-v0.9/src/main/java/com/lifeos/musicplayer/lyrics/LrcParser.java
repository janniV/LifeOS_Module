package com.lifeos.musicplayer.lyrics;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Sehr toleranter Parser für LRC-Lyrics. Unterstützt:
 *  - Standard-Timestamps wie [mm:ss], [mm:ss.xx] und [mm:ss.xxx]
 *  - Mehrere Timestamps pro Zeile: [00:12.34][00:25.78]Text
 *  - ID-Tags ([ti:], [ar:], [al:], [length:], [offset:], [by:], [re:], [ve:], …)
 *    werden ignoriert. Ein [offset:±ms] verschiebt alle Zeilen.
 */
public final class LrcParser {

    public record TimedLine(long timeMs, String text) {}

    private static final Pattern TS = Pattern.compile("\\[(\\d+):(\\d+)(?:[.:](\\d+))?\\]");
    private static final Pattern META = Pattern.compile(
        "\\[\\s*(ti|ar|al|au|by|length|offset|re|ve|tool|lang|hash|encoding)\\s*:([^\\]]*)\\]",
        Pattern.CASE_INSENSITIVE);

    private LrcParser() {}

    /** Heuristik: enthält der Text mindestens eine Zeile, die mit einem
     *  echten Zeit-Tag beginnt? */
    public static boolean looksLikeLrc(String text) {
        if (text == null || text.isBlank()) return false;
        for (String raw : text.split("\\r?\\n")) {
            String line = raw.trim();
            if (line.isEmpty()) continue;
            Matcher m = TS.matcher(line);
            if (m.lookingAt()) return true;
        }
        return false;
    }

    public static List<TimedLine> parse(String text) {
        if (text == null) return List.of();

        long offsetMs = 0;
        List<TimedLine> result = new ArrayList<>();

        for (String raw : text.split("\\r?\\n")) {
            String line = raw.trim();
            if (line.isEmpty()) continue;

            Matcher meta = META.matcher(line);
            if (meta.matches()) {
                if (meta.group(1).equalsIgnoreCase("offset")) {
                    try { offsetMs = Long.parseLong(meta.group(2).trim()); }
                    catch (NumberFormatException ignored) {}
                }
                continue;
            }

            List<Long> timestamps = new ArrayList<>();
            Matcher m = TS.matcher(line);
            int end = 0;
            while (m.find(end) && m.start() == end) {
                int min = Integer.parseInt(m.group(1));
                int sec = Integer.parseInt(m.group(2));
                long ms = (min * 60L + sec) * 1000L;
                if (m.group(3) != null) ms += scaleFraction(m.group(3));
                timestamps.add(ms);
                end = m.end();
            }
            if (timestamps.isEmpty()) continue;

            String content = line.substring(end).trim();
            for (long ts : timestamps) {
                result.add(new TimedLine(Math.max(0, ts + offsetMs), content));
            }
        }
        Collections.sort(result, (a, b) -> Long.compare(a.timeMs(), b.timeMs()));
        return result;
    }

    private static long scaleFraction(String frac) {
        try {
            int v = Integer.parseInt(frac);
            return switch (frac.length()) {
                case 1 -> v * 100L;   // .x  → Zehntel
                case 2 -> v * 10L;    // .xx → Hundertstel
                case 3 -> v;          // .xxx → ms direkt
                default -> v;
            };
        } catch (NumberFormatException e) {
            return 0;
        }
    }
}
