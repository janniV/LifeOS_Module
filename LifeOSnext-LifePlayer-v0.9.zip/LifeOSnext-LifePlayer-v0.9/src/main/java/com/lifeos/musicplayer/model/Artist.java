package com.lifeos.musicplayer.model;

import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Objects;

public final class Artist {
    private final String name;
    private final Map<String, Album> albums = new LinkedHashMap<>();

    public Artist(String name) {
        this.name = name == null ? "" : name;
    }

    public String getName() { return name; }
    public Map<String, Album> getAlbums() { return albums; }

    public int getTrackCount() {
        int n = 0;
        for (Album a : albums.values()) n += a.getTracks().size();
        return n;
    }

    @Override public boolean equals(Object o) {
        return o instanceof Artist a && Objects.equals(name.toLowerCase(), a.name.toLowerCase());
    }
    @Override public int hashCode() { return Objects.hash(name.toLowerCase()); }
}
