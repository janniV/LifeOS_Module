package com.lifeos.musicplayer.library;

import core.LifeOSFileReference;
import core.LifeOSFileService;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;

public final class NasCache {

    private final Path root;
    private final LifeOSFileService files;
    private long maxBytes = 8L * 1024 * 1024 * 1024;

    public NasCache(Path root, LifeOSFileService files) {
        this.root = root;
        this.files = files;
        try { Files.createDirectories(root); } catch (IOException ignored) {}
    }

    public void setMaxBytes(long bytes) { this.maxBytes = bytes; }

    public Path resolve(LifeOSFileReference ref) {
        String key = ref.getProviderId() + "/" + ref.getOwnerId() + "/" + ref.getRelativePath();
        key = key.replace("\\", "/").replaceAll("/+", "/");
        return root.resolve(key);
    }

    public Path ensureCached(LifeOSFileReference ref) throws IOException {
        Path cached = resolve(ref);
        if (Files.exists(cached) && Files.size(cached) > 0) {
            try { Files.setLastModifiedTime(cached, java.nio.file.attribute.FileTime.fromMillis(System.currentTimeMillis())); }
            catch (IOException ignored) {}
            return cached;
        }
        Files.createDirectories(cached.getParent());
        Path tmp = Files.createTempFile(cached.getParent(), "dl-", ".part");
        try (InputStream in = files.openReadStream(ref);
             OutputStream out = Files.newOutputStream(tmp)) {
            in.transferTo(out);
        } catch (Exception e) {
            try { Files.deleteIfExists(tmp); } catch (IOException ignored) {}
            throw new IOException("NAS-Download fehlgeschlagen: " + ref + " (" + e.getMessage() + ")", e);
        }
        Files.move(tmp, cached, StandardCopyOption.REPLACE_EXISTING, StandardCopyOption.ATOMIC_MOVE);
        evictIfOverLimit();
        return cached;
    }

    private void evictIfOverLimit() {
        try {
            long total = Files.walk(root)
                .filter(Files::isRegularFile)
                .mapToLong(p -> { try { return Files.size(p); } catch (IOException e) { return 0; } })
                .sum();
            if (total <= maxBytes) return;
            Files.walk(root)
                .filter(Files::isRegularFile)
                .sorted((a, b) -> {
                    try { return Files.getLastModifiedTime(a).compareTo(Files.getLastModifiedTime(b)); }
                    catch (IOException e) { return 0; }
                })
                .forEach(p -> {
                    try {
                        if (currentSize() <= maxBytes * 9 / 10) return;
                        Files.deleteIfExists(p);
                    } catch (IOException ignored) {}
                });
        } catch (IOException ignored) {}
    }

    private long currentSize() throws IOException {
        return Files.walk(root)
            .filter(Files::isRegularFile)
            .mapToLong(p -> { try { return Files.size(p); } catch (IOException e) { return 0; } })
            .sum();
    }
}
