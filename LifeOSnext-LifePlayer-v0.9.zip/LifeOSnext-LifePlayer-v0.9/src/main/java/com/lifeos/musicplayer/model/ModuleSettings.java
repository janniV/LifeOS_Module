package com.lifeos.musicplayer.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
public final class ModuleSettings {

    public enum SidebarPosition { LEFT, RIGHT }

    private SidebarPosition sidebarPosition = SidebarPosition.LEFT;

    public SidebarPosition getSidebarPosition() {
        return sidebarPosition == null ? SidebarPosition.LEFT : sidebarPosition;
    }

    public void setSidebarPosition(SidebarPosition p) {
        this.sidebarPosition = p == null ? SidebarPosition.LEFT : p;
    }
}
