package com.lifeos.musicplayer.ui;

import com.lifeos.musicplayer.library.CoverArtService;
import com.lifeos.musicplayer.model.Album;
import com.lifeos.musicplayer.playback.PlaybackController;
import javafx.geometry.Pos;
import javafx.scene.control.Label;
import javafx.scene.layout.VBox;

public final class AlbumGridCell extends VBox {

    public AlbumGridCell(Album album, PlaybackController controller, CoverArtService covers) {
        getStyleClass().add("music-album-grid-cell");
        setSpacing(8);
        setAlignment(Pos.TOP_LEFT);
        setPrefWidth(180);
        setMaxWidth(180);

        CoverView cover = new CoverView(covers, 180, 12);
        cover.showAlbum(album);

        Label title = new Label(album.getName().isBlank() ? "(Unbekanntes Album)" : album.getName());
        title.getStyleClass().add("music-album-grid-title");
        title.setWrapText(true);
        title.setMaxWidth(180);

        Label artist = new Label(album.getArtist()
            + (album.getYear() > 0 ? "  ·  " + album.getYear() : ""));
        artist.getStyleClass().add("music-album-grid-subtitle");
        artist.setWrapText(false);
        artist.setMaxWidth(180);

        cover.setStyle("-fx-cursor: hand;");
        cover.setOnMouseClicked(e -> {
            if (e.getClickCount() == 2) controller.playAll(album.getTracks(), 0);
        });

        getChildren().addAll(cover, title, artist);
    }
}
