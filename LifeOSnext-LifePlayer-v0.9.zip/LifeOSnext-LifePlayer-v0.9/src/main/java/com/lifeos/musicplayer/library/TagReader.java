package com.lifeos.musicplayer.library;

import com.lifeos.musicplayer.model.Track;
import org.jaudiotagger.audio.AudioFile;
import org.jaudiotagger.audio.AudioFileIO;
import org.jaudiotagger.audio.AudioHeader;
import org.jaudiotagger.tag.FieldKey;
import org.jaudiotagger.tag.Tag;

import java.io.File;
import java.util.Set;

public final class TagReader {

    public static final Set<String> SUPPORTED_EXTENSIONS = Set.of(
        "mp3", "m4a", "aac", "wav", "aif", "aiff", "flac"
    );

    private TagReader() {}

    public static boolean isSupportedFilename(String name) {
        if (name == null) return false;
        int dot = name.lastIndexOf('.');
        if (dot < 0) return false;
        return SUPPORTED_EXTENSIONS.contains(name.substring(dot + 1).toLowerCase());
    }

    public static void fillFromFile(Track track, File file) {
        try {
            AudioFile af = AudioFileIO.read(file);
            Tag tag = af.getTag();
            AudioHeader h = af.getAudioHeader();

            if (tag != null) {
                track.setTitle(firstNonBlank(tag.getFirst(FieldKey.TITLE), stripExtension(file.getName())));
                track.setArtist(tag.getFirst(FieldKey.ARTIST));
                track.setAlbumArtist(tag.getFirst(FieldKey.ALBUM_ARTIST));
                track.setAlbum(tag.getFirst(FieldKey.ALBUM));
                track.setGenre(tag.getFirst(FieldKey.GENRE));
                track.setYear(parseInt(tag.getFirst(FieldKey.YEAR)));
                track.setTrackNumber(parseInt(tag.getFirst(FieldKey.TRACK)));
                track.setDiscNumber(parseInt(tag.getFirst(FieldKey.DISC_NO)));
            } else {
                track.setTitle(stripExtension(file.getName()));
            }
            if (h != null) {
                track.setDurationMs((long) (h.getTrackLength() * 1000L));
                track.setFormat(h.getFormat() == null ? extension(file.getName()) : h.getFormat());
            } else {
                track.setFormat(extension(file.getName()));
            }
            track.setSizeBytes(file.length());
        } catch (Exception e) {
            track.setTitle(stripExtension(file.getName()));
            track.setFormat(extension(file.getName()));
            track.setSizeBytes(file.length());
        }
    }

    private static String firstNonBlank(String a, String b) {
        return (a == null || a.isBlank()) ? b : a;
    }

    private static int parseInt(String s) {
        if (s == null || s.isBlank()) return 0;
        try { return Integer.parseInt(s.replaceAll("[^0-9].*", "")); }
        catch (NumberFormatException e) { return 0; }
    }

    private static String stripExtension(String n) {
        int dot = n.lastIndexOf('.');
        return dot < 0 ? n : n.substring(0, dot);
    }

    private static String extension(String n) {
        int dot = n.lastIndexOf('.');
        return dot < 0 ? "" : n.substring(dot + 1).toLowerCase();
    }
}
