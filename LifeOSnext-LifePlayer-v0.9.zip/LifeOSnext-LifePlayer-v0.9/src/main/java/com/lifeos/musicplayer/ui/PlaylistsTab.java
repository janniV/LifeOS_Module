package com.lifeos.musicplayer.ui;

import com.lifeos.musicplayer.library.LibraryStore;
import com.lifeos.musicplayer.library.MusicLibrary;
import com.lifeos.musicplayer.model.Playlist;
import com.lifeos.musicplayer.model.Track;
import com.lifeos.musicplayer.playback.PlaybackController;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.geometry.Insets;
import javafx.scene.control.*;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

public final class PlaylistsTab extends BorderPane {

    private final ObservableList<Playlist> playlists = FXCollections.observableArrayList();
    private final MusicLibrary library;
    private final LibraryStore store;
    private final PlaybackController controller;

    public PlaylistsTab(MusicLibrary library, LibraryStore store,
                        List<Playlist> initial, PlaybackController controller) {
        this.library = library;
        this.store = store;
        this.controller = controller;
        playlists.setAll(initial);

        ListView<Playlist> left = new ListView<>(playlists);
        left.setCellFactory(lv -> new ListCell<>() {
            @Override protected void updateItem(Playlist p, boolean empty) {
                super.updateItem(p, empty);
                setText(empty || p == null ? null : p.getName() + " (" + p.getTrackIds().size() + ")");
            }
        });

        BorderPane right = new BorderPane();
        right.setPadding(new Insets(8));
        Label hint = new Label("Wähle eine Playlist.");
        right.setCenter(hint);

        left.getSelectionModel().selectedItemProperty().addListener((obs, o, n) -> {
            if (n == null) { right.setCenter(hint); return; }
            ListView<Track> tracks = new ListView<>();
            tracks.setCellFactory(lv -> new ListCell<>() {
                @Override protected void updateItem(Track t, boolean empty) {
                    super.updateItem(t, empty);
                    setText(empty || t == null ? null : t.getTitle() + " — " + t.getDisplayArtist());
                }
            });
            tracks.getItems().setAll(resolve(n));
            tracks.setOnMouseClicked(e -> {
                if (e.getClickCount() == 2 && tracks.getSelectionModel().getSelectedIndex() >= 0) {
                    controller.playAll(new ArrayList<>(tracks.getItems()),
                                       tracks.getSelectionModel().getSelectedIndex());
                }
            });
            Button playAll = new Button("Abspielen");
            playAll.setOnAction(e -> controller.playAll(new ArrayList<>(tracks.getItems()), 0));
            HBox tb = new HBox(8, playAll);
            tb.setPadding(new Insets(0, 0, 8, 0));
            right.setTop(tb);
            right.setCenter(tracks);
        });

        Button create = new Button("Neu …");
        create.setOnAction(e -> {
            Optional<String> name = new TextInputDialog().showAndWait();
            name.filter(n -> !n.isBlank()).ifPresent(n -> {
                Playlist p = new Playlist(n);
                playlists.add(p);
                store.savePlaylists(new ArrayList<>(playlists));
            });
        });
        Button del = new Button("Löschen");
        del.setOnAction(e -> {
            Playlist sel = left.getSelectionModel().getSelectedItem();
            if (sel != null) { playlists.remove(sel); store.savePlaylists(new ArrayList<>(playlists)); }
        });

        HBox toolbar = new HBox(8, create, del);
        toolbar.setPadding(new Insets(8));
        setTop(toolbar);

        SplitPane sp = new SplitPane(left, right);
        sp.setDividerPositions(0.3);
        setCenter(sp);
    }

    private List<Track> resolve(Playlist p) {
        List<Track> out = new ArrayList<>();
        for (String id : p.getTrackIds()) {
            Track t = library.findById(id);
            if (t != null) out.add(t);
        }
        return out;
    }

    public List<Playlist> getPlaylists() { return new ArrayList<>(playlists); }

    public void addPlaylist(Playlist p) {
        playlists.add(p);
        store.savePlaylists(new ArrayList<>(playlists));
    }
}
