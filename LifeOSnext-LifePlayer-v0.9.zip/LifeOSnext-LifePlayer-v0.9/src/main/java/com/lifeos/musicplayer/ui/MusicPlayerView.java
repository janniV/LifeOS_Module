package com.lifeos.musicplayer.ui;

import atlantafx.base.theme.Styles;
import com.lifeos.musicplayer.library.CoverArtService;
import com.lifeos.musicplayer.library.LibraryStore;
import com.lifeos.musicplayer.library.MusicLibrary;
import com.lifeos.musicplayer.library.NasCache;
import com.lifeos.musicplayer.lyrics.LyricsService;
import com.lifeos.musicplayer.model.ModuleSettings;
import com.lifeos.musicplayer.model.MusicSource;
import com.lifeos.musicplayer.model.Playlist;
import com.lifeos.musicplayer.playback.PlaybackController;
import core.CoreServices;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.ToggleButton;
import javafx.scene.control.ToggleGroup;
import javafx.scene.control.ScrollPane;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.scene.input.MouseButton;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.StackPane;
import javafx.stage.Modality;
import javafx.stage.Stage;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

public final class MusicPlayerView extends BorderPane {

    private final SourcesSettingsView sourcesView;
    private final PlaylistsTab playlistsTab;
    private final LyricsTab lyricsTab;
    private final CoreServices core;

    private final BorderPane body = new BorderPane();
    private final StackPane tabContent = new StackPane();
    private final MusicSidebar sidebar = new MusicSidebar();
    private final Map<String, Node> tabNodes = new LinkedHashMap<>();
    private final Map<String, ToggleButton> tabButtons = new LinkedHashMap<>();
    private ModuleSettings settings;
    private String previousTabName;
    private String currentTabName;

    public MusicPlayerView(MusicLibrary library,
                           LibraryStore store,
                           NasCache cache,
                           CoverArtService covers,
                           PlaybackController controller,
                           LyricsService lyrics,
                           CoreServices core,
                           String moduleId,
                           List<MusicSource> sources,
                           List<Playlist> playlists,
                           ModuleSettings settings) {
        this.core = core;
        this.settings = settings == null ? new ModuleSettings() : settings;
        getStyleClass().add("music-root");
        applyStylesheet();

        TracksTab tracksTab = new TracksTab(library, controller);
        ArtistsTab artistsTab = new ArtistsTab(library, controller, covers);
        AlbumsTab albumsTab = new AlbumsTab(library, controller, covers, store);
        QueueTab queueTab = new QueueTab(controller);
        sourcesView = new SourcesSettingsView(library, store, cache, core, moduleId, sources, this.settings, this::onSettingsChanged);
        playlistsTab = new PlaylistsTab(library, store, playlists, controller);
        lyricsTab = new LyricsTab(controller, lyrics, covers);
        lyricsTab.setOnBack(this::navigateBack);

        tracksTab.setOnAlbumClick(name -> {
            selectTab("Alben");
            albumsTab.showAlbumDetail(name);
        });
        tracksTab.setOnArtistClick(name -> {
            selectTab("Künstler:innen");
            artistsTab.showArtistDetail(name);
        });

        tabNodes.put("Titel", tracksTab);
        tabNodes.put("Künstler:innen", artistsTab);
        tabNodes.put("Alben", albumsTab);
        tabNodes.put("Playlists", playlistsTab);
        tabNodes.put("Warteschlange", queueTab);
        tabNodes.put("Songtext", lyricsTab);

        sidebar.setOnSelect(this::onSidebarSelect);

        tabContent.getStyleClass().add("music-tab-content");
        body.setCenter(tabContent);
        applySidebarLayout();

        PlayerBar playerBar = new PlayerBar(controller, covers);
        playerBar.setOnInfoClick(() -> selectTab("Songtext"));
        setTop(buildHeader());
        setCenter(body);
        setBottom(playerBar);

        this.addEventFilter(MouseEvent.MOUSE_PRESSED, e -> {
            if (e.getButton() == MouseButton.BACK) {
                navigateBack();
            } else if (e.getButton() == MouseButton.FORWARD) {
                selectTab("Songtext");
            }
        });

        selectTab("Alben");
    }

    private void onSidebarSelect(MusicSidebar.Entry e) {
        switch (e) {
            case TRACKS, RECENT, GENRES -> selectTab("Titel");
            case ARTISTS                -> selectTab("Künstler:innen");
            case ALBUMS                 -> selectTab("Alben");
            case NEW_PLAYLIST, FAVORITES -> selectTab("Playlists");
            default -> {}
        }
    }

    private void onSettingsChanged(ModuleSettings updated) {
        this.settings = updated == null ? new ModuleSettings() : updated;
        applySidebarLayout();
    }

    private void applySidebarLayout() {
        body.setLeft(null);
        body.setRight(null);
        if (settings.getSidebarPosition() == ModuleSettings.SidebarPosition.RIGHT) {
            sidebar.getStyleClass().remove("sidebar-left");
            if (!sidebar.getStyleClass().contains("sidebar-right")) sidebar.getStyleClass().add("sidebar-right");
            body.setRight(sidebar);
        } else {
            sidebar.getStyleClass().remove("sidebar-right");
            if (!sidebar.getStyleClass().contains("sidebar-left")) sidebar.getStyleClass().add("sidebar-left");
            body.setLeft(sidebar);
        }
    }

    private void navigateBack() {
        if (previousTabName != null) {
            selectTab(previousTabName);
        }
    }

    private void selectTab(String name) {
        Node n = tabNodes.get(name);
        if (n == null) return;

        if (currentTabName != null && !currentTabName.equals(name)) {
            previousTabName = currentTabName;
        }
        currentTabName = name;

        tabContent.getChildren().setAll(n);
        for (Map.Entry<String, ToggleButton> e : tabButtons.entrySet()) {
            e.getValue().setSelected(e.getKey().equals(name));
        }
        // Sync sidebar highlight when possible
        MusicSidebar.Entry mapped = switch (name) {
            case "Titel" -> MusicSidebar.Entry.TRACKS;
            case "Künstler:innen" -> MusicSidebar.Entry.ARTISTS;
            case "Alben" -> MusicSidebar.Entry.ALBUMS;
            default -> null;
        };
        if (mapped != null) sidebar.setActive(mapped);
    }

    private void applyStylesheet() {
        try {
            String css = getClass().getResource("/com/lifeos/musicplayer/music-player.css").toExternalForm();
            sceneProperty().addListener((obs, oldScene, scene) -> {
                if (scene != null && !scene.getStylesheets().contains(css)) {
                    scene.getStylesheets().add(css);
                }
            });
        } catch (Exception ignored) {}
    }

    private BorderPane buildHeader() {
        Node icon = Icons.musicNote(22);
        icon.getStyleClass().add("music-header-icon");

        Label title = new Label("LifeMusic v0.9.0");
        title.getStyleClass().addAll("music-header-title", Styles.TITLE_3);

        HBox titleBlock = new HBox(10, icon, title);
        titleBlock.setAlignment(Pos.CENTER_LEFT);
        titleBlock.setMinWidth(160);

        HBox tabRow = buildTabRow();

        // Tab row in a horizontally scrollable holder so it never disappears
        // when LifeOS gives the module a narrow content area.
        ScrollPane tabScroll = new ScrollPane(tabRow);
        tabScroll.setFitToHeight(true);
        tabScroll.setHbarPolicy(ScrollPane.ScrollBarPolicy.NEVER);
        tabScroll.setVbarPolicy(ScrollPane.ScrollBarPolicy.NEVER);
        tabScroll.getStyleClass().add("music-tab-scroll");
        tabScroll.setPannable(true);

        StackPane tabCenter = new StackPane(tabScroll);
        StackPane.setAlignment(tabScroll, Pos.CENTER);
        tabCenter.setMinWidth(0);

        Button settingsBtn = new Button("Einstellungen");
        settingsBtn.setGraphic(Icons.settingsGear(14));
        settingsBtn.getStyleClass().add("music-header-button");
        settingsBtn.setOnAction(e -> openSettings());

        BorderPane header = new BorderPane();
        header.setLeft(titleBlock);
        header.setCenter(tabCenter);
        header.setRight(settingsBtn);
        BorderPane.setAlignment(titleBlock, Pos.CENTER_LEFT);
        BorderPane.setAlignment(settingsBtn, Pos.CENTER_RIGHT);
        BorderPane.setMargin(titleBlock, new Insets(0, 12, 0, 0));
        BorderPane.setMargin(settingsBtn, new Insets(0, 0, 0, 12));
        header.getStyleClass().add("music-header");
        return header;
    }

    private HBox buildTabRow() {
        ToggleGroup group = new ToggleGroup();
        HBox row = new HBox(8);
        row.setAlignment(Pos.CENTER);
        row.getStyleClass().add("music-tab-row");
        String[] names = { "Titel", "Künstler:innen", "Alben", "Playlists", "Warteschlange", "Songtext" };
        Node[] icons = {
            Icons.track(14), Icons.artist(14), Icons.album(14),
            Icons.playlist(14), Icons.queueIcon(14), Icons.lyrics(14)
        };
        for (int i = 0; i < names.length; i++) {
            String n = names[i];
            ToggleButton tb = new ToggleButton(n);
            tb.setGraphic(icons[i]);
            tb.setToggleGroup(group);
            tb.getStyleClass().add("music-tab-button");
            tb.setOnAction(e -> {
                if (!tb.isSelected()) { tb.setSelected(true); return; }
                selectTab(n);
            });
            tabButtons.put(n, tb);
            row.getChildren().add(tb);
        }
        return row;
    }

    private void openSettings() {
        if (core != null) {
            try {
                core.showDialog("Musik-Einstellungen", sourcesView);
                return;
            } catch (Exception ignored) {}
        }
        Stage s = new Stage();
        s.setTitle("Musik-Einstellungen");
        Scene scene = new Scene(new BorderPane(sourcesView));
        try {
            String css = getClass().getResource("/com/lifeos/musicplayer/music-player.css").toExternalForm();
            scene.getStylesheets().add(css);
        } catch (Exception ignored) {}
        s.setScene(scene);
        s.initModality(Modality.NONE);
        s.show();
    }

    public SourcesSettingsView getSourcesView() { return sourcesView; }
    public PlaylistsTab getPlaylistsTab() { return playlistsTab; }
}
