package com.lifeos.musicplayer.library;

import com.lifeos.musicplayer.model.MusicSource;
import com.lifeos.musicplayer.model.RefKind;
import com.lifeos.musicplayer.model.SourceKind;
import com.lifeos.musicplayer.model.Track;
import core.CoreServices;
import core.LifeOSFileMetadata;
import core.LifeOSFileReference;
import core.LifeOSFileService;

import java.io.File;
import java.lang.reflect.Method;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.concurrent.atomic.AtomicBoolean;

public final class LibraryScanner {

    public interface ProgressCallback {
        void onProgress(String currentItem, int done, int total);
        default void onError(String message) {}
    }

    private final LifeOSFileService files;
    private final NasCache cache;
    private final String moduleId;
    private final CoreServices core;
    private final AtomicBoolean cancel = new AtomicBoolean(false);

    public LibraryScanner(LifeOSFileService files, NasCache cache, String moduleId) {
        this(files, cache, moduleId, null);
    }

    public LibraryScanner(LifeOSFileService files, NasCache cache, String moduleId, CoreServices core) {
        this.files = files;
        this.cache = cache;
        this.moduleId = moduleId;
        this.core = core;
    }

    public void cancel() { cancel.set(true); }

    public List<Track> scan(MusicSource source, ProgressCallback cb) {
        cancel.set(false);
        List<Track> result = new ArrayList<>();
        SourceKind kind = source.getKindResolved();
        try {
            switch (kind) {
                case LOCAL -> scanLocal(source, result, cb);
                case NAS, LIFEOS_WORKSPACE, LIFEOS_MODULE -> scanManaged(source, result, cb);
            }
        } catch (Exception e) {
            cb.onError("Scan abgebrochen: " + e.getMessage());
            e.printStackTrace();
        }
        source.setLastScannedEpochMs(System.currentTimeMillis());
        source.setTrackCount(result.size());
        return result;
    }

    private void scanLocal(MusicSource source, List<Track> result, ProgressCallback cb) {
        File rootFile = source.getLocalFile();
        if (rootFile == null || !rootFile.isDirectory()) {
            cb.onError("Ordner existiert nicht: " + (rootFile == null ? "-" : rootFile));
            return;
        }
        List<Path> audioFiles = new ArrayList<>();
        collectLocal(rootFile, audioFiles, cb);
        int total = audioFiles.size();
        int done = 0;
        for (Path p : audioFiles) {
            if (cancel.get()) break;
            done++;
            cb.onProgress(p.getFileName().toString(), done, total);
            try {
                File file = p.toFile();
                if (!file.exists()) continue;
                Track t = new Track();
                t.setLocalFile(file);
                TagReader.fillFromFile(t, file);
                result.add(t);
            } catch (Exception e) {
                cb.onError("Lesefehler: " + p + " (" + e.getMessage() + ")");
            }
        }
    }

    private void collectLocal(File dir, List<Path> out, ProgressCallback cb) {
        if (cancel.get()) return;
        File[] entries = dir.listFiles();
        if (entries == null) return;
        for (File f : entries) {
            if (cancel.get()) return;
            if (f.isDirectory()) {
                collectLocal(f, out, cb);
            } else if (TagReader.isSupportedFilename(f.getName())) {
                out.add(f.toPath());
                cb.onProgress("Indexiere: " + f.getName(), out.size(), -1);
            }
        }
    }

    private void scanManaged(MusicSource source, List<Track> result, ProgressCallback cb) {
        if (files == null) { cb.onError("LifeOS-Dateidienst nicht verfügbar."); return; }
        LifeOSFileReference root = source.resolve(core, moduleId);
        if (root == null) {
            cb.onError("Quelle konnte nicht aufgelöst werden: " + source.getLabel()
                + " — bitte in den LifeOS-Einstellungen prüfen.");
            return;
        }
        System.err.println("[MusicPlayer] scanManaged root=" + root + " kind=" + source.getKind());
        if (source.getKind() == RefKind.NAS && core != null) {
            try {
                boolean allowed = core.isRemoteFileReferenceAllowed(moduleId, root, false);
                System.err.println("[MusicPlayer] isRemoteFileReferenceAllowed(read) = " + allowed);
                if (!allowed) {
                    cb.onError("Zugriff auf NAS-Ordner verweigert. "
                        + "Bitte in den LifeOS-Einstellungen für 'Musik' freigeben.");
                    return;
                }
            } catch (Throwable t) {
                System.err.println("[MusicPlayer] isRemoteFileReferenceAllowed warf: " + t);
            }
        }

        LifeOSFileReference startFolder = root;
        String subPath = source.getSubPath();
        if (subPath != null && !subPath.isBlank()) {
            startFolder = descendInto(root, subPath, cb);
            if (startFolder == null) return;
        }

        boolean async = isRemoteKind(source.getKind());
        String sourceKey = source.getRefKey();
        RefKind tk = source.getKind();
        List<LifeOSFileReference> audioFiles = new ArrayList<>();
        collectManaged(startFolder, audioFiles, async, cb);
        System.err.println("[MusicPlayer] scanManaged sammelte " + audioFiles.size() + " Audiodateien");
        int total = audioFiles.size();
        int done = 0;
        for (LifeOSFileReference ref : audioFiles) {
            if (cancel.get()) break;
            done++;
            try {
                cb.onProgress(safeRel(ref), done, total);
                String fileName = safeRel(ref);
                String ext = fileName.contains(".") ? fileName.substring(fileName.lastIndexOf('.')) : ".tmp";
                File tempHead = File.createTempFile("scan-", ext);

                try (java.io.InputStream in = files.openReadStream(ref);
                     java.io.OutputStream out = java.nio.file.Files.newOutputStream(tempHead.toPath())) {
                    byte[] buffer = new byte[8192];
                    int read;
                    long totalRead = 0;
                    // Lese maximal 2 Megabyte, das reicht für ID3/FLAC-Tags
                    while ((read = in.read(buffer)) != -1 && totalRead < 2_000_000) {
                        out.write(buffer, 0, read);
                        totalRead += read;
                    }
                }

                Track t = new Track();
                t.setManagedReference(ref, tk, sourceKey);
                TagReader.fillFromFile(t, tempHead);

                // Korrigiere den Titel, falls der Tagger auf den temp-Namen zurückgefallen ist
                if (t.getTitle() == null || t.getTitle().startsWith("scan-")) {
                    String baseName = fileName;
                    int slash = Math.max(baseName.lastIndexOf('/'), baseName.lastIndexOf('\\'));
                    if (slash >= 0) baseName = baseName.substring(slash + 1);
                    int dot = baseName.lastIndexOf('.');
                    if (dot > 0) baseName = baseName.substring(0, dot);
                    t.setTitle(baseName);
                }

                result.add(t);
                tempHead.delete();
            } catch (Exception e) {
                cb.onError("Lesefehler: " + safeRel(ref) + " (" + e.getMessage() + ")");
            }
        }
    }

    private LifeOSFileReference descendInto(LifeOSFileReference root, String subPath, ProgressCallback cb) {
        String[] parts = subPath.split("/+");
        LifeOSFileReference cur = root;
        for (String part : parts) {
            if (part.isBlank()) continue;
            LifeOSFileReference next = findChild(cur, part);
            if (next == null) {
                cb.onError("Unterordner nicht gefunden: " + subPath + " (bei '" + part + "')");
                return null;
            }
            cur = next;
        }
        return cur;
    }

    private LifeOSFileReference findChild(LifeOSFileReference folder, String name) {
        try {
            Object rawList = files.list(folder);
            if (!(rawList instanceof Iterable<?> it)) return null;
            for (Object c : it) {
                if (c == null) continue;
                Probe p = probe(c);
                if (p != null && name.equalsIgnoreCase(p.name)) return p.ref;
            }
        } catch (Exception ignored) {}
        return null;
    }

    private boolean isRemoteKind(RefKind k) {
        return k == RefKind.NAS;
    }

    private static String safeRel(LifeOSFileReference r) {
        try { return r.getRelativePath(); } catch (Throwable t) { return String.valueOf(r); }
    }

    private void collectManaged(LifeOSFileReference folder, List<LifeOSFileReference> out,
                                boolean async, ProgressCallback cb) {
        if (cancel.get()) return;
        try {
            Object rawList = async ? files.listAsync(folder).get() : files.list(folder);
            if (rawList == null) {
                System.err.println("[MusicPlayer] list(" + folder + ") -> null");
                cb.onError("Ordner nicht lesbar: " + safeRel(folder));
                return;
            }
            if (!(rawList instanceof Iterable<?> iterable)) {
                System.err.println("[MusicPlayer] list(" + folder + ") gab kein Iterable zurück, sondern: "
                    + rawList.getClass().getName());
                cb.onError("Unerwarteter Rückgabetyp: " + rawList.getClass().getSimpleName());
                return;
            }
            int count = 0;
            for (Object child : iterable) {
                count++;
                if (cancel.get()) return;
                if (child == null) continue;
                Probe p = probe(child);
                if (p == null) continue;
                if (p.isDirectory) {
                    if (p.ref != null) collectManaged(p.ref, out, async, cb);
                } else if (p.name != null && TagReader.isSupportedFilename(p.name)) {
                    if (p.ref != null) {
                        out.add(p.ref);
                        cb.onProgress("Indexiere: " + p.name, out.size(), -1);
                    } else {
                        System.err.println("[MusicPlayer] keine Referenz für " + p.name
                            + " (item-typ: " + child.getClass().getName() + ")");
                    }
                }
            }
            if (count == 0) {
                System.err.println("[MusicPlayer] list(" + folder + ") -> 0 Einträge");
            }
        } catch (Exception e) {
            cb.onError("Listfehler in " + safeRel(folder) + ": " + e.getMessage());
            e.printStackTrace();
        }
    }

    /** Bestimmt aus einem unbekannten list()-Element Name, isDirectory und Referenz. */
    private Probe probe(Object child) {
        Probe p = new Probe();
        if (child instanceof LifeOSFileReference r) {
            p.ref = r;
            p.name = invokeString(r, "getRelativePath");
            if (p.name != null) {
                int slash = Math.max(p.name.lastIndexOf('/'), p.name.lastIndexOf('\\'));
                if (slash >= 0) p.name = p.name.substring(slash + 1);
            }
            // Für Verzeichnis-Erkennung describe() nutzen
            try {
                LifeOSFileMetadata m = files.describe(r);
                if (m != null) {
                    Boolean directory = inferDirectoryFromMetadata(m);
                    p.isDirectory = Boolean.TRUE.equals(directory);
                    if (m.getName() != null) p.name = m.getName();
                }
            } catch (Throwable t) {
                System.err.println("[MusicPlayer] describe(ref) warf: " + t);
            }
            return p;
        }
        // child ist vermutlich LifeOSFileMetadata o. ä.
        p.name = invokeString(child, "getName");
        Boolean dir = invokeBool(child, "isDirectory");
        if (dir == null) dir = invokeBool(child, "isFolder");
        if (dir == null) dir = inferDirectoryFromKind(child);
        if (dir == null) dir = inferDirectoryFromContentType(child);
        p.isDirectory = Boolean.TRUE.equals(dir);
        p.ref = extractRef(child);
        if (p.ref == null && firstUnknown.add(child.getClass().getName())) {
            System.err.println("[MusicPlayer] Unbekannter list()-Item-Typ: " + child.getClass().getName());
            for (Method m : child.getClass().getMethods()) {
                if (m.getParameterCount() == 0 && !m.getDeclaringClass().equals(Object.class)) {
                    System.err.println("    " + m.getReturnType().getSimpleName() + " " + m.getName() + "()");
                }
            }
        }
        return p;
    }

    private final Set<String> firstUnknown = new HashSet<>();

    private static LifeOSFileReference extractRef(Object item) {
        for (String mname : new String[]{
                "getReference", "getRef", "toReference", "asReference",
                "getFileReference", "getEntry", "getEntryReference"}) {
            try {
                Method m = item.getClass().getMethod(mname);
                Object r = m.invoke(item);
                if (r instanceof LifeOSFileReference ref) return ref;
            } catch (Throwable ignored) {}
        }
        // Manche APIs verschachteln die Referenz in einem Getter, der sie als
        // Property hält — versuche reflexiv alle 0-arg-Getter
        for (Method m : item.getClass().getMethods()) {
            if (m.getParameterCount() != 0) continue;
            if (!LifeOSFileReference.class.isAssignableFrom(m.getReturnType())) continue;
            try {
                Object r = m.invoke(item);
                if (r instanceof LifeOSFileReference ref) return ref;
            } catch (Throwable ignored) {}
        }
        return null;
    }

    private static String invokeString(Object target, String method) {
        try {
            Method m = target.getClass().getMethod(method);
            Object r = m.invoke(target);
            return r == null ? null : r.toString();
        } catch (Throwable t) { return null; }
    }

    private static Boolean invokeBool(Object target, String method) {
        try {
            Method m = target.getClass().getMethod(method);
            Object r = m.invoke(target);
            return r instanceof Boolean b ? b : null;
        } catch (Throwable t) { return null; }
    }

    private static Boolean inferDirectoryFromKind(Object target) {
        String kind = invokeString(target, "getKind");
        if (kind == null || kind.isBlank()) return null;
        String normalized = kind.trim().toUpperCase(java.util.Locale.ROOT);
        if ("DIRECTORY".equals(normalized) || "WORKSPACE".equals(normalized)) return true;
        if ("FILE".equals(normalized)) return false;
        return null;
    }

    private static Boolean inferDirectoryFromContentType(Object target) {
        String contentType = invokeString(target, "getContentType");
        if (contentType == null || contentType.isBlank()) {
            contentType = invokeString(target, "getMimeType");
        }
        if (contentType == null || contentType.isBlank()) return null;
        return "inode/directory".equalsIgnoreCase(contentType.trim());
    }

    private static Boolean inferDirectoryFromMetadata(Object target) {
        Boolean dir = invokeBool(target, "isDirectory");
        if (dir == null) dir = invokeBool(target, "isFolder");
        if (dir == null) dir = inferDirectoryFromKind(target);
        if (dir == null) dir = inferDirectoryFromContentType(target);
        return dir;
    }

    private static final class Probe {
        String name;
        boolean isDirectory;
        LifeOSFileReference ref;
    }
}
