package com.lifeos.musicplayer.playback;

import com.lifeos.musicplayer.library.NasCache;
import com.lifeos.musicplayer.model.Track;
import com.lifeos.musicplayer.system.SystemMediaControls;
import core.CoreServices;
import core.LifeOSFileReference;

import java.io.File;
import java.nio.file.Path;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.function.Consumer;

public final class PlaybackController {

    public interface Listener {
        default void onTrackChanged(Track t) {}
        default void onStateChanged(PlaybackState s) {}
        default void onPosition(long posMs, long durMs) {}
        default void onError(String msg) {}
    }

    private final PlaybackQueue queue;
    private final NasCache cache;
    private final CoreServices core;
    private final String moduleId;
    private final CopyOnWriteArrayList<Listener> listeners = new CopyOnWriteArrayList<>();
    private final java.util.concurrent.atomic.AtomicReference<Consumer<Track>> playStartHook = new java.util.concurrent.atomic.AtomicReference<>(t -> {});

    private PlaybackEngine current;
    private SystemMediaControls systemControls = SystemMediaControls.NO_OP;
    private double volume = 0.8;
    private int consecutiveLoadFailures = 0;
    private static final int MAX_CONSECUTIVE_LOAD_FAILURES = 5;

    public PlaybackController(PlaybackQueue queue, NasCache cache) {
        this(queue, cache, null, null);
    }

    public PlaybackController(PlaybackQueue queue, NasCache cache, CoreServices core, String moduleId) {
        this.queue = queue;
        this.cache = cache;
        this.core = core;
        this.moduleId = moduleId;
    }

    public void setSystemMediaControls(SystemMediaControls smc) {
        this.systemControls = smc == null ? SystemMediaControls.NO_OP : smc;
        wireSystemControls();
    }

    private void wireSystemControls() {
        systemControls.setHandler(new SystemMediaControls.Handler() {
            @Override public void onPlay()      { resume(); }
            @Override public void onPause()     { pause(); }
            @Override public void onTogglePlay(){ togglePlay(); }
            @Override public void onNext()      { next(); }
            @Override public void onPrevious()  { previous(); }
            @Override public void onSeek(long positionMs) { seek(positionMs); }
            @Override public void onStop()      { stop(); }
            @Override public void onSetVolume(double v) { setVolume(v); }
        });
    }

    public PlaybackQueue getQueue() { return queue; }

    public void setOnPlayStarted(Consumer<Track> hook) {
        playStartHook.set(hook == null ? t -> {} : hook);
    }

    public void playTrack(Track t) {
        queue.playNow(t);
        playInternal(t);
    }

    public void playAll(java.util.List<Track> tracks, int startIndex) {
        queue.setTracks(tracks, startIndex);
        Track t = queue.getCurrent();
        if (t != null) playInternal(t);
    }

    public void resume() {
        if (current == null) {
            Track t = queue.getCurrent();
            if (t != null) playInternal(t);
            return;
        }
        PlaybackState s = current.getState();
        if (s == PlaybackState.PAUSED) {
            current.play();
        } else if (s == PlaybackState.STOPPED || s == PlaybackState.ERROR) {
            // Engine ist tot, aber ein Track ist in der Queue. Neu laden statt stumm bleiben.
            Track t = queue.getCurrent();
            if (t != null) {
                consecutiveLoadFailures = 0;
                playInternal(t);
            }
        }
        // IDLE/BUFFERING: Load läuft asynchron, einfach warten. PLAYING: schon am Laufen.
    }

    public void pause() { if (current != null) current.pause(); }

    public void stop() {
        if (current != null) {
            current.stop();
            current.dispose();
            current = null;
        }
        systemControls.updateState(PlaybackState.STOPPED, 0, 0);
        fireState(PlaybackState.STOPPED);
    }

    public void togglePlay() {
        if (current == null) { resume(); return; }
        PlaybackState s = current.getState();
        if (s == PlaybackState.PLAYING)      current.pause();
        else if (s == PlaybackState.PAUSED)  current.play();
        else                                 resume();
    }

    public void next() {
        Track t = queue.next(false);
        if (t == null) { stop(); return; }
        consecutiveLoadFailures = 0;
        playInternal(t);
    }

    public void previous() {
        if (current != null && current.getPositionMs() > 3000) {
            current.seek(0);
            return;
        }
        Track t = queue.previous();
        if (t != null) playInternal(t);
    }

    public void seek(long ms) { if (current != null) current.seek(ms); }

    public void setVolume(double v) {
        this.volume = Math.max(0, Math.min(1, v));
        if (current != null) current.setVolume(volume);
    }

    public double getVolume() { return volume; }
    public long getPositionMs() { return current == null ? 0 : current.getPositionMs(); }
    public long getDurationMs() { return current == null ? 0 : current.getDurationMs(); }
    public PlaybackState getState() { return current == null ? PlaybackState.IDLE : current.getState(); }
    public Track getCurrentTrack() { return queue.getCurrent(); }

    public void addListener(Listener l) { listeners.add(l); }
    public void removeListener(Listener l) { listeners.remove(l); }

    private void playInternal(Track t) {
        if (t == null) return;
        if (current != null) {
            current.setListener(null);   // sonst feuert die alte Engine STOPPED-Events in die neue Engine-Referenz
            current.stop();
            current.dispose();
            current = null;
        }
        current = createEngineFor(t);
        current.setVolume(volume);
        current.setListener(new PlaybackEngine.Listener() {
            @Override public void onStateChanged(PlaybackState s) {
                systemControls.updateState(s, current == null ? 0 : current.getPositionMs(),
                                              current == null ? 0 : current.getDurationMs());
                fireState(s);
            }
            @Override public void onPositionChanged(long p, long d) {
                systemControls.updateState(current.getState(), p, d);
                for (Listener l : listeners) l.onPosition(p, d);
            }
            @Override public void onEndReached() {
                consecutiveLoadFailures = 0;
                Track nxt = queue.next(true);
                if (nxt != null) playInternal(nxt);
                else stop();
            }
            @Override public void onError(String message) {
                for (Listener l : listeners) l.onError(message);
                skipAfterFailure();
            }
        });

        for (Listener l : listeners) l.onTrackChanged(t);
        systemControls.updateNowPlaying(t);
        playStartHook.get().accept(t);

        CompletableFuture.runAsync(() -> {
            try {
                Path local = resolveLocalFile(t);
                current.setKnownDurationMs(t.getDurationMs());
                current.load(local);
                current.play();
                consecutiveLoadFailures = 0;
            } catch (Exception e) {
                for (Listener l : listeners) l.onError("Datei nicht abspielbar: " + e.getMessage());
                skipAfterFailure();
            }
        });
    }

    private void skipAfterFailure() {
        consecutiveLoadFailures++;
        if (consecutiveLoadFailures >= MAX_CONSECUTIVE_LOAD_FAILURES) {
            for (Listener l : listeners) l.onError(
                "Wiedergabe gestoppt: " + consecutiveLoadFailures + " Titel in Folge nicht abspielbar.");
            consecutiveLoadFailures = 0;
            stop();
            return;
        }
        Track nxt = queue.next(false);
        if (nxt != null) playInternal(nxt);
        else { consecutiveLoadFailures = 0; stop(); }
    }

    private Path resolveLocalFile(Track t) throws Exception {
        if (t.isLocal()) {
            File f = t.getLocalFile();
            if (f == null) throw new Exception("Lokaler Pfad fehlt.");
            return f.toPath();
        }
        LifeOSFileReference ref = t.resolve(core, moduleId);
        if (ref == null) throw new Exception("Track-Referenz konnte nicht aufgelöst werden. Bitte die Quelle neu scannen.");
        return cache.ensureCached(ref);
    }

    private PlaybackEngine createEngineFor(Track t) {
        // Ab v0.9: FFmpeg ist die primäre Engine. Sie kann alle Formate
        // und Größen, an denen sich der JavaFX-MediaPlayer verschluckt hat.
        if (ffmpegAvailable()) {
            return new FFmpegPlaybackEngine();
        }
        // Fallback, falls die nativen FFmpeg-Bibliotheken auf dieser
        // Plattform nicht laden — dann landen wir wieder bei der alten
        // JFX/jflac-Kombination, damit der Player nicht stumm wird.
        String fmt = (t.getFormat() == null ? "" : t.getFormat().toLowerCase());
        String path = t.getFilePath() == null ? "" : t.getFilePath().toLowerCase();
        if (fmt.contains("flac") || path.endsWith(".flac")) {
            return new FlacPlaybackEngine();
        }
        return new JfxPlaybackEngine();
    }

    private static volatile Boolean ffmpegProbed;
    private static boolean ffmpegAvailable() {
        Boolean p = ffmpegProbed;
        if (p != null) return p;
        synchronized (PlaybackController.class) {
            if (ffmpegProbed != null) return ffmpegProbed;
            try {
                Class.forName("org.bytedeco.javacv.FFmpegFrameGrabber");
                // Erzwingt das Laden der nativen FFmpeg-Bibliotheken jetzt,
                // damit wir nicht erst beim ersten Track scheitern.
                org.bytedeco.ffmpeg.global.avutil.av_version_info();
                ffmpegProbed = Boolean.TRUE;
            } catch (Throwable t) {
                System.err.println("[MusicPlayer] FFmpeg nicht verfügbar, fallback auf JavaFX/jflac: "
                                   + t.getClass().getSimpleName() + ": " + t.getMessage());
                ffmpegProbed = Boolean.FALSE;
            }
            return ffmpegProbed;
        }
    }

    private void fireState(PlaybackState s) {
        for (Listener l : listeners) l.onStateChanged(s);
    }
}
