package com.lifeos.musicplayer.system;

import com.lifeos.musicplayer.model.Track;
import com.lifeos.musicplayer.playback.PlaybackState;

/**
 * Plattform-agnostische Default-Implementierung. Sie hält den Handler
 * und Now-Playing-Informationen lokal vor, damit ein nativer Adapter
 * (z. B. SMTC-JNI auf Windows) sich später an dieselbe Instanz
 * andocken kann, ohne Code im PlaybackController zu ändern.
 *
 * Sobald ein nativer Adapter verfügbar ist, kann eine
 * {@link NativeBridge} per setNativeBridge(...) registriert werden.
 */
public final class DefaultSystemMediaControls implements SystemMediaControls {

    public interface NativeBridge {
        default void onAttach(Handler handler) {}
        default void onNowPlaying(Track track) {}
        default void onState(PlaybackState state, long positionMs, long durationMs) {}
        default void onDetach() {}
    }

    private Handler handler = new Handler() {};
    private NativeBridge bridge;
    private Track nowPlaying;
    private PlaybackState lastState = PlaybackState.IDLE;
    private long lastPos;
    private long lastDur;

    public void setNativeBridge(NativeBridge bridge) {
        if (this.bridge != null) this.bridge.onDetach();
        this.bridge = bridge;
        if (bridge != null) {
            bridge.onAttach(handler);
            if (nowPlaying != null) bridge.onNowPlaying(nowPlaying);
            bridge.onState(lastState, lastPos, lastDur);
        }
    }

    @Override public void setHandler(Handler h) {
        this.handler = h == null ? new Handler() {} : h;
        if (bridge != null) bridge.onAttach(this.handler);
    }

    @Override public void updateNowPlaying(Track track) {
        this.nowPlaying = track;
        if (bridge != null) bridge.onNowPlaying(track);
    }

    @Override public void updateState(PlaybackState state, long positionMs, long durationMs) {
        this.lastState = state;
        this.lastPos = positionMs;
        this.lastDur = durationMs;
        if (bridge != null) bridge.onState(state, positionMs, durationMs);
    }

    @Override public void shutdown() {
        if (bridge != null) bridge.onDetach();
        bridge = null;
    }
}
